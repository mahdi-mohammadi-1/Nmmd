// ============================================================
// v2.19 — full-site VISUAL audit on rendered pages.
// Loads every route in a real browser at 4 widths × 2 langs,
// measures geometry from the DOM, crawls every internal link.
// usage: node research/visual-audit.mjs
// ============================================================
import { createRequire } from 'node:module';
const require = createRequire(new URL('.', import.meta.url));
const { chromium } = require('playwright');

const BASE = 'http://localhost:5176/#/';
const ROUTES = ['home', 'about', 'machinery', 'machinery/bulldozers', 'models/sd22', 'parts', 'parts/oil-filter', 'services', 'news', 'news/season-prep', 'contact'];
const VIEWS = [
  { w: 1440, h: 900, langs: ['fa', 'en'] },
  { w: 1024, h: 768, langs: ['fa'] },
  { w: 768, h: 1024, langs: ['fa'] },
  { w: 390, h: 844, langs: ['fa', 'en'] },
];
const SEV = { CRITICAL: [], HIGH: [], MEDIUM: [], LOW: [] };
const add = (sev, msg) => { SEV[sev].push(msg); console.log(`[${sev}] ${msg}`); };

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });

// ---------- pass 1: geometry per route/viewport/lang ----------
const linkTargets = new Set();
for (const v of VIEWS) {
  for (const lang of v.langs) {
    for (const route of ROUTES) {
      const page = await browser.newPage({ viewport: { width: v.w, height: v.h } });
      const errors = [];
      page.on('pageerror', e => errors.push(String(e).slice(0, 120)));
      page.on('console', m => m.type() === 'error' && errors.push(m.text().slice(0, 120)));
      try {
        await page.goto(`${BASE}${lang}/${route}`, { waitUntil: 'networkidle', timeout: 15000 });
      } catch { add('CRITICAL', `${route} [${lang}@${v.w}]: failed to load`); await page.close(); continue; }
      await page.waitForTimeout(350);
      // lazy-load images
      await page.evaluate(async () => {
        for (let y = 0; y <= document.body.scrollHeight; y += 650) { scrollTo(0, y); await new Promise(r => setTimeout(r, 15)); }
        scrollTo(0, 0);
      });
      await page.waitForTimeout(250);
      const m = await page.evaluate(() => {
        const out = {};
        out.docW = document.documentElement.scrollWidth;
        out.vw = innerWidth;
        out.is404 = document.body.textContent.includes('404');
        out.h1 = document.querySelectorAll('h1').length;
        // broken images
        out.badImgs = [...document.querySelectorAll('img')].filter(i => i.complete && i.naturalWidth === 0).map(i => i.getAttribute('src'));
        // collect internal links
        out.links = [...document.querySelectorAll('a[href^="#/"]')].map(a => a.getAttribute('href'));
        // tap targets
        out.smallTaps = [...document.querySelectorAll('a, button')].filter(el => {
          const r = el.getBoundingClientRect();
          const cs = getComputedStyle(el);
          if (cs.display === 'none' || cs.visibility === 'hidden' || r.width === 0 || el.classList.contains('sr-only')) return false;
          return (r.height > 0 && r.height < 30 && el.textContent.trim().length > 0);
        }).slice(0, 4).map(el => el.textContent.trim().slice(0, 24) + `(${Math.round(el.getBoundingClientRect().height)}px)`);
        // navbar
        const nav = document.querySelector('header, nav') || document.querySelector('div[class*="sticky"]');
        out.nav = nav ? { h: Math.round(nav.getBoundingClientRect().height), pos: getComputedStyle(nav).position, blur: getComputedStyle(nav).backdropFilter !== 'none' } : null;
        // hero overlay (first section w/ big img bg)
        const hero = document.querySelector('section');
        out.hero = hero ? { h: Math.round(hero.getBoundingClientRect().height), hasOverlay: !!hero.querySelector('[class*="gradient"], [class*="overlay"], img[class*="absolute"]') } : null;
        // text clipped horizontally
        // v2.20 harmony rule: no full-width orange CTA slabs (CtaBand is dark)
        out.orangeSlabs = [...document.querySelector('main').children].filter(el => /rgb\(255, *95, *0\)/.test(getComputedStyle(el).backgroundColor)).length;
        out.clipped = [...document.querySelectorAll('h1,h2,h3,p,a,button')].filter(el => el.scrollWidth > el.clientWidth + 2 && getComputedStyle(el).overflow !== 'hidden' && getComputedStyle(el).textOverflow !== 'ellipsis').length;
        return out;
      });
      const id = `${route} [${lang}@${v.w}]`;
      if (m.is404 && route !== 'x') add('CRITICAL', `${id}: renders 404`);
      if (m.docW > m.vw + 1) add('CRITICAL', `${id}: horizontal overflow ${m.docW}px > ${m.vw}px`);
      if (m.h1 !== 1) add('HIGH', `${id}: h1 count = ${m.h1}`);
      if (m.badImgs.length) add('CRITICAL', `${id}: broken images ${m.badImgs.join(', ')}`);
      if (m.smallTaps.length) add('MEDIUM', `${id}: tap targets <30px — ${m.smallTaps.join(', ')}`);
      if (m.nav && m.nav.h > 96) add('HIGH', `${id}: navbar ${m.nav.h}px tall`);
      if (m.nav && !m.nav.blur && v.w === 390) add('LOW', `${id}: navbar has no backdrop blur`);
      if (m.clipped > 0) add('MEDIUM', `${id}: ${m.clipped} text elements clipped`);
      if (m.orangeSlabs > 0) add('HIGH', `${id}: ${m.orangeSlabs} full-width orange section(s) — use CtaBand`);
      if (errors.length) add('HIGH', `${id}: console errors — ${errors[0]}`);
      m.links.forEach(l => linkTargets.add(l));
      await page.close();
    }
  }
}

// ---------- pass 2: internal link crawl (fa) ----------
const seen = new Set();
for (const href of [...linkTargets]) {
  if (!href.startsWith('#/')) continue;
  const path = href.slice(2); // fa/xxx or en/xxx
  if (seen.has(path)) continue;
  seen.add(path);
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  try {
    await page.goto(`${BASE}${path}`, { waitUntil: 'networkidle', timeout: 15000 });
    await page.waitForTimeout(300);
    const is404 = await page.evaluate(() => document.body.textContent.includes('404'));
    if (is404) add('CRITICAL', `dead link target: #/${path}`);
  } catch { add('CRITICAL', `link target failed to load: #/${path}`); }
  await page.close();
}

// ---------- pass 3: navbar scroll behavior + mobile menu (fa home) ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  await page.goto(BASE + 'fa/home', { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);
  const before = await page.evaluate(() => {
    const nav = document.querySelector('header, nav');
    return { cls: nav?.className || '', bg: nav ? getComputedStyle(nav).backgroundColor : '' };
  });
  await page.evaluate(() => scrollTo(0, 700));
  await page.waitForTimeout(500);
  const after = await page.evaluate(() => {
    const nav = document.querySelector('div.fixed.inset-x-0.top-0, header, nav');
    const r = nav?.getBoundingClientRect();
    return { cls: nav?.className || '', bg: nav ? getComputedStyle(nav).backgroundColor : '', top: r ? r.top : 99, h: r ? Math.round(r.height) : 0 };
  });
  if (after.top > 1) add('HIGH', 'navbar is not sticky/fixed after scroll');
  if (before.cls === after.cls && before.bg === after.bg) add('LOW', 'navbar has no visible scrolled-state change (bg/shadow)');
  await page.close();
}
{
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await page.goto(BASE + 'fa/home', { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);
  const burger = await page.locator('button[aria-label*="menu" i], button[aria-label*="منو"]').count();
  const anyBtn = await page.locator('header button, nav button').count();
  if (burger === 0 && anyBtn === 0) add('HIGH', 'mobile: no menu button found in navbar @390');
  else {
    // try to open the drawer
    const btn = page.locator('header button, nav button').first();
    await btn.click();
    await page.waitForTimeout(400);
    const open = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1);
    const drawer = await page.evaluate(() => {
      const links = [...document.querySelectorAll('a, button')].filter(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.top >= 0 && r.top < innerHeight; });
      return links.length;
    });
    if (open) add('MEDIUM', 'mobile menu open causes horizontal overflow');
  }
  await page.close();
}

await browser.close();
console.log('\n========== SUMMARY ==========');
for (const k of ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']) console.log(`${k}: ${SEV[k].length}`);
