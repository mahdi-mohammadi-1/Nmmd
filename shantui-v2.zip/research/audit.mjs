// ============================================================
// Rendered-output visual audit — the enforceable form of the
// mandatory "Code → Run → Visual Check → Fix → Re-check" rule.
// Drives real Chromium and inspects actual rendered geometry,
// images, fonts, motion, hover states and interactions.
// usage: node research/audit.mjs
// ============================================================
import { createRequire } from 'node:module';
const require = createRequire(new URL('.', import.meta.url));
const { chromium } = require('playwright');

const BASE = 'http://localhost:5176/#/';
const PAGES = ['home', 'about', 'machinery', 'machinery/bulldozers', 'models/sd22', 'parts', 'parts/oil-filter', 'services', 'news', 'news/season-prep', 'contact'];
let pass = 0, fail = 0; const findings = [];
const ok = (name, cond, note = '') => { cond ? pass++ : (fail++, findings.push(`${name} ${note}`)); console.log(`${cond ? 'PASS' : 'FAIL'} ${name}${note ? ' — ' + note : ''}`); };

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });

// ---------- sweep: every page × lang × width ----------
for (const lang of ['fa', 'en']) {
  for (const route of PAGES) {
    for (const [w, h] of [[390, 844], [1440, 900]]) {
      const page = await browser.newPage({ viewport: { width: w, height: h } });
      const errors = [];
      page.on('pageerror', e => errors.push(String(e)));
      page.on('console', m => m.type() === 'error' && errors.push(m.text()));
      await page.goto(BASE + lang + '/' + route, { waitUntil: 'networkidle' });
      await page.evaluate(async () => {
        for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 60)); }
        for (const el of document.querySelectorAll('.strip')) {
          const rtl = getComputedStyle(el).direction === 'rtl';
          const max = el.scrollWidth;
          for (let x = 0; x <= max; x += 280) { el.scrollLeft = rtl ? -x : x; await new Promise(r => setTimeout(r, 80)); }
          el.scrollLeft = 0;
        }
        scrollTo(0, 0);
      });
      await page.waitForFunction(() => [...document.images].every(im => im.complete), { timeout: 6000 }).catch(() => {});
      await page.waitForTimeout(400);
      const tag = `${lang}/${route}@${w}`;
      const r = await page.evaluate(() => {
        const vw = window.innerWidth;
        const out = { overflow: document.documentElement.scrollWidth - vw, brokenImgs: [], tinyTargets: [], headingClipped: [] };
        document.querySelectorAll('img').forEach(im => { if (!im.complete || im.naturalWidth === 0) out.brokenImgs.push(im.src.split('/').pop()); });
        document.querySelectorAll('a, button').forEach(el => {
          const b = el.getBoundingClientRect();
          if (b.width > 0 && b.height > 5 && b.height < 30 && el.offsetParent !== null && !el.className.toString().includes('sr-only')) out.tinyTargets.push(`${el.textContent.trim().slice(0, 14)}(${Math.round(b.height)}px)`);
        });
        document.querySelectorAll('h1,h2,h3').forEach(el => { if (el.scrollWidth > el.clientWidth + 3 && getComputedStyle(el).overflowX !== 'visible' && getComputedStyle(el).textOverflow !== 'ellipsis') out.headingClipped.push(el.textContent.trim().slice(0, 18)); });
        return out;
      });
      ok(`${tag}: no horizontal overflow`, r.overflow <= 1, `+${r.overflow}px`);
      ok(`${tag}: images load`, r.brokenImgs.length === 0, r.brokenImgs.slice(0, 3).join(','));
      ok(`${tag}: tap targets ≥30px`, r.tinyTargets.length === 0, r.tinyTargets.slice(0, 3).join(','));
      ok(`${tag}: headings not clipped`, r.headingClipped.length === 0, r.headingClipped.slice(0, 2).join('|'));
      ok(`${tag}: no console errors`, errors.length === 0, errors.slice(0, 2).join('|'));
      await page.close();
    }
  }
}

// ---------- deep checks: home ----------
for (const lang of ['fa', 'en']) {
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  await page.goto(BASE + lang + '/home', { waitUntil: 'networkidle' });
  await page.waitForTimeout(2200);
  const tag = `deep/${lang}`;
  // hero
  const hero = await page.evaluate(() => {
    const s = document.querySelector('section[aria-labelledby="hero-title"]');
    const b = s?.getBoundingClientRect();
    const btns = [...s?.querySelectorAll('a, button') || []].filter(el => el.getBoundingClientRect().height > 40);
    return { h: b?.height || 0, vh: innerHeight, btns: btns.length };
  });
  ok(`${tag}: hero ≥70% viewport`, hero.h >= 0.7 * hero.vh, `${Math.round(hero.h)}px`);
  ok(`${tag}: hero CTAs visible`, hero.btns >= 2);
  // fonts
  await page.evaluate(() => document.fonts.ready);
  const fonts = await page.evaluate(lang => ({
    barlow: [...document.fonts].some(f => f.family.includes('Barlow') && f.status === 'loaded'),
    noto: lang !== 'fa' || [...document.fonts].some(f => f.family.includes('Noto Sans Arabic') && f.status === 'loaded'),
  }), lang);
  ok(`${tag}: display font loaded`, fonts.barlow);
  ok(`${tag}: Persian font loaded`, fonts.noto);
  // product stream coverage + hover pause
  const stream = await page.evaluate(() => {
    const cards = [...document.querySelectorAll('.prod-rail article')];
    const vw = innerWidth;
    const vis = cards.filter(c => { const b = c.getBoundingClientRect(); return b.left < vw - 30 && b.right > 30; });
    return { vis: vis.length, track: !!document.querySelector('.prod-track') };
  });
  ok(`${tag}: stream shows ≥4 cards`, stream.vis >= 4, `${stream.vis} visible`);
  await page.hover('.prod-rail');
  await page.waitForTimeout(300);
  const paused = await page.evaluate(() => getComputedStyle(document.querySelector('.prod-track')).animationPlayState);
  ok(`${tag}: hover pauses stream`, paused === 'paused', paused);
  // nav indicator alignment
  const ind = await page.evaluate(() => {
    const nav = document.querySelector('header nav');
    const active = nav?.querySelector('[aria-current="page"]');
    const bar = nav?.querySelector('span[aria-hidden="true"]');
    if (!active || !bar) return null;
    const a = active.getBoundingClientRect(), b = bar.getBoundingClientRect();
    return { dl: Math.abs(a.left - b.left), dr: Math.abs(a.right - b.right) };
  });
  ok(`${tag}: nav indicator aligned`, ind && ind.dl < 4 && ind.dr < 4, ind ? `Δ${ind.dl.toFixed(1)}/${ind.dr.toFixed(1)}` : 'none');
  // footer reachable, page end clean
  await page.evaluate(() => scrollTo(0, document.body.scrollHeight));
  await page.waitForTimeout(500);
  const endOk = await page.evaluate(() => {
    const f = document.querySelector('footer');
    const r = f?.getBoundingClientRect();
    return !!r && r.bottom <= innerHeight + 2 && r.height > 200;
  });
  ok(`${tag}: footer renders at page end`, endOk);
  await page.close();
}

// ---------- mobile menu + quote sheet ----------
{
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await page.goto(BASE + 'fa/home', { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  const burger = page.locator('header button[aria-haspopup="menu"]');
  ok('mobile: hamburger visible', await burger.isVisible());
  await burger.click();
  await page.waitForTimeout(400);
  ok('mobile: menu opens with 7 links', (await page.locator('[role="menu"] a').count()) === 7);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  ok('mobile: Esc closes menu', (await page.locator('[role="menu"]').count()) === 0);
  // quote sheet journey on mobile
  await page.locator('section[aria-labelledby="hero-title"] button').first().click();
  await page.waitForSelector('[role="dialog"]');
  await page.waitForTimeout(1000);
  await page.locator('[role="dialog"] form button[type="submit"]').click();
  await page.waitForTimeout(300);
  ok('mobile: quote validation errors', (await page.locator('[role="alert"]').count()) === 2);
  await page.fill('input[type="text"]', 'تست');
  await page.fill('input[type="tel"]', '0700 000 000');
  await page.locator('[role="dialog"] form button[type="submit"]').click();
  await page.waitForTimeout(300);
  ok('mobile: quote records', await page.locator('[role="status"]').isVisible());
  await page.close();
}

await browser.close();
console.log(`\n${pass} passed, ${fail} failed`);
if (findings.length) console.log('FINDINGS:\n' + findings.map(f => ' - ' + f).join('\n'));
process.exit(fail ? 1 : 0);
