// ============================================================
// Step-4 home restructure — targeted rendered-geometry checks
// for the NEW sections (audit.mjs covers the general sweep).
// usage: node research/qa-home.mjs
// ============================================================
import { createRequire } from 'node:module';
const require = createRequire(new URL('.', import.meta.url));
const { chromium } = require('playwright');

const BASE = 'http://localhost:5176/#/';
let pass = 0, fail = 0; const findings = [];
const ok = (name, cond, note = '') => { cond ? pass++ : (fail++, findings.push(`${name} ${note}`)); console.log(`${cond ? 'PASS' : 'FAIL'} ${name}${note ? ' — ' + note : ''}`); };

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });

// ---------- home fa @1440: all 10 sections + new-section geometry ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'fa/home', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);

  // lazy-load everything
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 50)); }
    scrollTo(0, 0);
  });
  await page.waitForTimeout(400);

  // 1. header: transparent overlay state at top (over hero video/photo)
  const topHeader = await page.evaluate(() => {
    const h = document.querySelector('header');
    const cs = getComputedStyle(h);
    return { bg: cs.backgroundColor, blur: cs.backdropFilter };
  });
  // bg-deep/35 renders as oklab(≈0.21 … / 0.35); bg-card/90 as oklab(≈1 … / 0.9)
  ok('header@top transparent-dark glass', /\/\s*0\.35\)/.test(topHeader.bg) && topHeader.blur.includes('blur'), JSON.stringify(topHeader));

  // hero H1 must clear the fixed header (overlay, not covered)
  const heroClear = await page.evaluate(() => {
    const h1 = document.querySelector('#hero-title');
    const header = document.querySelector('header');
    return h1 && header ? h1.getBoundingClientRect().top - header.getBoundingClientRect().bottom : -1;
  });
  ok('hero h1 clears fixed header', heroClear > 0, `gap ${Math.round(heroClear)}px`);

  // 2. header: solid glass after scroll
  await page.evaluate(() => scrollTo(0, 400));
  await page.waitForTimeout(400);
  const solidHeader = await page.evaluate(() => {
    const h = document.querySelector('header');
    return getComputedStyle(h).backgroundColor;
  });
  ok('header@scrolled solid glass', /\/\s*0\.9\)/.test(solidHeader), solidHeader);

  // 3. section order on the page (by vertical position)
  const order = await page.evaluate(() => {
    const marks = [
      ['hero', '#hero-title'], ['products', 'section[aria-label] .prod-rail'],
      ['categories', 'a[href$="/machinery/bulldozers"]'], ['about', '#hero-title ~ *'], // placeholder, refined below
    ];
    const tops = {};
    const h1 = document.querySelector('#hero-title'); if (h1) tops.hero = h1.getBoundingClientRect().top + scrollY;
    const rail = document.querySelector('.prod-rail'); if (rail) tops.products = rail.getBoundingClientRect().top + scrollY;
    const catTile = document.querySelector('a[href$="/machinery/bulldozers"]'); if (catTile) tops.categories = catTile.getBoundingClientRect().top + scrollY;
    const finder = document.querySelector('select'); if (finder) tops.parts = finder.getBoundingClientRect().top + scrollY;
    const fig = document.querySelector('figure'); if (fig) tops.gallery = fig.getBoundingClientRect().top + scrollY;
    const newsImg = [...document.querySelectorAll('img[src*="news-"]')][0]; if (newsImg) tops.news = newsImg.getBoundingClientRect().top + scrollY;
    const finale = document.querySelector('#finale-title'); if (finale) tops.finale = finale.getBoundingClientRect().top + scrollY;
    return Object.fromEntries(Object.entries(tops).map(([k, v]) => [k, Math.round(v)]));
  });
  const seq = ['hero', 'products', 'categories', 'parts', 'news', 'gallery', 'finale'];
  let monotone = true;
  for (let i = 1; i < seq.length; i++) if (!(order[seq[i - 1]] < order[seq[i]])) monotone = false;
  ok('section order hero→products→categories→parts→news→gallery→finale', monotone, JSON.stringify(order));

  // 4. category tiles: 6, each with a loaded image + label
  const tiles = await page.evaluate(async () => {
    const links = [...document.querySelectorAll('a[href*="/machinery/"]')].filter(a => a.querySelector('img') && a.querySelector('h3'));
    const out = [];
    for (const a of links) {
      const im = a.querySelector('img');
      out.push({ label: a.querySelector('h3').textContent.trim(), complete: im.complete && im.naturalWidth > 0, w: im.getBoundingClientRect().width });
    }
    return out;
  });
  ok('category tiles = 6', tiles.length === 6, String(tiles.length));
  ok('category tile images all loaded', tiles.every(t => t.complete), tiles.filter(t => !t.complete).map(t => t.label).join(','));
  ok('category tiles BIG (≥280px wide)', tiles.every(t => t.w >= 280), `min ${Math.round(Math.min(...tiles.map(t => t.w)))}px`);

  // 5. parts finder: two selects + search btn; default one card per group (4)
  const finder = await page.evaluate(() => ({
    selects: document.querySelectorAll('select').length,
    cards: [...document.querySelectorAll('article img[src*="part-"]')].length,
  }));
  ok('parts finder: 2 selects', finder.selects === 2, String(finder.selects));
  ok('parts default = 4 cards (one per group)', finder.cards === 4, String(finder.cards));

  // 6. finder interaction: pick a group → search → 3 filter parts
  await page.evaluate(() => scrollTo(0, 0));
  const partSelects = page.locator('select');
  await partSelects.nth(1).selectOption({ label: 'فیلترها' });
  await page.getByRole('button', { name: /جستجو/ }).click();
  await page.waitForTimeout(300);
  const after = await page.evaluate(() => [...document.querySelectorAll('article img[src*="part-"]')].length);
  ok('finder: filters group → 3 cards', after === 3, String(after));

  // 7. news asym: exactly 3 photos loaded
  const news = await page.evaluate(() => {
    const sec = [...document.querySelectorAll('section')].find(s => s.textContent.includes('آماده‌سازی ناوگان') || s.textContent.includes('Preparing your fleet'));
    return sec ? [...sec.querySelectorAll('img')].map(im => im.complete && im.naturalWidth > 0) : [];
  });
  ok('news preview = 3 images, all loaded', news.length === 3 && news.every(Boolean), JSON.stringify(news));

  // 8. gallery masonry: 6 figures, all loaded, ≥2 distinct heights
  const gallery = await page.evaluate(() => {
    const figs = [...document.querySelectorAll('figure')];
    const imgs = figs.map(f => f.querySelector('img')).filter(Boolean);
    const hs = [...new Set(imgs.map(im => Math.round(im.getBoundingClientRect().height / 50) * 50))];
    return { n: imgs.length, allLoaded: imgs.every(im => im.complete && im.naturalWidth > 0), distinctHeights: hs.length };
  });
  ok('gallery = 6 images, loaded', gallery.n === 6 && gallery.allLoaded, `${gallery.n} imgs`);
  ok('gallery masonry has varied heights', gallery.distinctHeights >= 2, `${gallery.distinctHeights} height buckets`);

  // 9. testimonials: 3 cards + demo note visible
  const testi = await page.evaluate(() => {
    const blocks = [...document.querySelectorAll('figure blockquote')];
    const note = document.body.textContent.includes('نظریات نمایشی');
    return { n: blocks.length, note };
  });
  ok('testimonials = 3 + demo note', testi.n === 3 && testi.note, JSON.stringify(testi));

  // 10. footer: 5 nav columns + 3 social buttons + soon label
  const footer = await page.evaluate(() => {
    const f = document.querySelector('footer');
    const cols = [...f.querySelectorAll('nav')].length;
    const socials = [...f.querySelectorAll('button[title*="به‌زودی"]')].length;
    return { cols, socials };
  });
  ok('footer: 4 link columns + company column', footer.cols === 4, String(footer.cols));
  ok('footer: 3 social buttons (soon)', footer.socials === 3, String(footer.socials));

  ok('home fa: no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  await page.close();
}

// ---------- home en @390: overlay header, no overflow, mobile ok ----------
{
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await page.goto(BASE + 'en/home', { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);
  const mob = await page.evaluate(() => {
    const header = document.querySelector('header');
    const r = header.getBoundingClientRect();
    const h1 = document.querySelector('#hero-title');
    return { headerW: Math.round(r.width), h1Top: Math.round(h1.getBoundingClientRect().top), docW: document.documentElement.scrollWidth, vw: innerWidth };
  });
  ok('mobile header fits viewport', mob.headerW <= mob.vw, JSON.stringify(mob));
  ok('mobile hero h1 below header', mob.h1Top >= 96, `h1 top ${mob.h1Top}px`);
  ok('mobile: no horizontal overflow', mob.docW <= mob.vw + 1, `${mob.docW} vs ${mob.vw}`);
  await page.close();
}

// ---------- interior page: fixed-header padding ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  await page.goto(BASE + 'fa/about', { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);
  const pad = await page.evaluate(() => {
    const main = document.querySelector('main');
    const hero = main.querySelector('h1') || main.querySelector('h2');
    return { pt: getComputedStyle(main).paddingTop, firstTop: Math.round(hero.getBoundingClientRect().top) };
  });
  ok('interior page pads below fixed header', parseInt(pad.pt) >= 104 && pad.firstTop >= 100, JSON.stringify(pad));
  // header must be solid on interior pages even at scrollY=0
  const bg = await page.evaluate(() => getComputedStyle(document.querySelector('header')).backgroundColor);
  ok('interior header solid at top', /\/\s*0\.9\)/.test(bg), bg);
  await page.close();
}

await browser.close();
console.log(`\n${pass} passed, ${fail} failed`);
if (findings.length) { console.log('FINDINGS:'); findings.forEach(f => console.log(' - ' + f)); process.exit(1); }
