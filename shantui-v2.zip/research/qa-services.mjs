// ============================================================
// Services-page rebuild — targeted rendered-geometry + interaction
// checks. usage: node research/qa-services.mjs
// ============================================================
import { createRequire } from 'node:module';
const require = createRequire(new URL('.', import.meta.url));
const { chromium } = require('playwright');

const BASE = 'http://localhost:5176/#/';
let pass = 0, fail = 0; const findings = [];
const ok = (name, cond, note = '') => { cond ? pass++ : (fail++, findings.push(`${name} ${note}`)); console.log(`${cond ? 'PASS' : 'FAIL'} ${name}${note ? ' — ' + note : ''}`); };

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });

// ---------- fa/services @1440 ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'fa/services', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 40)); }
    scrollTo(0, 0);
  });
  await page.waitForTimeout(400);

  // 1. hero 40–55vh + 2 CTAs
  const hero = await page.evaluate(() => {
    const h = document.querySelector('#svc-hero-title').closest('section').getBoundingClientRect();
    const btns = [...document.querySelectorAll('button, a')].filter(el => el.textContent.includes('درخواست سرویس') || el.textContent.includes('تماس با تیم تخنیکی')).length;
    return { pct: Math.round(h.height / innerHeight * 100), btns };
  });
  ok('hero 40–55vh', hero.pct >= 40 && hero.pct <= 55, hero.pct + '%');
  ok('hero has both CTAs', hero.btns >= 2, String(hero.btns));

  // 2. six service cards with icons; 2 have detail anchors
  const cards = await page.evaluate(() => ({
    n: [...document.querySelectorAll('article')].filter(a => a.querySelector('svg')).length,
    details: [...document.querySelectorAll('button')].filter(b => b.textContent.includes('جزئیات بیشتر')).length,
  }));
  ok('6 service cards', cards.n === 6, String(cards.n));
  ok('2 cards link to on-page details', cards.details === 2, String(cards.details));

  // 3. maintenance split: 6 checklist items + image loaded
  const maint = await page.evaluate(() => {
    const sec = document.getElementById('svc-maintenance');
    const items = [...sec.querySelectorAll('li')].length;
    const img = sec.querySelector('img');
    return { items, loaded: img ? img.complete && img.naturalWidth > 0 : false, demo: sec.textContent.includes('تصویر نمایشی') };
  });
  ok('maintenance split: 6 items + image', maint.items === 6 && maint.loaded, JSON.stringify(maint));
  ok('maintenance image demo-labeled', maint.demo);

  // 4. repair process: 5 steps
  const steps = await page.evaluate(() => {
    const sec = document.getElementById('svc-repair');
    return sec ? [...sec.querySelectorAll('li')].length : 0;
  });
  ok('repair process = 5 steps', steps === 5, String(steps));

  // 5. on-site: image + 4 items
  const onsite = await page.evaluate(() => ({
    img: (() => { const i = [...document.querySelectorAll('img[src*="service-field"]')][0]; return i ? i.complete && i.naturalWidth > 0 : false; })(),
    items: ['اعزام تیم تخنیکی', 'بازدید ماشین در پروژه', 'تشخیص مشکل در محل', 'هماهنگی قطعات مورد نیاز'].filter(x => document.body.textContent.includes(x)).length,
  }));
  ok('on-site image loads + 4 items', onsite.img && onsite.items === 4, JSON.stringify(onsite));

  // 6. parts integration: 2 links to parts page
  const partsLinks = await page.evaluate(() => [...document.querySelectorAll('a[href="#/fa/parts"]')].length);
  ok('parts integration links', partsLinks >= 2, String(partsLinks));

  // 7. why: 5 icon items, no fake numbers
  const why = await page.evaluate(() => ['تیم تخنیکی', 'قطعات اصلی', 'پاسخ سریع', 'پشتیبانی پس از فروش', 'تمرکز بر ماشین سنگین'].filter(x => document.body.textContent.includes(x)).length);
  ok('why-services = 5 items', why === 5, String(why));

  // 8. form: fields + province + type select
  const form = await page.evaluate(() => ({
    name: !!document.querySelector('#sf-name'), phone: !!document.querySelector('#sf-phone'),
    prov: document.querySelector('#sf-prov')?.options.length || 0, model: !!document.querySelector('#sf-model'),
    type: document.querySelector('#sf-type')?.options.length || 0, serial: !!document.querySelector('#sf-serial'),
    notes: !!document.querySelector('#sf-notes'), file: !!document.querySelector('#svc-form input[type="file"]') || !!document.querySelector('form input[type="file"][accept*="video"]'),
  }));
  ok('form fields present', form.name && form.phone && form.model && form.serial && form.notes, JSON.stringify(form));
  ok('province select = 34 + placeholder', form.prov === 35, String(form.prov));
  ok('problem-type select = 5 + placeholder', form.type === 6, String(form.type));
  ok('file upload accepts image/video', !!form.file);

  // 9. validation: 4 required errors
  await page.locator('#svc-form button[type="submit"]').click();
  await page.waitForTimeout(300);
  const errs = await page.evaluate(() => [...document.querySelectorAll('#svc-form p')].filter(p => p.textContent.includes('لطفاً این خانه')).length);
  ok('validation shows 4 required errors', errs === 4, String(errs));

  // 10. full submit → localStorage + success
  await page.evaluate(() => localStorage.removeItem('shantui-service-requests'));
  await page.fill('#sf-name', 'تست سرویس');
  await page.fill('#sf-phone', '+93 700 111 111');
  await page.selectOption('#sf-prov', { label: 'بلخ' });
  await page.fill('#sf-model', 'SD16');
  await page.selectOption('#sf-type', { label: 'سرویس دوره‌ای' });
  await page.locator('#svc-form button[type="submit"]').click();
  await page.waitForTimeout(400);
  const sent = await page.evaluate(() => ({
    ok: document.body.textContent.includes('درخواست ثبت شد'),
    rec: (() => { try { return JSON.parse(localStorage.getItem('shantui-service-requests') || '[]'); } catch { return []; } })(),
  }));
  ok('submit → success state', sent.ok);
  ok('request recorded (model+type+province)', sent.rec.length === 1 && sent.rec[0].model === 'SD16' && sent.rec[0].type === 'سرویس دوره‌ای' && sent.rec[0].province === 'بلخ', JSON.stringify(sent.rec.map(r => [r.model, r.type])));

  // 11. FAQ accordion: 5 items, first opens on click
  const faq = await page.evaluate(() => document.querySelectorAll('details').length);
  ok('FAQ = 5 accordion items', faq === 5, String(faq));
  await page.locator('details summary').first().click();
  await page.waitForTimeout(300);
  const open = await page.evaluate(() => document.querySelector('details')?.open);
  ok('FAQ accordion opens', open === true);

  // 12. final CTA
  const cta = await page.evaluate(() => document.body.textContent.includes('ماشین شما نیاز به بررسی تخنیکی دارد؟'));
  ok('final CTA present', cta);

  ok('services fa: no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  await page.close();
}

// ---------- en/services @390 (mobile) ----------
{
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'en/services', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 40)); }
    scrollTo(0, 0);
  });
  const mob = await page.evaluate(() => ({
    docW: document.documentElement.scrollWidth, vw: innerWidth,
    hero: document.body.textContent.includes('Technical service'),
    imgs: [...document.querySelectorAll('img[src*="service-"], img[src*="facility-"]')].every(i => i.complete || i.loading === 'lazy'),
  }));
  ok('en/services@390: no horizontal overflow', mob.docW <= mob.vw + 1, `${mob.docW} vs ${mob.vw}`);
  ok('en/services@390: hero renders + images ok', mob.hero && mob.imgs);
  ok('en/services@390: no console errors', errors.length === 0, errors.slice(0, 2).join(' | '));
  await page.close();
}

await browser.close();
console.log(`\n${pass} passed, ${fail} failed`);
if (findings.length) { console.log('FINDINGS:'); findings.forEach(f => console.log(' - ' + f)); process.exit(1); }
