// v2 smoke suite — verifies every route in both languages renders,
// with no console errors, one h1, a dock, and a working quote sheet.
import { createRequire } from 'node:module';
const require = createRequire('/home/user/shantui-v2/research/node_modules/');
const { chromium } = require('playwright');

const BASE = 'http://localhost:5176/';
const ROUTES = ['home', 'about', 'machinery', 'machinery/bulldozers', 'models/sd22', 'parts', 'services', 'news', 'contact', 'nope-404'];
const WIDTHS = [390, 1280];
let pass = 0, fail = 0;
const ok = (name, cond) => { cond ? pass++ : fail++; console.log(`${cond ? 'PASS' : 'FAIL'} ${name}`); };

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });
for (const lang of ['fa', 'en']) {
  for (const r of ROUTES) {
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', e => errors.push(String(e)));
    page.on('console', m => m.type() === 'error' && errors.push(m.text()));
    await page.goto(BASE + `#/${lang}/${r}`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(350);
    const name = `${lang}/${r}`;
    ok(`${name}: renders`, await page.locator('#root *').first().isVisible());
    ok(`${name}: one h1`, (await page.locator('h1').count()) === 1);
    ok(`${name}: dock`, await page.locator('nav[aria-label] a[aria-current="page"]').first().isVisible().catch(() => false));
    ok(`${name}: dir`, await page.evaluate(() => document.documentElement.dir) === (lang === 'fa' ? 'rtl' : 'ltr'));
    ok(`${name}: no overflow`, await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));
    ok(`${name}: no console errors`, errors.length === 0);
    if (errors.length) console.log('   errors:', errors.slice(0, 2).join(' | '));
    await page.close();
  }
}
// journeys
const page = await browser.newPage();
await page.setViewportSize({ width: 1280, height: 900 });
await page.goto(BASE + '#/en/home', { waitUntil: 'networkidle' });
await page.click('header button:has-text("Request a quotation")');
await page.waitForSelector('[role="dialog"]');
await page.waitForTimeout(1000); // let the sheet entrance animation settle
ok('quote sheet opens', true);
await page.fill('input[type="text"]', 'Smoke Test');
await page.fill('input[type="tel"]', '+93 700 000 000');
await page.click('[role="dialog"] form button[type="submit"]');
await page.waitForTimeout(200);
ok('quote sheet validates + records', await page.locator('text=Request recorded').isVisible().catch(() => false));
await page.click('[aria-label="Close"]');
await page.waitForTimeout(200);
ok('quote sheet closes', (await page.locator('[role="dialog"]').count()) === 0);
await page.click('text=Switch to دری');
await page.waitForTimeout(300);
ok('language flips to RTL Dari', await page.evaluate(() => document.documentElement.dir) === 'rtl');
await page.click('section[aria-labelledby="hero-title"] a:has-text("ماشین‌آلات")');
await page.waitForTimeout(400);
ok('navigates to machinery in Dari', page.url().includes('/fa/machinery'));
await page.click('a:has-text("بلدوزرها")');
await page.waitForTimeout(400);
ok('category filter works', page.url().includes('/fa/machinery/bulldozers'));
for (const w of WIDTHS) {
  await page.setViewportSize({ width: w, height: 900 });
  await page.waitForTimeout(150);
  ok(`no overflow @${w}`, await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));
}
await browser.close();
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
