// ============================================================
// Parts-page rebuild — targeted rendered-geometry + interaction
// checks. usage: node research/qa-parts.mjs
// ============================================================
import { createRequire } from 'node:module';
const require = createRequire(new URL('.', import.meta.url));
const { chromium } = require('playwright');

const BASE = 'http://localhost:5176/#/';
let pass = 0, fail = 0; const findings = [];
const ok = (name, cond, note = '') => { cond ? pass++ : (fail++, findings.push(`${name} ${note}`)); console.log(`${cond ? 'PASS' : 'FAIL'} ${name}${note ? ' — ' + note : ''}`); };

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });

// ---------- fa/parts @1440 ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'fa/parts', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 40)); }
    scrollTo(0, 0);
  });
  await page.waitForTimeout(400);

  // 1. hero 40–55vh with 2 CTAs
  const hero = await page.evaluate(() => {
    const h = document.querySelector('#parts-hero-title').closest('section').getBoundingClientRect();
    const btns = [...document.querySelectorAll('button')].filter(b => b.textContent.includes('جستجوی قطعه') || b.textContent.includes('درخواست قطعه')).length;
    return { pct: Math.round(h.height / innerHeight * 100), btns };
  });
  ok('hero 40–55vh', hero.pct >= 40 && hero.pct <= 55, hero.pct + '%');
  ok('hero has both CTAs', hero.btns >= 2, String(hero.btns));

  // 2. finder: 3 selects + PN input + search button
  const finder = await page.evaluate(() => ({
    selects: document.querySelectorAll('#parts-finder select').length,
    pn: !!document.querySelector('#parts-finder input[type="search"]'),
    searchBtn: [...document.querySelectorAll('#parts-finder button')].some(b => b.textContent.includes('جستجو')),
  }));
  ok('finder: 3 selects + PN field + search', finder.selects === 3 && finder.pn && finder.searchBtn, JSON.stringify(finder));

  // 3. NO separate category section (user removed it) — finder is the only category path
  const noCats = await page.evaluate(() => document.querySelectorAll('button[aria-pressed] img').length);
  ok('no category tile section', noCats === 0, String(noCats));

  // 4. grid: 8 parts, all images loaded, statuses + compat present
  const grid = await page.evaluate(() => {
    const imgs = [...document.querySelectorAll('article img[src*="part-"]')];
    const badges = ['موجود', 'قابل سفارش', 'تصدیق با نمایندگی'].filter(s => document.body.textContent.includes(s)).length;
    return { n: imgs.length, loaded: imgs.every(i => i.complete && i.naturalWidth > 0), badges };
  });
  ok('grid shows 8 parts, images loaded', grid.n === 8 && grid.loaded, JSON.stringify(grid));
  ok('all 3 part statuses present', grid.badges === 3, String(grid.badges));

  // 5. PN search: type ST-10 → 1 result
  await page.fill('#parts-finder input[type="search"]', 'ST-10');
  await page.waitForTimeout(300);
  let n = await page.evaluate(() => document.querySelectorAll('article img[src*="part-"]').length);
  ok('PN search "ST-10" → 1 part', n === 1, String(n));
  await page.fill('#parts-finder input[type="search"]', 'ST-99');
  await page.waitForTimeout(300);
  n = await page.evaluate(() => document.querySelectorAll('article img[src*="part-"]').length);
  const empty = await page.evaluate(() => document.body.textContent.includes('پیدا نشد'));
  ok('PN search "ST-99" → empty state', n === 0 && empty);
  await page.fill('#parts-finder input[type="search"]', '');

  // 6. finder selects → search: excavators + undercarriage → 2 parts
  await page.selectOption('#parts-finder select >> nth=0', 'excavators');
  await page.selectOption('#parts-finder select >> nth=2', 'undercarriage');
  await page.locator('#parts-finder button', { hasText: 'جستجو' }).click();
  await page.waitForTimeout(400);
  n = await page.evaluate(() => document.querySelectorAll('article img[src*="part-"]').length);
  ok('finder excavators+undercarriage → 2 parts', n === 2, String(n));
  await page.locator('button', { hasText: 'پاک کردن فیلترها' }).click();
  await page.waitForTimeout(300);
  n = await page.evaluate(() => document.querySelectorAll('article img[src*="part-"]').length);
  ok('reset returns to 8', n === 8, String(n));

  // 8. form: fields + provinces
  const form = await page.evaluate(() => ({
    name: !!document.querySelector('#pf-name'), phone: !!document.querySelector('#pf-phone'),
    prov: document.querySelector('#pf-prov')?.options.length || 0, model: !!document.querySelector('#pf-model'),
    serial: !!document.querySelector('#pf-serial'), pn: !!document.querySelector('#pf-pn'),
    notes: !!document.querySelector('#pf-notes'), photo: !!document.querySelector('#parts-form input[type="file"]'),
  }));
  ok('form: 8 fields incl. photo upload', form.name && form.phone && form.model && form.serial && form.pn && form.notes && form.photo, JSON.stringify(form));
  ok('province select has 34 provinces + placeholder', form.prov === 35, String(form.prov));

  // 9. validation: empty submit shows 3 errors
  await page.locator('#parts-form button[type="submit"]').click();
  await page.waitForTimeout(300);
  const errs = await page.evaluate(() => [...document.querySelectorAll('#parts-form p')].filter(p => p.textContent.includes('لطفاً این خانه')).length);
  ok('validation shows 3 required errors', errs === 3, String(errs));

  // 10. card → form prefill
  await page.locator('article button', { hasText: 'درخواست این قطعه' }).first().click();
  await page.waitForTimeout(500);
  const pre = await page.evaluate(() => ({
    pn: document.querySelector('#pf-pn')?.value || '',
    notes: document.querySelector('#pf-notes')?.value || '',
  }));
  ok('card request prefills form', pre.pn.startsWith('ST-') && pre.notes.length > 3, JSON.stringify(pre));

  // 11. full submit → recorded locally + success state
  await page.evaluate(() => localStorage.removeItem('shantui-parts-requests'));
  await page.fill('#pf-name', 'تست کاربر');
  await page.fill('#pf-phone', '+93 700 000 000');
  await page.selectOption('#pf-prov', { label: 'کابل' });
  await page.fill('#pf-model', 'SD22');
  await page.locator('#parts-form button[type="submit"]').click();
  await page.waitForTimeout(400);
  const sent = await page.evaluate(() => ({
    ok: document.body.textContent.includes('درخواست ثبت شد'),
    rec: (() => { try { return JSON.parse(localStorage.getItem('shantui-parts-requests') || '[]'); } catch { return []; } })(),
  }));
  ok('submit → success state', sent.ok);
  ok('request recorded in localStorage', sent.rec.length === 1 && sent.rec[0].model === 'SD22' && sent.rec[0].province === 'کابل', JSON.stringify(sent.rec.map(r => r.model)));

  // 12. photo upload → local preview
  await page.locator('#parts-form button', { hasText: 'درخواست جدید' }).click();
  await page.waitForTimeout(300);
  await page.setInputFiles('#parts-form input[type="file"]', { name: 'part.png', mimeType: 'image/png', buffer: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64') });
  await page.waitForTimeout(400);
  const preview = await page.evaluate(() => !!document.querySelector('#parts-form img[src^="data:"]'));
  ok('photo upload shows local preview', preview);

  // 13. sections: why (5) + how (3) + support + cta
  const rest = await page.evaluate(() => ({
    why: document.body.textContent.includes('چرا قطعات اصلی؟'),
    how: document.body.textContent.includes('نحوه‌ی درخواست قطعه'),
    support: document.querySelectorAll('main > section').length,  // v2.20: support band merged into CtaBand — single dark ending
    cta: document.body.textContent.includes('پیدا نکردید؟'),
  }));
  ok('why (5) + how (3) + final CTA present', rest.why && rest.how && rest.cta, JSON.stringify(rest));

  ok('parts fa: no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  await page.close();
}

// ---------- part detail page (#/fa/parts/oil-filter) ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'fa/parts/oil-filter', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);
  const det = await page.evaluate(() => ({
    h1: document.querySelector('h1')?.textContent || '',
    num: document.body.textContent.includes('ST-10-021'),
    compat: document.body.textContent.includes('بلدوزرها'),
    status: document.body.textContent.includes('موجود'),
    similar: document.body.textContent.includes('سایر قطعات این دسته'),
    imgLoaded: [...document.querySelectorAll('img[src*="part-"]')].every(i => i.complete && i.naturalWidth > 0),
  }));
  ok('part detail renders (name/num/compat/status/similar)', det.h1.includes('فیلتر روغن') && det.num && det.compat && det.status && det.similar, JSON.stringify(det));
  ok('part detail images load', det.imgLoaded);
  // request → back to parts page with prefilled form
  await page.locator('button', { hasText: 'درخواست این قطعه' }).first().click();
  await page.waitForTimeout(900);
  const pre = await page.evaluate(() => ({
    hash: location.hash,
    pn: document.querySelector('#pf-pn')?.value || '',
    notes: document.querySelector('#pf-notes')?.value || '',
  }));
  ok('detail request → parts form prefilled', pre.hash === '#/fa/parts' && pre.pn === 'ST-10-021' && pre.notes.length > 3, JSON.stringify(pre));
  ok('part detail: no console errors', errors.length === 0, errors.slice(0, 2).join(' | '));
  await page.close();
}

// ---------- en/parts @390 (mobile) ----------
{
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'en/parts', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 40)); }
    scrollTo(0, 0);
  });
  const mob = await page.evaluate(() => ({
    docW: document.documentElement.scrollWidth, vw: innerWidth,
    hero: document.body.textContent.includes('Genuine SHANTUI parts'),
    imgs: [...document.querySelectorAll('img[src*="part-"], img[src*="facility-"]')].every(i => i.complete || i.loading === 'lazy'),
  }));
  ok('en/parts@390: no horizontal overflow', mob.docW <= mob.vw + 1, `${mob.docW} vs ${mob.vw}`);
  ok('en/parts@390: hero renders', mob.hero);
  ok('en/parts@390: no console errors', errors.length === 0, errors.slice(0, 2).join(' | '));
  await page.close();
}

await browser.close();
console.log(`\n${pass} passed, ${fail} failed`);
if (findings.length) { console.log('FINDINGS:'); findings.forEach(f => console.log(' - ' + f)); process.exit(1); }
