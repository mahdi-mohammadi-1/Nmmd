// ============================================================
// Unified screenshot tool.
// usage:
//   node research/snap.mjs <route> <name> [width] [--vp]
//   node research/snap.mjs fa/services my-shot 1440
//   node research/snap.mjs fa/home mobile-home 390 --vp   (viewport-only, not fullPage)
// Requires the preview server running on :5176 (vite preview).
// ============================================================
import { createRequire } from 'node:module';
const require = createRequire(new URL('.', import.meta.url));
const { chromium } = require('playwright');

const [route, name, wArg, vpArg] = process.argv.slice(2);
if (!route || !name) { console.error('usage: node research/snap.mjs <route> <name> [width] [--vp]'); process.exit(1); }
const width = parseInt(wArg || '1440', 10);
const fullPage = vpArg !== '--vp';

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });
const page = await browser.newPage({ viewport: { width, height: 900 } });
await page.goto(`http://localhost:5176/#/${route}`, { waitUntil: 'networkidle' });
await page.waitForTimeout(500);
await page.evaluate(async () => {
  for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 30)); }
  scrollTo(0, 0);
});
await page.waitForTimeout(400);
await page.screenshot({ path: `/home/user/shots/${name}.png`, fullPage });
await browser.close();
console.log(`saved shots/${name}.png (${route} @${width}${fullPage ? ' fullPage' : ''})`);
