// ============================================================
// v2.18 — contact page rebuild: targeted rendered checks.
// usage: node research/qa-contact.mjs
// ============================================================
import { createRequire } from 'node:module';
const require = createRequire(new URL('.', import.meta.url));
const { chromium } = require('playwright');

const BASE = 'http://localhost:5176/#/';
let pass = 0, fail = 0; const findings = [];
const ok = (name, cond, note = '') => { cond ? pass++ : (fail++, findings.push(name)); console.log(`${cond ? 'PASS' : 'FAIL'} ${name}${note ? ' — ' + note : ''}`); };

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });

// ---------- fa/contact @1440 ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'fa/contact', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 40)); }
    scrollTo(0, 0);
  });
  await page.waitForTimeout(400);

  // 1. hero
  ok('hero renders', await page.locator('h1', { hasText: 'با ما در تماس شوید' }).count() >= 1);

  // 2. four quick-contact cards with tel/wa/mail links
  const cards = await page.evaluate(() => ({
    n: [...document.querySelectorAll('article')].filter(a => a.querySelector('a[href^="tel:"]')).length,
    tel: document.querySelectorAll('a[href^="tel:"]').length,
    wa: document.querySelectorAll('a[href^="https://wa.me/"]').length,
    mail: document.querySelectorAll('a[href^="mailto:"]').length,
    titles: ['فروش', 'دسک قطعات', 'خدمات تخنیکی', 'دفتر و اداره'].filter(x => document.body.textContent.includes(x)).length,
  }));
  ok('4 quick cards with titles', cards.n === 4 && cards.titles === 4, JSON.stringify(cards));
  ok('every card has tel + whatsapp + email', cards.tel >= 4 && cards.wa >= 4 && cards.mail >= 4, `tel:${cards.tel} wa:${cards.wa} mail:${cards.mail}`);

  // 3. demo notice present
  ok('demo notice banner', await page.evaluate(() => document.body.textContent.includes('معلومات تماس نمونه')));

  // 4. form fields + subject options
  const form = await page.evaluate(() => ({
    name: !!document.querySelector('#cf-name'), phone: !!document.querySelector('#cf-phone'),
    email: !!document.querySelector('#cf-email'), subject: document.querySelector('#cf-subject')?.options.length || 0,
    message: !!document.querySelector('#cf-message'),
  }));
  ok('form fields present', form.name && form.phone && form.email && form.message, JSON.stringify(form));
  ok('subject select = 5 + placeholder', form.subject === 6, String(form.subject));

  // 5. validation: 4 required errors
  await page.locator('#cf-message').scrollIntoViewIfNeeded();
  await page.locator('form button[type="submit"]').click();
  await page.waitForTimeout(300);
  const errs = await page.evaluate(() => [...document.querySelectorAll('form p')].filter(p => p.textContent.includes('لطفاً این خانه')).length);
  ok('validation shows 4 required errors', errs === 4, String(errs));

  // 6. full submit → success + localStorage
  await page.evaluate(() => localStorage.removeItem('shantui-contact-requests'));
  await page.fill('#cf-name', 'تست تماس');
  await page.fill('#cf-phone', '+93 700 222 222');
  await page.fill('#cf-email', 'test@example.com');
  await page.selectOption('#cf-subject', { label: 'قطعات' });
  await page.fill('#cf-message', 'این یک پیام تست است.');
  await page.locator('form button[type="submit"]').click();
  await page.waitForTimeout(400);
  const sent = await page.evaluate(() => ({
    ok: document.body.textContent.includes('پیام ثبت شد'),
    rec: (() => { try { return JSON.parse(localStorage.getItem('shantui-contact-requests') || '[]'); } catch { return []; } })(),
  }));
  ok('submit → success state', sent.ok);
  ok('message recorded (subject+message+email)', sent.rec.length === 1 && sent.rec[0].subject === 'قطعات' && sent.rec[0].message.includes('تست') && sent.rec[0].email === 'test@example.com', JSON.stringify(sent.rec.map(r => r.subject)));

  // 7. office info rows
  const office = await page.evaluate(() => {
    const txt = document.body.textContent;
    return ['آدرس', 'ساعات کاری', 'شماره عمومی', 'واتساپ'].filter(x => txt.includes(x)).length + (txt.includes('شنبه–پنجشنبه') ? 1 : 0);
  });
  ok('office info rows (4 labels + hours)', office === 5, String(office));

  // 8. branch tabs + map switch
  const map = await page.evaluate(() => ({
    tabs: [...document.querySelectorAll('button')].filter(b => b.textContent.includes('کابل — دفتر مرکزی') || b.textContent.includes('مزار شریف — شعبه')).length,
    kabul: document.body.textContent.includes('ناحیه‌ی صنعتی'),
  }));
  ok('map: 2 branch tabs + kabul info', map.tabs === 2 && map.kabul, JSON.stringify(map));
  await page.locator('button', { hasText: 'مزار شریف' }).click();
  await page.waitForTimeout(300);
  const mazar = await page.evaluate(() => ({
    addr: document.body.textContent.includes('جاده‌ی اصلی'),
    hours: document.body.textContent.includes('۱۶:۳۰'),
    link: !!document.querySelector('a[href*="maps.google.com"]'),
  }));
  ok('switch to mazar updates card + external map link', mazar.addr && mazar.hours && mazar.link, JSON.stringify(mazar));

  // 9. CTA: quote opens sheet + parts link
  await page.locator('section[aria-labelledby="contact-cta-title"] button').click();
  await page.waitForTimeout(400);
  const sheet = await page.evaluate(() => {
    const fixed = [...document.querySelectorAll('div')].filter(d => getComputedStyle(d).position === 'fixed');
    return fixed.some(d => d.textContent.includes('درخواست قیمت') || d.textContent.includes('استعلام')) || !!document.querySelector('input[name="preset"], input');
  });
  ok('CTA quote button opens quote sheet', sheet);
  const partsLink = await page.evaluate(() => !!document.querySelector('a[href="#/fa/parts"]'));
  ok('CTA parts link', partsLink);

  ok('fa/contact: no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  await page.close();
}

// ---------- en/contact @390 ----------
{
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'en/contact', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 40)); }
    scrollTo(0, 0);
  });
  const mob = await page.evaluate(() => ({
    docW: document.documentElement.scrollWidth, vw: innerWidth,
    hero: document.body.textContent.includes('Get in touch'),
    tel: document.querySelectorAll('a[href^="tel:"]').length,
    form: !!document.querySelector('#cf-message'),
  }));
  ok('en/contact@390: no horizontal overflow', mob.docW <= mob.vw + 1, `${mob.docW} vs ${mob.vw}`);
  ok('en/contact@390: hero + links + form render', mob.hero && mob.tel >= 4 && mob.form);
  ok('en/contact@390: no console errors', errors.length === 0, errors.slice(0, 2).join(' | '));
  await page.close();
}

await browser.close();
console.log(`\n${pass} passed, ${fail} failed`);
if (findings.length) { console.log('FINDINGS:'); findings.forEach(f => console.log(' - ' + f)); process.exit(1); }
