# research/ — test & QA scripts

همه‌ی اسکریپت‌ها نیاز به سرور پیش‌نمایش دارند:

```bash
npm run build && npx vite preview --host 0.0.0.0 --port 5176 --strictPort
```

| اسکریپت | کار | تعداد بررسی |
|---------|-----|-------------|
| `audit.mjs` | ممیزی کامل همه‌ی صفحات (ساختار، لینک، کنتراست، tap-target) | ۲۴۱ |
| `smoke.mjs` | تست‌های سریع کل مسیرها + فرم‌ها | ۱۲۸ |
| `visual-audit.mjs` | ممیزی بصری رندرشده در ۴ عرض × ۲ زبان + کراول لینک + قاعده‌ی «بدون اسلب نارنجی» | ۴۴ بارگذاری |
| `qa-home.mjs` / `qa-about.mjs` / `qa-machinery.mjs` | تست‌های صفحه‌به‌صفحه | — |
| `qa-parts.mjs` | قطعات + صفحه‌ی جزئیات قطعه | ۲۶ |
| `qa-services.mjs` | خدمات + فورم سرویس | ۲۴ |
| `qa-news.mjs` | اخبار + رویدادها + جزئیات خبر | ۲۰ |
| `qa-contact.mjs` | تماس + نقشه + فورم | ۱۸ |
| `snap.mjs` | اسکرین‌شات: `node research/snap.mjs fa/services name 1440` | — |

اجراهای کامل: `node research/audit.mjs && node research/smoke.mjs && node research/qa-*.mjs`
