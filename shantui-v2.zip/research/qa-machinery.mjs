// ============================================================
// Machinery-page restructure — targeted rendered-geometry and
// interaction checks (toolbar, views, compare, project guide,
// detail-page parts). usage: node research/qa-machinery.mjs
// ============================================================
import { createRequire } from 'node:module';
const require = createRequire(new URL('.', import.meta.url));
const { chromium } = require('playwright');

const BASE = 'http://localhost:5176/#/';
let pass = 0, fail = 0; const findings = [];
const ok = (name, cond, note = '') => { cond ? pass++ : (fail++, findings.push(`${name} ${note}`)); console.log(`${cond ? 'PASS' : 'FAIL'} ${name}${note ? ' — ' + note : ''}`); };

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });

// ---------- fa/machinery @1440 ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'fa/machinery', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);

  // 1. hero 40–55vh
  const hero = await page.evaluate(() => {
    const h = document.querySelector('#mach-hero-title').closest('section').getBoundingClientRect();
    return Math.round(h.height / innerHeight * 100);
  });
  ok('hero 40–55vh', hero >= 40 && hero <= 55, hero + '%');

  // 2. toolbar: search + view toggle ONLY (no family chips — filtering lives in the strip)
  const toolbar = await page.evaluate(() => ({
    search: !!document.querySelector('input[type="search"]'),
    viewToggle: !!document.querySelector('[role="group"][aria-label="نمای گرید"]'),
    strayChips: document.querySelectorAll('.sticky button[aria-pressed]:not([aria-label*="نمای"])').length,
  }));
  ok('toolbar: search + view toggle', toolbar.search && toolbar.viewToggle, JSON.stringify(toolbar));
  ok('toolbar has no family chips (no duplication)', toolbar.strayChips === 0, String(toolbar.strayChips));

  // 3. family filter strip: "all" button + 6 image tiles
  const strip = await page.evaluate(() => ({
    imgs: document.querySelectorAll('a[href^="#/fa/machinery/"] img').length,
    allBtn: [...document.querySelectorAll('button[aria-pressed]')].some(b => b.textContent.includes('همه خانواده‌ها') && b.querySelector('svg')),
  }));
  ok('family strip = 6 image tiles', strip.imgs === 6, String(strip.imgs));
  ok('family strip has "all" option', strip.allBtn);

  // 4. product grid: 10 cards, statuses present
  const grid = await page.evaluate(() => {
    const cards = [...document.querySelectorAll('article')];
    const badges = ['موجود', 'قابل سفارش', 'تصدیق با نمایندگی'].filter(s => document.body.textContent.includes(s));
    const specRow = cards.filter(c => c.textContent.includes('توان')).length;
    return { n: cards.length, badges: badges.length, specRow };
  });
  ok('grid shows all 10 machines', grid.n === 10, String(grid.n));
  ok('all 3 status variants render', grid.badges === 3, JSON.stringify(grid.badges));
  ok('9 cards show key specs', grid.specRow === 9, String(grid.specRow));

  // 5. search filters live
  await page.fill('input[type="search"]', 'sd');
  await page.waitForTimeout(300);
  const filtered = await page.evaluate(() => document.querySelectorAll('article').length);
  ok('search "sd" → 3 dozers', filtered === 3, String(filtered));
  await page.fill('input[type="search"]', '');
  await page.waitForTimeout(300);

  // 6. family filter via image tile
  await page.locator('a[href$="/machinery/excavators"]').first().click();
  await page.waitForTimeout(600);
  const ex = await page.evaluate(() => document.querySelectorAll('article').length);
  ok('family tile filter → 2 excavators', ex === 2, String(ex));
  await page.locator('button[aria-pressed]', { hasText: 'همه خانواده‌ها' }).first().click();
  await page.waitForTimeout(600);
  const backAll = await page.evaluate(() => document.querySelectorAll('article').length);
  ok('"all" returns to 10 machines', backAll === 10, String(backAll));

  // 7. view toggle → list
  await page.locator('button[aria-label="نمای لیست"]').click();
  await page.waitForTimeout(300);
  const listView = await page.evaluate(() => {
    const a = document.querySelector('article');
    return a ? getComputedStyle(a).display : 'none';
  });
  ok('list view renders (flex row ≥900px)', listView === 'flex', listView);
  await page.locator('button[aria-label="نمای گرید"]').click();

  // 8. compare journey: add 2 → tray → compare page
  await page.evaluate(() => { sessionStorage.removeItem('shantui-compare'); });
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  const addBtn = async model => {
    const card = page.locator('article', { hasText: model }).first();
    await card.locator('button', { hasText: 'مقایسه' }).first().click();
  };
  await addBtn('SD22');
  await addBtn('SD16');
  await page.waitForTimeout(300);
  const tray = await page.evaluate(() => {
    const el = document.querySelector('[role="region"]');
    return { present: !!el, chips: el ? el.querySelectorAll('button[aria-label^="حذف"]').length : 0 };
  });
  ok('compare tray appears with 2 chips', tray.present && tray.chips === 2, JSON.stringify(tray));
  await page.locator('[role="region"] a', { hasText: 'مقایسه کن' }).click();
  await page.waitForTimeout(600);
  const cmp = await page.evaluate(() => ({
    h1: document.querySelector('h1')?.textContent || '',
    cards: document.querySelectorAll('article').length,
    specs: document.body.textContent.includes('162 kW') && document.body.textContent.includes('120 kW'),
    quoteAll: !!document.querySelector('button') && document.body.textContent.includes('استعلام برای این ماشین‌ها'),
  }));
  ok('compare page: 2 cards side by side', cmp.cards === 2, JSON.stringify(cmp));
  ok('compare page shows both specs', cmp.specs);
  ok('compare page has quote-all', cmp.quoteAll);
  await page.evaluate(() => { sessionStorage.removeItem('shantui-compare'); });

  ok('machinery fa: no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  await page.close();
}

// ---------- fa/models/sd22 (detail: specs + parts + similar) ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto(BASE + 'fa/models/sd22', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  const det = await page.evaluate(() => ({
    specs: document.body.textContent.includes('162 kW') && document.body.textContent.includes('23.6 t'),
    partsTitle: document.body.textContent.includes('قطعات این ماشین'),
    partImgs: [...document.querySelectorAll('img[src*="part-"]')].length,
    partLoaded: [...document.querySelectorAll('img[src*="part-"]')].every(i => i.complete && i.naturalWidth > 0),
    similar: document.body.textContent.includes('مدل‌های مشابه'),
    status: document.body.textContent.includes('موجود'),
  }));
  ok('detail: key specs in table', det.specs);
  ok('detail: parts-for-this-machine section', det.partsTitle && det.partImgs >= 3 && det.partLoaded, `${det.partImgs} imgs`);
  ok('detail: similar models section', det.similar);
  ok('detail: status badge', det.status);
  ok('detail: no console errors', errors.length === 0, errors.slice(0, 2).join(' | '));
  await page.close();
}

// ---------- fa/machinery @390 (mobile: sheet + overflow + tray) ----------
{
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto(BASE + 'fa/machinery', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 40)); }
    scrollTo(0, 0);
  });
  const mob = await page.evaluate(() => ({
    docW: document.documentElement.scrollWidth, vw: innerWidth,
    stripImgs: document.querySelectorAll('a[href^="#/fa/machinery/"] img').length,
    allBtn: [...document.querySelectorAll('button[aria-pressed]')].some(b => b.textContent.includes('همه خانواده‌ها') && b.querySelector('svg')),
  }));
  ok('mobile: no horizontal overflow', mob.docW <= mob.vw + 1, `${mob.docW} vs ${mob.vw}`);
  ok('mobile: filter strip visible (6 tiles + all)', mob.stripImgs === 6 && mob.allBtn, JSON.stringify(mob));
  ok('mobile: no console errors', errors.length === 0, errors.slice(0, 2).join(' | '));
  await page.close();
}

// ---------- en/machinery @1440 ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto(BASE + 'en/machinery', { waitUntil: 'networkidle' });
  await page.waitForTimeout(400);
  const en = await page.evaluate(() => ({
    hero: document.body.textContent.includes('SHANTUI machinery'),
    statuses: ['In stock', 'Orderable', 'Confirm with dealership'].filter(s => document.body.textContent.includes(s)).length,
    projects: document.body.textContent.includes('The right machine for your project'),
    cta: document.body.textContent.includes('Not sure which machine fits your project?'),
    docW: document.documentElement.scrollWidth,
  }));
  ok('en: hero + 3 statuses + projects + cta', en.hero && en.statuses === 3 && en.projects && en.cta, JSON.stringify(en));
  ok('en: no horizontal overflow', en.docW <= 1441, String(en.docW));
  ok('en: no console errors', errors.length === 0, errors.slice(0, 2).join(' | '));
  await page.close();
}

await browser.close();
console.log(`\n${pass} passed, ${fail} failed`);
if (findings.length) { console.log('FINDINGS:'); findings.forEach(f => console.log(' - ' + f)); process.exit(1); }
