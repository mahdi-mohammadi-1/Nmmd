// ============================================================
// About-page restructure — targeted rendered-geometry checks.
// usage: node research/qa-about.mjs
// ============================================================
import { createRequire } from 'node:module';
const require = createRequire(new URL('.', import.meta.url));
const { chromium } = require('playwright');

const BASE = 'http://localhost:5176/#/';
let pass = 0, fail = 0; const findings = [];
const ok = (name, cond, note = '') => { cond ? pass++ : (fail++, findings.push(`${name} ${note}`)); console.log(`${cond ? 'PASS' : 'FAIL'} ${name}${note ? ' — ' + note : ''}`); };

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });

// ---------- fa/about @1440 ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'fa/about', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 50)); }
    scrollTo(0, 0);
  });
  await page.waitForTimeout(400);

  // 1. hero height 45–65% of viewport + h1 visible below fixed header
  const hero = await page.evaluate(() => {
    const h = document.querySelector('#about-hero-title').closest('section');
    const r = h.getBoundingClientRect();
    const h1 = document.querySelector('#about-hero-title').getBoundingClientRect();
    const header = document.querySelector('header').getBoundingClientRect();
    return { h: Math.round(r.height), vh: innerHeight, h1Top: Math.round(h1.top), headerBottom: Math.round(header.bottom) };
  });
  ok('hero height 45–65vh', hero.h >= hero.vh * 0.45 && hero.h <= hero.vh * 0.65, `${hero.h}px of ${hero.vh}px`);
  ok('hero h1 below fixed header', hero.h1Top > hero.headerBottom, `h1 ${hero.h1Top} vs header ${hero.headerBottom}`);

  // 2. section order via heading positions
  const order = await page.evaluate(() => {
    const find = txt => [...document.querySelectorAll('h1,h2')].find(el => el.textContent.includes(txt));
    const marks = [['hero', '#about-hero-title'], ['global', 'SHANTUI کیست؟'], ['af', 'SHANTUI در افغانستان'], ['caps', 'توانمندی‌های ما'], ['mv', 'مأموریت و دیدگاه'], ['team', 'تیم ما'], ['fac', 'حضور و امکانات'], ['cta', '#about-cta-title']];
    const out = {};
    for (const [k, sel] of marks) {
      const el = sel.startsWith('#') ? document.querySelector(sel) : find(sel);
      if (el) out[k] = Math.round(el.getBoundingClientRect().top + scrollY);
    }
    return out;
  });
  const seq = ['hero', 'global', 'af', 'caps', 'mv', 'team', 'fac', 'cta'];
  let mono = seq.every(k => order[k] !== undefined);
  for (let i = 1; i < seq.length; i++) if (order[seq[i - 1]] >= order[seq[i]]) mono = false;
  ok('section order hero→global→af→caps→mv→team→fac→cta', mono, JSON.stringify(order));

  // 3. global facts: 3 stat cards with the verified numbers
  const facts = await page.evaluate(() => [...document.querySelectorAll('.yard-card')].filter(c => /۱۹۸۰|1980/.test(c.textContent)).length);
  ok('global facts render (1980 present)', facts >= 1, String(facts));

  // 4. capabilities: 5 link cards, all navigate to real routes
  const caps = await page.evaluate(() => {
    const links = [...document.querySelectorAll('a[href*="#/"]')].filter(a => a.querySelector('svg') && a.textContent.includes('باز کردن صفحه'));
    return { n: links.length, hrefs: links.map(l => l.getAttribute('href')) };
  });
  ok('capabilities = 5 link cards', caps.n === 5, String(caps.n));
  ok('capability links valid routes', caps.n === 5 && caps.hrefs.every(h => /#\/(fa|en)\/(machinery|parts|services|contact)$/.test(h)), caps.hrefs.join(' '));

  // 5. values: 5 chips
  const values = await page.evaluate(() => ['کیفیت', 'صداقت در معامله', 'پشتیبانی تخنیکی', 'مسئولیت‌پذیری', 'همکاری درازمدت'].filter(v => document.body.textContent.includes(v)).length);
  ok('5 working values present', values === 5, `${values}/5`);

  // 6. team: 3 cards, photos loaded, demo label
  const team = await page.evaluate(() => {
    const imgs = [...document.querySelectorAll('img[src*="team-"]')];
    return { n: imgs.length, loaded: imgs.every(i => i.complete && i.naturalWidth > 0), demo: document.body.textContent.includes('تیم نمونه') };
  });
  ok('team = 3 photos, loaded', team.n === 3 && team.loaded, JSON.stringify(team));
  ok('team demo label visible', team.demo);

  // 7. facilities: 4 images loaded + illustrative label
  const fac = await page.evaluate(() => {
    const imgs = [...document.querySelectorAll('img[src*="facility-"], img[src*="showroom"]')];
    return { n: imgs.length, loaded: imgs.every(i => i.complete && i.naturalWidth > 0), demo: document.body.textContent.includes('تصاویر نمایشی') };
  });
  ok('facilities = 4 images, loaded', fac.n === 4 && fac.loaded, JSON.stringify(fac));
  ok('facilities demo label visible', fac.demo);

  // 8. CTA: quote button + contact link
  const cta = await page.evaluate(() => {
    const btns = [...document.querySelectorAll('#about-cta-title ~ * button, section[aria-labelledby="about-cta-title"] button, section[aria-labelledby="about-cta-title"] a')];
    return { n: btns.length, hasContact: btns.some(b => b.getAttribute('href')?.includes('/contact')) };
  });
  ok('CTA has 2 actions incl. contact', cta.n === 2 && cta.hasContact, JSON.stringify(cta));

  // 9. quote sheet opens from about
  await page.locator('section[aria-labelledby="about-cta-title"] button').first().click();
  await page.waitForTimeout(400);
  const sheet = await page.evaluate(() => !!document.querySelector('input, form, [role="dialog"]'));
  ok('quote sheet opens from about CTA', sheet);
  await page.keyboard.press('Escape');

  ok('about fa: no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  await page.close();
}

// ---------- en/about @390 (mobile) ----------
{
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'en/about', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 50)); }
    scrollTo(0, 0);
  });
  const mob = await page.evaluate(() => ({
    docW: document.documentElement.scrollWidth, vw: innerWidth,
    teamImgs: [...document.querySelectorAll('img[src*="team-"]')].every(i => i.complete && i.naturalWidth > 0),
    facImgs: [...document.querySelectorAll('img[src*="facility-"], img[src*="showroom"]')].every(i => i.complete && i.naturalWidth > 0),
  }));
  ok('en/about@390: no horizontal overflow', mob.docW <= mob.vw + 1, `${mob.docW} vs ${mob.vw}`);
  ok('en/about@390: team + facility images load', mob.teamImgs && mob.facImgs);
  ok('en/about@390: no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  await page.close();
}

await browser.close();
console.log(`\n${pass} passed, ${fail} failed`);
if (findings.length) { console.log('FINDINGS:'); findings.forEach(f => console.log(' - ' + f)); process.exit(1); }
