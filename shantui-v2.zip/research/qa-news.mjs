// ============================================================
// v2.17 — news-page rebuild: targeted rendered checks.
// usage: node research/qa-news.mjs
// ============================================================
import { createRequire } from 'node:module';
const require = createRequire(new URL('.', import.meta.url));
const { chromium } = require('playwright');

const BASE = 'http://localhost:5176/#/';
let pass = 0, fail = 0; const findings = [];
const ok = (name, cond, note = '') => { cond ? pass++ : (fail++, findings.push(name)); console.log(`${cond ? 'PASS' : 'FAIL'} ${name}${note ? ' — ' + note : ''}`); };

const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome' });

// ---------- fa/news @1440 ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'fa/news', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 40)); }
    scrollTo(0, 0);
  });
  await page.waitForTimeout(400);

  // 1. short hero renders
  ok('hero title renders', await page.locator('h1', { hasText: 'اخبار و رویدادها' }).count() >= 1);

  // 2. featured split card: image + cat + date + title + summary + read-more link
  const feat = await page.evaluate(() => {
    const a = document.querySelector('a[href="#/fa/news/season-prep"]');
    if (!a) return null;
    const img = a.querySelector('img');
    return {
      img: img ? img.complete && img.naturalWidth > 0 : false,
      cat: a.textContent.includes('راهنما'),
      date: a.textContent.includes('۱۸ شهور ۱۴۰۵'),
      title: a.textContent.includes('آماده‌سازی ناوگان'),
      read: a.textContent.includes('بیشتر بخوانید'),
      split: getComputedStyle(a).display === 'grid',
    };
  });
  ok('featured: split card + image + meta + CTA', !!feat && feat.img && feat.cat && feat.date && feat.title && feat.read && feat.split, JSON.stringify(feat));

  // 3. grid: 6 cards initially, all images load, links to detail
  const grid = await page.evaluate(() => ({
    links: [...document.querySelectorAll('a[href^="#/fa/news/"]')].filter(a => a.className.includes('yard-card')).length,
    imgs: [...document.querySelectorAll('main img, body img')].filter(i => i.src.includes('/images/')).every(i => i.complete && i.naturalWidth > 0),
  }));
  ok('grid: featured + 6 = 7 detail-linked cards', grid.links === 7, String(grid.links));
  ok('all visible images load', grid.imgs);

  // 4. load more reveals 3, then allLoaded note
  const moreBtn = await page.locator('button', { hasText: 'نمایش خبرهای بیشتر' }).count();
  ok('load-more button present with count', moreBtn === 1);
  await page.locator('button', { hasText: 'نمایش خبرهای بیشتر' }).click();
  await page.waitForTimeout(400);
  const after = await page.evaluate(() => ({
    links: [...document.querySelectorAll('a[href^="#/fa/news/"]')].filter(a => a.className.includes('yard-card')).length,
    done: document.body.textContent.includes('فعلاً همین‌قدر داریم'),
    btn: [...document.querySelectorAll('button')].some(b => b.textContent.includes('نمایش خبرهای بیشتر')),
  }));
  ok('after load-more: featured + 9 = 10 cards, no button, allLoaded note', after.links === 10 && !after.btn && after.done, JSON.stringify(after));

  // 5. events timeline: 5 items with kind/date/place
  const ev = await page.evaluate(() => {
    const txt = document.body.textContent;
    return {
      kinds: ['نمایشگاه', 'روز باز', 'آموزش', 'معرفی محصول', 'برنامه‌ی مشتریان'].filter(k => txt.includes(k)).length,
      dates: ['۱۰ عقرب ۱۴۰۵', '۲۵ عقرب ۱۴۰۵', '۱۰ قوس ۱۴۰۵', '۲۰ قوس ۱۴۰۵', '۵ جدی ۱۴۰۵'].filter(d => txt.includes(d)).length,
      samples: [...document.querySelectorAll('span')].filter(s => s.textContent.trim() === 'نمونه').length,
    };
  });
  ok('events: 5 kinds + 5 dates', ev.kinds === 5 && ev.dates === 5, JSON.stringify(ev));
  ok('sample chips on every card + event', ev.samples >= 14, String(ev.samples));

  // 6. short CTA + contact link
  const cta = await page.evaluate(() => ({
    title: document.body.textContent.includes('فعالیت‌های شانتویی افغانستان را دنبال کنید'),
    link: !!document.querySelector('a[href="#/fa/contact"]'),
  }));
  ok('CTA band + contact link', cta.title && cta.link);

  ok('fa/news: no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  await page.close();
}

// ---------- fa/news/season-prep detail @1440 ----------
{
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'fa/news/season-prep', { waitUntil: 'networkidle' });
  await page.waitForTimeout(600);
  const d = await page.evaluate(() => ({
    back: !!document.querySelector('a[href="#/fa/news"]'),
    title: document.body.textContent.includes('آماده‌سازی ناوگان برای فصل ساخت‌وساز'),
    date: document.body.textContent.includes('۱۸ شهور ۱۴۰۵'),
    paras: [...document.querySelectorAll('p')].filter(p => p.textContent.includes('قدم اول مایعات') || p.textContent.includes('قدم دوم زیرسازی') || p.textContent.includes('در آخر اسناد را مرتب')).length,
    img: (() => { const i = document.querySelector('img[src*="news-road"]'); return i ? i.complete && i.naturalWidth > 0 : false; })(),
    demo: document.body.textContent.includes('تصویر نمایشی'),
    related: [...document.querySelectorAll('a[href^="#/fa/news/"]')].filter(a => a.className.includes('yard-card')).length,
  }));
  ok('detail: back link + title + date', d.back && d.title && d.date);
  ok('detail: 3 body paragraphs render', d.paras === 3, String(d.paras));
  ok('detail: image + demo label', d.img && d.demo);
  ok('detail: 3 related cards', d.related === 3, String(d.related));
  // related card click navigates to another detail
  await page.locator('a[href="#/fa/news/hour-250"]').first().click();
  await page.waitForTimeout(500);
  ok('related card navigates to hour-250 detail', await page.evaluate(() => document.body.textContent.includes('چک‌لیست سرویس ۲۵۰ ساعته')));
  ok('detail: no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  await page.close();
}

// ---------- home regression + en/news @390 ----------
{
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  await page.goto(BASE + 'en/news', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.evaluate(async () => {
    for (let y = 0; y <= document.body.scrollHeight; y += 700) { scrollTo(0, y); await new Promise(r => setTimeout(r, 40)); }
    scrollTo(0, 0);
  });
  const mob = await page.evaluate(() => ({
    docW: document.documentElement.scrollWidth, vw: innerWidth,
    title: document.body.textContent.includes('News & events'),
    feat: !!document.querySelector('a[href="#/en/news/season-prep"]'),
  }));
  ok('en/news@390: no horizontal overflow', mob.docW <= mob.vw + 1, `${mob.docW} vs ${mob.vw}`);
  ok('en/news@390: hero + featured render', mob.title && mob.feat);

  // home regression: news section still renders with new keys
  await page.goto(BASE + 'en', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  const home = await page.evaluate(() => ({
    big: document.body.textContent.includes('Preparing your fleet'),
    small: document.body.textContent.includes('The 250-hour service checklist'),
    links: [...document.querySelectorAll('a[href^="#/en/news/"]')].length,
  }));
  ok('home: news preview renders (big + 2 small)', home.big && home.small && home.links >= 3, JSON.stringify(home));
  ok('en@390 + home: no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));
  await page.close();
}

await browser.close();
console.log(`\n${pass} passed, ${fail} failed`);
if (findings.length) { console.log('FINDINGS:'); findings.forEach(f => console.log(' - ' + f)); process.exit(1); }
