# SHANTUI Afghanistan — v2 (from-scratch rebuild)

بازسازی کامل سایت نمایندگی شانتویی افغانستان — نوشته‌شده از صفر، سپتمبر ۲۰۲۶.
Complete from-scratch rebuild of the Shantui Afghanistan dealership site.

## اجرا / Run

```bash
npm install
npm run dev        # سرور توسعه / dev server
npm run build      # بیلد تولیدی / production build
npm run smoke      # تست مرورگری / browser smoke suite (needs Chromium)
```

## معماری / Architecture

```
src/
  main.jsx            — پوسته‌ی اپ: روتر، زبان، داک، شیت استعلام
  app.css             — توکن‌های طراحی «Orange Yard» + انیمیشن‌ها
  lib/content.js      — دیتای ماشین‌آلات + متن دو زبانه (دری/EN)
  lib/router.js       — روتر هش سبک + revealer اسکرول
  ui/kit.jsx          — آیکون‌ها، MachinePhoto، دکمه‌ها، Ticker، Dock، QuoteSheet
  layout/chrome.jsx   — هدر شیشه‌ای + فوتر
  home/sections.jsx   — بخش‌های صفحه‌ی اصلی
  pages/all.jsx       — همه‌ی صفحات داخلی
research/smoke.mjs    — ۱۶۴ چک: ۱۳ مسیر × ۲ زبان + سفرهای کاربری
```

## قواعد محتوا / Content rules

دیتای نمونه صادقانه است — هیچ مشخصات، موجودی، تماس یا بروشور ساختگی.
تمام درخواست‌ها فقط محلی ثبت می‌شوند (بدون بک‌اند).
