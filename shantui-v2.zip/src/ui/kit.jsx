import React, { useEffect, useState } from 'react';
import { img, products, copy, cat } from '../lib/content';

// ============================================================
// v2 UI kit — built from scratch. Icon set (stroke style),
// machine photo frame, buttons, section head, ticker, dock,
// quote sheet. Everything composes the "Orange Yard" language.
// ============================================================

const PATHS = {
  home: 'M4 11.5 12 4l8 7.5M6.5 10v9h11v-9',
  machine: 'M4 17h16M7 17v-5l3-4h6l3 4v5M10 8V5h5v3',
  parts: 'M12 3v4M12 17v4M5 12H3M21 12h-2M7 7 5.5 5.5M17 7l1.5-1.5M7 17l-1.5 1.5M17 17l1.5 1.5M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z',
  tool: 'M14.5 6.5a4 4 0 0 0-5.6 4.7L4 16v4h4l4.8-4.9a4 4 0 0 0 4.7-5.6l-2.6 2.6-2.5-.5-.5-2.5 2.6-2.6Z',
  grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
  pin: 'M12 21s7-5.5 7-11a7 7 0 1 0-14 0c0 5.5 7 11 7 11ZM12 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z',
  arrow: 'M4 12h15M13 5l7 7-7 7',
  diagonal: 'M7 17 17 7M9 7h8v8',
  document: 'M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h6',
  check: 'M4 12.5 9.5 18 20 6.5',
  plus: 'M12 5v14M5 12h14',
  close: 'M6 6l12 12M18 6 6 18',
  info: 'M12 8h.01M11 12h1v5h1M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z',
  calendar: 'M5 5h14v16H5zM8 3v4M16 3v4M5 10h14M10 14h.01M14 14h.01M10 17h.01M14 17h.01',
  phone: 'M5 4h4l2 5-2.5 1.5a11.5 11.5 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A17 17 0 0 1 3 6a2 2 0 0 1 2-2Z',
  mail: 'M4 6h16v12H4zM4.5 7l7.5 5.5L19.5 7',
  search: 'M10.5 4a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13ZM15.5 15.5 21 21',
  truck: 'M3 7h10v9H3zM13 10h4l3 3v3h-7M6.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM16.5 19a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z',
  shield: 'M12 3 5 6v5c0 4.5 3 8.2 7 10 4-1.8 7-5.5 7-10V6l-7-3ZM9 12l2 2 4-4.5',
  telegram: 'M21.5 4.5 3.5 11.3c-1 .4-1 1.8.1 2.1l4.5 1.4 1.7 5.3c.3.9 1.4 1 2 .3l2.4-2.6 4.7 3.4c.8.6 1.9.2 2.1-.8l2.7-14c.2-1.1-.9-2-1.9-1.6Z',
  instagram: 'M7.5 3.5h9a4 4 0 0 1 4 4v9a4 4 0 0 1-4 4h-9a4 4 0 0 1-4-4v-9a4 4 0 0 1 4-4Z M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z M16.8 7.3h.01',
  whatsapp: 'M12 3.5a8.5 8.5 0 0 0-7.3 12.8L3.5 20.5l4.3-1.1A8.5 8.5 0 1 0 12 3.5Z M8.8 8h.9l.9 2.2-.9 1a6.8 6.8 0 0 0 3.2 3.2l1-.9 2.2.9v.9c0 .8-.6 1.4-1.4 1.4A8.4 8.4 0 0 1 7.4 9.4c0-.8.6-1.4 1.4-1.4Z',
};

export function Icon({ name, size = 18, className = '' }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className} style={{ width: size, height: size, flexShrink: 0 }}><path d={PATHS[name] || PATHS.arrow} /></svg>;
}

// Machine photo on an engineering grid plate — the v2 stage.
export function MachinePhoto({ name, alt, size = '', eager = false, className = '' }) {
  return (
    <div className={`grid-plate relative overflow-hidden rounded-2xl ${className}`}>
      <img
        src={img(name, size)} alt={alt} loading={eager ? 'eager' : 'lazy'}
        width="880" height="560" decoding="async"
        className="relative z-10 h-full w-full object-contain"
      />
    </div>
  );
}

export function BtnPrimary({ children, onClick, href: link, className = '', submit = false }) {
  const cls = `cta-arrow inline-flex min-h-12 items-center gap-3 rounded-full bg-brand px-6 text-sm font-extrabold tracking-wide text-deep transition-all hover:bg-brandhot hover:shadow-[0_12px_36px_-10px_rgba(255,95,0,.55)] active:scale-[.98] ${className}`;
  return link
    ? <a href={link} className={cls}>{children}<Icon name="arrow" className="directional" /></a>
    : <button type={submit ? 'submit' : 'button'} onClick={onClick} className={cls}>{children}<Icon name="arrow" className="directional" /></button>;
}

export function BtnGhost({ children, onClick, href: link, className = '' }) {
  const cls = `inline-flex min-h-12 items-center gap-3 rounded-full border border-bone/20 px-6 text-sm font-bold text-bone/90 transition-colors hover:border-brand hover:text-brand ${className}`;
  return link ? <a href={link} className={cls}>{children}</a> : <button type="button" onClick={onClick} className={cls}>{children}</button>;
}

export function SectionHead({ eyebrow, title, body, children }) {
  return (
    <div className="io grid items-end gap-6 pb-10 md:grid-cols-[1.4fr_1fr] md:pb-14">
      <div>
        <p className="flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.22em] text-brand"><span aria-hidden="true" className="sweep h-[3px] w-9 origin-left rounded-full" />{eyebrow}</p>
        <h2 className="mt-4 font-display text-4xl font-extrabold leading-[1.02] tracking-tight text-bone md:text-5xl">{title}</h2>
      </div>
      <div>
        {body && <p className="max-w-md text-sm leading-relaxed text-muted md:text-[15px]">{body}</p>}
        {children}
      </div>
    </div>
  );
}

export function Shell({ children, tone = 'ink' }) {
  return <section className={`${tone === 'raised' ? 'bg-raised' : 'bg-ink'} py-16 md:py-24`}><div className="mx-auto max-w-(--container-yard) px-5 md:px-10">{children}</div></section>;
}

// Quote sheet — a bottom sheet on mobile, a card on desktop.
// Records locally only; no network. Fully honest preview behaviour.
export function QuoteSheet({ open, onClose, lang, t, presetMachine }) {
  const c = copy[lang];
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', machine: presetMachine || '', message: '' });
  const [errors, setErrors] = useState({});
  useEffect(() => { if (open) { setSent(false); setForm(f => ({ ...f, machine: presetMachine || f.machine })); setErrors({}); } }, [open, presetMachine]);
  useEffect(() => {
    const onKey = e => e.key === 'Escape' && onClose();
    if (open) addEventListener('keydown', onKey);
    return () => removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));
  const submit = e => {
    e.preventDefault();
    const errs = {};
    if (!form.name.trim()) errs.name = t.quote.required;
    if (!form.phone.trim()) errs.phone = t.quote.required;
    setErrors(errs);
    if (Object.keys(errs).length === 0) setSent(true);
  };
  const field = (k, label, type = 'text', textarea = false) => (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold text-muted">{label}</span>
      {textarea
        ? <textarea rows="3" value={form[k]} onChange={set(k)} className="w-full rounded-2xl border border-cardline bg-raised px-4 py-3 text-sm text-bone placeholder:text-muted/50 focus:border-brand focus:outline-none" />
        : <input type={type} value={form[k]} onChange={set(k)} className="w-full min-h-12 rounded-2xl border border-cardline bg-raised px-4 text-sm text-bone placeholder:text-muted/50 focus:border-brand focus:outline-none" />}
      {errors[k] && <span role="alert" className="mt-1 block text-xs font-bold text-brandhot">{errors[k]}</span>}
    </label>
  );
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center" role="dialog" aria-modal="true" aria-label={t.quote.title}>
      <div aria-hidden="true" onClick={onClose} className="absolute inset-0 bg-deep/55 backdrop-blur-sm" />
      <div className="pop relative w-full max-w-lg rounded-t-[2rem] border border-cardline bg-card p-6 shadow-2xl sm:rounded-[2rem] sm:p-8">
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-brand">{c.hero.eyebrow}</p>
            <h2 className="mt-2 font-display text-2xl font-extrabold tracking-tight">{t.quote.title}</h2>
          </div>
          <button onClick={onClose} aria-label={t.common.close} className="grid size-11 shrink-0 place-items-center rounded-full border border-cardline text-muted transition-colors hover:border-brand hover:text-brand"><Icon name="close" /></button>
        </div>
        {sent ? (
          <div className="rounded-2xl border border-cardline bg-raised p-5" role="status">
            <p className="flex items-center gap-2 font-display text-lg font-extrabold text-brand"><Icon name="check" />{t.quote.sent}</p>
            <p className="mt-2 text-sm leading-relaxed text-muted">{t.quote.sentBody}</p>
            <div className="mt-4 flex gap-3">
              <BtnPrimary onClick={() => setSent(false)}>{t.quote.edit}</BtnPrimary>
              <BtnGhost onClick={onClose}>{t.quote.done}</BtnGhost>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} noValidate className="grid gap-4">
            {field('name', t.quote.name)}
            {field('phone', t.quote.phone, 'tel')}
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold text-muted">{t.quote.machine}</span>
              <select value={form.machine} onChange={set('machine')} className="w-full min-h-12 rounded-2xl border border-cardline bg-raised px-4 text-sm text-bone focus:border-brand focus:outline-none">
                <option value="">{t.quote.pick}</option>
                {products.map(p => <option key={p.id} value={p.model || '—'}>{p.model || cat(p.category).label[lang]}</option>)}
              </select>
            </label>
            {field('message', t.quote.message, 'text', true)}
            <p className="flex items-center gap-2 text-[11px] leading-relaxed text-muted/80"><Icon name="info" size={14} />{t.quote.body}</p>
            <BtnPrimary submit className="mt-1 w-full justify-center">{t.quote.send}</BtnPrimary>
          </form>
        )}
      </div>
    </div>
  );
}

// ============================================================
// v2.20 — unified quiet CTA band (dark, brand accent only).
// Replaces the old full-orange slabs: one consistent ending
// for every page; the hazard stripe lives on the footer only.
// ============================================================
export const CTA_PRIMARY = 'cta-arrow inline-flex min-h-12 items-center gap-3 rounded-full bg-brand px-6 text-sm font-extrabold text-deep transition-all hover:bg-brandhot active:scale-[.98]';
export const CTA_GHOST = 'inline-flex min-h-12 items-center gap-3 rounded-full border-2 border-white/25 px-5 text-xs font-extrabold text-white transition-colors hover:border-white hover:bg-white hover:text-deep';

export function CtaBand({ id, title, body, children, watermark }) {
  return (
    <section className="relative overflow-hidden bg-deep text-white" aria-labelledby={id}>
      {watermark && (
        <span aria-hidden="true" className="pointer-events-none absolute -bottom-8 end-0 hidden select-none font-display text-[140px] font-extrabold leading-none tracking-tighter text-white/[.05] md:block">{watermark}</span>
      )}
      <div className="relative mx-auto flex max-w-(--container-yard) flex-wrap items-center justify-between gap-6 px-5 py-12 md:px-10 md:py-14">
        <div className="min-w-0">
          <span aria-hidden="true" className="mb-4 block h-[3px] w-10 rounded-full bg-brand" />
          <h2 id={id} className="max-w-xl font-display text-2xl font-extrabold leading-[1.1] tracking-tight md:text-3xl">{title}</h2>
          {body && <p className="mt-2.5 max-w-lg text-sm leading-relaxed text-white/70">{body}</p>}
        </div>
        <div className="flex flex-wrap gap-4">{children}</div>
      </div>
    </section>
  );
}
