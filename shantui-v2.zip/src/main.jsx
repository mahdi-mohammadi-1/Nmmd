import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource/barlow-semi-condensed/600.css';
import '@fontsource/barlow-semi-condensed/700.css';
import '@fontsource/barlow-semi-condensed/800.css';
import '@fontsource/noto-sans-arabic/400.css';
import '@fontsource/noto-sans-arabic/700.css';
import './app.css';

import { useRoute, installRevealer } from './lib/router';
import { copy } from './lib/content';
import { Header, Footer } from './layout/chrome';
import { QuoteSheet } from './ui/kit';
import { Hero, ProductStream, CategoryTiles, AboutBrief, PartsFinder, ServicesGrid, NewsAsym, Gallery, Testimonials, Finale } from './home/sections';
import { Catalog } from './pages/catalog';
import { Product } from './pages/product';
import { ComparePage } from './pages/compare';
import { Contact } from './pages/contact';
import { NotFound } from './pages/shared';
import { PartsPage } from './pages/parts';
import { ServicesPage } from './pages/services';
import { AboutPage } from './pages/about';
import { NewsPage } from './pages/news';

// ============================================================
// SHANTUI AFGHANISTAN v2.3 — 7-page structure (user-defined):
// home · about · machinery (+detail) · parts · services · news · contact
// Single floating pill header (dock style), no bottom dock.
// ============================================================

const TITLES = {
  home: { en: 'SHANTUI Afghanistan — Heavy Machinery Yard', fa: 'شانتویی افغانستان — کارگاه ماشین‌آلات سنگین' },
  about: { en: 'About us — SHANTUI Afghanistan', fa: 'درباره ما — شانتویی افغانستان' },
  machinery: { en: 'Our machinery — SHANTUI Afghanistan', fa: 'ماشین‌آلات ما — شانتویی افغانستان' },
  compare: { en: 'Compare machines — SHANTUI Afghanistan', fa: 'مقایسه‌ی ماشین‌آلات — شانتویی افغانستان' },
  models: { en: 'Machine — SHANTUI Afghanistan', fa: 'ماشین — شانتویی افغانستان' },
  parts: { en: 'Machine parts — SHANTUI Afghanistan', fa: 'قطعات ماشین‌ها — شانتویی افغانستان' },
  services: { en: 'Services — SHANTUI Afghanistan', fa: 'خدمات — شانتویی افغانستان' },
  news: { en: 'News — SHANTUI Afghanistan', fa: 'اخبار — شانتویی افغانستان' },
  contact: { en: 'Contact us — SHANTUI Afghanistan', fa: 'تماس با ما — شانتویی افغانستان' },
};

function App() {
  const [route] = useRoute();
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [preset, setPreset] = useState('');
  const t = copy[route.lang];
  const rtl = route.lang === 'fa';

  useEffect(() => {
    document.documentElement.lang = rtl ? 'fa-AF' : 'en';
    document.documentElement.dir = rtl ? 'rtl' : 'ltr';
    document.title = (TITLES[route.page] || TITLES.home)[route.lang];
  }, [route.lang, route.page, rtl]);

  useEffect(() => {
    const scan = installRevealer();
    const id = setInterval(scan, 900);
    return () => clearInterval(id);
  }, [route.path]);

  const onQuote = machine => { setPreset(machine || ''); setQuoteOpen(true); };
  const switchLang = () => { location.hash = `/${route.lang === 'en' ? 'fa' : 'en'}/${route.page}${route.param ? `/${route.param}` : ''}`; };

  const page = useMemo(() => {
    switch (route.page) {
      case 'machinery': return <Catalog key={route.path} lang={route.lang} t={t} route={route} onQuote={onQuote} />;
      case 'compare': return <ComparePage key={route.path} lang={route.lang} t={t} onQuote={onQuote} />;
      case 'models': return <Product key={route.path} lang={route.lang} t={t} route={route} onQuote={onQuote} />;
      case 'parts': return <PartsPage key={route.path} lang={route.lang} t={t} onQuote={onQuote} route={route} />;
      case 'services': return <ServicesPage key={route.path} lang={route.lang} t={t} onQuote={onQuote} />;
      case 'about': return <AboutPage key={route.path} lang={route.lang} t={t} onQuote={onQuote} />;
      case 'news': return <NewsPage key={route.path} lang={route.lang} t={t} onQuote={onQuote} route={route} />;
      case 'contact': return <Contact lang={route.lang} t={t} onQuote={onQuote} />;
      case 'home':
        return (
          <>
            <Hero lang={route.lang} t={t} onQuote={onQuote} />
            <ProductStream lang={route.lang} t={t} onQuote={onQuote} />
            <CategoryTiles lang={route.lang} t={t} />
            <AboutBrief lang={route.lang} t={t} />
            <PartsFinder lang={route.lang} t={t} onQuote={onQuote} />
            <ServicesGrid lang={route.lang} t={t} />
            <NewsAsym lang={route.lang} t={t} />
            <Gallery lang={route.lang} t={t} />
            <Testimonials lang={route.lang} t={t} />
            <Finale lang={route.lang} t={t} onQuote={onQuote} />
          </>
        );
      default: return <NotFound lang={route.lang} t={t} />;
    }
  }, [route, t]);

  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-brand focus:px-5 focus:py-3 focus:text-sm focus:font-extrabold focus:text-deep">{t.common.menu}</a>
      <Header route={route} t={t} onQuote={() => onQuote('')} onSwitchLang={switchLang} />
      {/* home hero sits under the fixed overlay header; other pages pad below it */}
      <main id="main" className={route.page === 'home' ? '' : 'pt-[104px]'}>{page}</main>
      <Footer lang={route.lang} t={t} />
      <QuoteSheet open={quoteOpen} onClose={() => setQuoteOpen(false)} lang={route.lang} t={t} presetMachine={preset} />
    </>
  );
}

createRoot(document.getElementById('root')).render(<App />);
