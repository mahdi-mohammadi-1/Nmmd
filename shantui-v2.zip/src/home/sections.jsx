import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, img, servicesList, newsList, partsList, partsGroups, galleryList } from '../lib/content';

// ============================================================
// v2.9 home — user-defined structure (2026-09-23):
// Hero(video) → Products+Filter → Categories → About(brief)
// → Parts(finder) → Services(4) → News(1+2) → Gallery(masonry)
// → Testimonials(demo) → Finale CTA.
// ============================================================

export function Hero({ lang, t, onQuote }) {
  // Full-bleed background video; the file is user-supplied
  // (public/videos/hero.mp4|.webm). Until then the reference photo
  // animates with a slow Ken Burns drift.
  const words = (text, off = 0) => String(text).split(' ').map((w, j) => <span key={j} style={{ '--i': off + j }}>{w}{'\u00A0'}</span>);
  const countA = String(t.hero.titleA).split(' ').length;
  const [video, setVideo] = useState(null);
  useEffect(() => {
    let alive = true;
    (async () => {
      for (const src of ['/videos/hero.mp4', '/videos/hero.webm']) {
        try {
          const r = await fetch(src, { method: 'HEAD' });
          const type = r.headers.get('content-type') || '';
          if (r.ok && type.startsWith('video/')) { if (alive) setVideo(src); return; }
        } catch { /* keep probing */ }
      }
      if (alive) setVideo('');
    })();
    return () => { alive = false; };
  }, []);
  return (
    <section className="relative flex min-h-[92svh] items-end overflow-hidden bg-deep text-white" aria-labelledby="hero-title">
      {video ? (
        <video key={video} src={video} autoPlay muted loop playsInline aria-hidden="true" onError={() => setVideo('')} className="absolute inset-0 h-full w-full object-cover" />
      ) : (
        <img src={img('hero')} alt="" aria-hidden="true" width="1920" height="1080" className="kenburns absolute inset-0 h-full w-full object-cover" />
      )}
      <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/95 via-deep/40 to-deep/25" />
      <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-b from-deep/60 via-transparent to-transparent" />
      <div className="relative mx-auto w-full max-w-(--container-yard) px-5 pb-16 pt-40 md:px-10 md:pb-20">
        <p className="pop flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.24em] text-brand" style={{ '--d': '0ms' }}>
          <span aria-hidden="true" className="sweep h-[3px] w-10 rounded-full bg-brand" />{t.hero.eyebrow}
        </p>
        <h1 id="hero-title" className="word mt-6 font-display font-extrabold leading-[1.02] tracking-tight">
          <span className="block text-[clamp(1.75rem,8vw,5rem)] text-white">{words(t.hero.titleA)}</span>
          <span className="block text-[clamp(1.75rem,8vw,5rem)] text-brand">{words(t.hero.titleB, countA)}</span>
        </h1>
        <p className="pop mt-6 max-w-xl text-sm leading-relaxed text-white/85 md:text-base" style={{ '--d': '300ms' }}>{t.hero.body}</p>
        <div className="pop mt-8 flex flex-wrap items-center gap-4" style={{ '--d': '420ms' }}>
          <button type="button" onClick={() => onQuote('')} className="cta-arrow inline-flex min-h-14 items-center gap-4 rounded-full bg-brand px-8 text-sm font-extrabold text-deep transition-all hover:bg-brandhot hover:shadow-[0_14px_44px_-12px_rgba(255,95,0,.7)] active:scale-[.98]">
            {t.hero.quote}<Icon name="arrow" className="directional" />
          </button>
          <a href={`#/${lang}/machinery`} className="inline-flex min-h-14 items-center gap-3 rounded-full border-2 border-white/45 px-7 text-sm font-extrabold text-white transition-colors hover:border-white hover:bg-white hover:text-deep">
            {t.hero.machines}<Icon name="machine" size={18} />
          </a>
        </div>
        <p className="mt-8 flex items-center gap-2 text-[11px] tracking-wide text-white/50"><Icon name="info" size={14} />{t.hero.note}</p>
      </div>
    </section>
  );
}

// ---------- 2. SHANTUI machinery + filter (max 8 on home) ----------
export function ProductStream({ lang, t, onQuote }) {
  const [filter, setFilter] = useState('all');
  const pool = (filter === 'all' ? products : prods(filter)).slice(0, 8);
  const half = Array.from({ length: Math.max(2, Math.ceil(6 / pool.length)) }).flatMap(() => pool);
  const card = (p, key) => {
    const name = p.model || cat(p.category).label[lang];
    return (
      <article key={key} className="yard-card flex w-[270px] shrink-0 flex-col p-5">
        <div className="flex items-center justify-between px-1 pb-3">
          <span className="rounded-full border border-brand/40 bg-brand/10 px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.14em] text-brand">{cat(p.category).label[lang]}</span>
          <span aria-hidden="true" className="pulse-dot size-1.5 rounded-full bg-brand" />
        </div>
        <MachinePhoto name={p.image} alt={name} eager className="img-zoom aspect-[4/3]" />
        <h3 className="mt-3 px-1 font-display text-xl font-extrabold tracking-tight"><bdi>{name}</bdi></h3>
        <div className="mt-auto flex items-center gap-3 px-1 pt-4">
          <BtnPrimary href={`#/${lang}/models/${p.id}`} className="min-h-10 px-4 text-[11px]">{t.featured.view}</BtnPrimary>
          <button onClick={() => onQuote(name)} className="inline-flex min-h-10 items-center gap-1.5 text-[11px] font-extrabold text-muted transition-colors hover:text-brand">{t.featured.quote}<Icon name="arrow" className="directional" size={14} /></button>
        </div>
      </article>
    );
  };
  return (
    <Shell>
      <SectionHead eyebrow={t.productsHome.eyebrow} title={t.productsHome.title} body={t.productsHome.body} />
      <div className="mb-8 flex flex-wrap items-center gap-2" role="group" aria-label={t.productsHome.all}>
        {[['all', t.productsHome.all], ...categories.map(c => [c.id, c.label[lang]])].map(([id, label]) => (
          <button key={id} onClick={() => setFilter(id)} aria-pressed={filter === id}
            className={`min-h-11 rounded-full border px-5 text-xs font-bold transition-all ${filter === id ? 'border-brand bg-brand text-deep shadow-[0_8px_24px_-8px_rgba(255,95,0,.5)]' : 'border-cardline bg-card text-muted hover:border-bone/40 hover:text-bone'}`}>
            {label}
          </button>
        ))}
      </div>
      <div className="prod-rail -mx-5 px-5 md:mx-0 md:px-0" aria-label={t.productsHome.title}>
        <div className="prod-track">
          <div className="prod-half">{half.map((p, i) => card(p, `a${i}`))}</div>
          <div className="prod-half" aria-hidden="true">{half.map((p, i) => card(p, `b${i}`))}</div>
        </div>
      </div>
      <div className="mt-8 flex flex-wrap items-center justify-between gap-4">
        <p className="flex items-center gap-2 text-[11px] text-muted/70"><Icon name="info" size={14} />{t.productsHome.body}</p>
        <BtnPrimary href={`#/${lang}/machinery`}>{t.productsHome.viewAll}</BtnPrimary>
      </div>
    </Shell>
  );
}

// ---------- 3. Machine families: large image tiles ----------
export function CategoryTiles({ lang, t }) {
  return (
    <Shell tone="raised">
      <SectionHead eyebrow={t.catHome.eyebrow} title={t.catHome.title} body={t.catHome.body} />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((c, j) => (
          <a key={c.id} href={`#/${lang}/machinery/${c.id}`} className="yard-card io group relative overflow-hidden" style={{ '--d': `${j * 70}ms` }}>
            <div className="img-zoom relative aspect-[4/3] overflow-hidden">
              <img src={img(c.image)} alt={c.label[lang]} loading="lazy" width="880" height="660" className="h-full w-full object-cover" />
              <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/80 via-deep/10 to-transparent" />
              <span aria-hidden="true" className="absolute inset-x-0 bottom-0 h-1.5 origin-left scale-x-0 bg-brand transition-transform duration-300 group-hover:scale-x-100" />
            </div>
            <div className="flex items-center justify-between gap-3 p-5">
              <h3 className="font-display text-2xl font-extrabold tracking-tight">{c.label[lang]}</h3>
              <span className="grid size-11 shrink-0 place-items-center rounded-full border border-cardline text-muted transition-all group-hover:border-brand group-hover:bg-brand group-hover:text-deep"><Icon name="arrow" className="directional" /></span>
            </div>
          </a>
        ))}
      </div>
    </Shell>
  );
}

// ---------- 4. SHANTUI Global + SHANTUI Afghanistan (brief) ----------
export function AboutBrief({ lang, t }) {
  return (
    <Shell>
      <div className="io grid gap-10 lg:grid-cols-2 lg:gap-14">
        {[[t.aboutBrief.titleG, t.aboutBrief.bodyG], [t.aboutBrief.titleAF, t.aboutBrief.bodyAF]].map(([title, body], j) => (
          <div key={title} className="io" style={{ '--d': `${j * 120}ms` }}>
            <p className="flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.22em] text-brand"><span aria-hidden="true" className="sweep h-[3px] w-9 rounded-full bg-brand" />{t.aboutBrief.eyebrow}</p>
            <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight md:text-4xl">{title}</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted md:text-[15px]">{body}</p>
          </div>
        ))}
      </div>
      <div className="io mt-10 grid gap-4 sm:grid-cols-3">
        {t.aboutBrief.facts.map(f => (
          <div key={f.l} className="yard-card flex items-center gap-4 p-5">
            <span className="font-display text-3xl font-extrabold tabular-nums text-brand md:text-4xl">{f.n}</span>
            <p className="text-[13px] font-bold leading-snug">{f.l}</p>
          </div>
        ))}
      </div>
      <div className="io mt-8 flex flex-wrap items-center gap-4">
        <BtnPrimary href={`#/${lang}/about`}>{t.aboutBrief.cta}</BtnPrimary>
        <p className="flex items-center gap-2 text-[11px] text-muted/70"><Icon name="info" size={13} />{t.aboutBrief.note}</p>
      </div>
    </Shell>
  );
}

// ---------- 5. Parts: finder + image cards ----------
export function PartsFinder({ lang, t, onQuote }) {
  const [model, setModel] = useState('');
  const [group, setGroup] = useState('all');
  const [searched, setSearched] = useState(false);
  // default view: one sample card per group; after a group search, that group's parts
  const perGroup = () => partsGroups.map(g => partsList.find(p => p.group === g.id)).filter(Boolean);
  const results = searched && group !== 'all' ? partsList.filter(p => p.group === group) : perGroup();
  const sel = 'w-full min-h-12 rounded-full border border-cardline bg-raised px-5 text-sm font-bold text-bone focus:border-brand focus:outline-none';
  return (
    <Shell tone="raised">
      <SectionHead eyebrow={t.partsHome.eyebrow} title={t.partsHome.title} body={t.partsHome.body} />
      <div className="io yard-card mb-10 grid items-end gap-4 p-5 md:grid-cols-[1fr_1fr_auto] md:p-6">
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold text-muted">{t.partsHome.finder.model}</span>
          <select value={model} onChange={e => setModel(e.target.value)} className={sel}>
            <option value="">{t.quote.pick}</option>
            {products.map(p => <option key={p.id} value={p.model || p.id}>{p.model || cat(p.category).label[lang]}</option>)}
          </select>
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold text-muted">{t.partsHome.finder.group}</span>
          <select value={group} onChange={e => { setGroup(e.target.value); setSearched(false); }} className={sel}>
            <option value="all">{t.partsHome.finder.all}</option>
            {partsGroups.map(g => <option key={g.id} value={g.id}>{g.label[lang]}</option>)}
          </select>
        </label>
        <BtnPrimary onClick={() => setSearched(true)} className="md:mb-0">{t.partsHome.finder.search}<Icon name="search" size={16} /></BtnPrimary>
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {results.map((part, j) => (
          <article key={part.id} className="yard-card io flex flex-col p-5" style={{ '--d': `${j * 60}ms` }}>
            <div className="img-zoom relative aspect-[4/3] overflow-hidden rounded-2xl bg-raised">
              <img src={`/images/${part.photo}`} alt={part.name[lang]} loading="lazy" width="640" height="480" className="h-full w-full object-cover" />
              <span className="absolute start-2.5 top-2.5 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.partsHome.demoPhoto}</span>
            </div>
            <div className="flex items-center justify-between px-1 pt-3">
              <h3 className="font-display text-base font-extrabold tracking-tight">{part.name[lang]}</h3>
              <span className="rounded-full border border-cardline bg-raised px-2 py-0.5 font-display text-[10px] font-extrabold tabular-nums text-muted">{part.num}</span>
            </div>
            <p className="mt-1 px-1 text-xs leading-relaxed text-muted">{part.note[lang]}</p>
            <button onClick={() => onQuote(part.name[lang])} className="cta-arrow mt-auto inline-flex min-h-11 items-center gap-2 px-1 text-xs font-extrabold text-brand">{t.featured.quote}<Icon name="arrow" className="directional" size={14} /></button>
          </article>
        ))}
      </div>
      <div className="mt-8 flex flex-wrap items-center gap-4">
        <BtnPrimary href={`#/${lang}/parts`}>{t.partsHome.view}</BtnPrimary>
        <BtnGhost onClick={onQuote}>{t.partsHome.request}</BtnGhost>
        <span className="text-[11px] text-muted/70">{results.length} {t.partsHome.finder.results}{model ? ` · ${model}` : ''}</span>
      </div>
    </Shell>
  );
}

// ---------- 6. Services: icon cards, short ----------
export function ServicesGrid({ lang, t }) {
  return (
    <Shell>
      <SectionHead eyebrow={t.servicesHome.eyebrow} title={t.servicesHome.title} body={t.servicesHome.body}>
        <a href={`#/${lang}/services`} className="cta-arrow mt-4 inline-flex min-h-11 items-center gap-3 border-b-2 border-brand pb-1 text-sm font-extrabold text-bone transition-colors hover:text-brand">{t.servicesHome.all}<Icon name="arrow" className="directional" /></a>
      </SectionHead>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {servicesList.slice(0, 4).map((sv, j) => (
          <article key={sv.id} className="yard-card io flex gap-4 p-5" style={{ '--d': `${j * 70}ms` }}>
            <span className="grid size-13 shrink-0 place-items-center rounded-2xl bg-brand/10 text-brand"><Icon name={sv.icon} size={24} /></span>
            <div className="min-w-0">
              <h3 className="font-display text-lg font-extrabold tracking-tight">{sv.title[lang]}</h3>
              <p className="mt-1.5 text-[13px] leading-relaxed text-muted">{sv.body[lang]}</p>
            </div>
          </article>
        ))}
      </div>
    </Shell>
  );
}

// ---------- 7. News: one big + two small, with photos ----------
export function NewsAsym({ lang, t }) {
  const [big, ...rest] = newsList.slice(0, 3);
  const badge = <span className="rounded-full border border-brand/50 bg-deep/70 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.12em] text-brand backdrop-blur">{t.news.sample}</span>;
  return (
    <Shell tone="raised">
      <SectionHead eyebrow={t.news.eyebrow} title={t.news.title} body={t.news.body}>
        <a href={`#/${lang}/news`} className="cta-arrow mt-4 inline-flex min-h-11 items-center gap-3 border-b-2 border-brand pb-1 text-sm font-extrabold text-bone transition-colors hover:text-brand">{t.news.all}<Icon name="arrow" className="directional" /></a>
      </SectionHead>
      <div className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
        <article className="yard-card io group overflow-hidden">
          <div className="img-zoom relative aspect-[16/10] overflow-hidden">
            <img src={`/images/${big.photo}`} alt={big.title[lang]} loading="lazy" width="960" height="600" className="h-full w-full object-cover" />
            <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/70 to-transparent" />
            <span className="absolute start-3 top-3">{badge}</span>
          </div>
          <div className="p-6">
            <span className="rounded-full bg-raised px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.14em] text-bone/70">{big.cat[lang]}</span>
            <a href={`#/${lang}/news/${big.id}`}><h3 className="mt-3 font-display text-2xl font-extrabold leading-snug tracking-tight transition-colors hover:text-brand md:text-3xl">{big.title[lang]}</h3></a>
            <p className="mt-2.5 text-sm leading-relaxed text-muted">{big.summary[lang]}</p>
          </div>
        </article>
        <div className="grid gap-5">
          {rest.map((n, j) => (
            <article key={n.id} className="yard-card io group flex flex-col overflow-hidden sm:flex-row" style={{ '--d': `${(j + 1) * 90}ms` }}>
              <div className="img-zoom relative aspect-[16/10] overflow-hidden sm:aspect-auto sm:w-2/5 sm:shrink-0">
                <img src={`/images/${n.photo}`} alt={n.title[lang]} loading="lazy" width="640" height="480" className="h-full w-full object-cover" />
                <span className="absolute start-2.5 top-2.5">{badge}</span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <span className="self-start rounded-full bg-raised px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.14em] text-bone/70">{n.cat[lang]}</span>
                <a href={`#/${lang}/news/${n.id}`}><h3 className="mt-2.5 font-display text-lg font-extrabold leading-snug tracking-tight transition-colors hover:text-brand">{n.title[lang]}</h3></a>
                <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-muted">{n.summary[lang]}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </Shell>
  );
}

// ---------- 8. Gallery: editorial masonry, captions only ----------
export function Gallery({ lang, t }) {
  return (
    <Shell>
      <SectionHead eyebrow={t.galleryHome.eyebrow} title={t.galleryHome.title}>
        <p className="mt-2 flex items-center gap-2 text-[11px] text-muted/70"><Icon name="info" size={13} />{t.galleryHome.note}</p>
      </SectionHead>
      <div className="columns-2 gap-4 lg:columns-3 [&>figure]:mb-4">
        {galleryList.map((g, j) => (
          <figure key={g.img} className="io break-inside-avoid" style={{ '--d': `${j * 60}ms` }}>
            <div className="yard-card group overflow-hidden p-0">
              <div className="img-zoom relative overflow-hidden">
                <img src={img(g.img)} alt={g.caption[lang]} loading="lazy" width="880" height="880" className={`w-full object-cover ${g.ar}`} />
                <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/75 via-transparent to-transparent opacity-80 transition-opacity group-hover:opacity-100" />
                <figcaption className="absolute inset-x-0 bottom-0 flex items-center gap-2 p-4 text-sm font-extrabold text-white">
                  <Icon name="pin" className="text-brand" size={15} />{g.caption[lang]}
                </figcaption>
              </div>
            </div>
          </figure>
        ))}
      </div>
    </Shell>
  );
}

// ---------- 9. Testimonials: clearly demo ----------
export function Testimonials({ lang, t }) {
  return (
    <Shell tone="raised">
      <SectionHead eyebrow={t.testi.eyebrow} title={t.testi.title} body={t.testi.note} />
      <div className="grid gap-5 md:grid-cols-3">
        {t.testi.items.map((it, j) => (
          <figure key={it.w} className="yard-card io flex flex-col p-6" style={{ '--d': `${j * 80}ms` }}>
            <Icon name="info" size={26} className="rotate-180 text-brand" />
            <blockquote className="mt-4 flex-1 text-[15px] font-semibold leading-relaxed">«{it.q}»</blockquote>
            <figcaption className="mt-5 flex items-center justify-between gap-2 border-t border-cardline pt-4">
              <span className="text-xs font-extrabold text-muted">{it.w}</span>
              <span className="rounded-full border border-cardline bg-raised px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.12em] text-muted">{t.news.sample}</span>
            </figcaption>
          </figure>
        ))}
      </div>
    </Shell>
  );
}

// ---------- 10. Final CTA ----------
export function Finale({ t, onQuote, lang }) {
  return (
    <section className="relative overflow-hidden bg-deep py-14 text-white md:py-16" aria-labelledby="finale-title">
      <span aria-hidden="true" className="pointer-events-none absolute -bottom-8 end-0 hidden select-none font-display text-[160px] font-extrabold leading-none tracking-tighter text-white/[.05] md:block">{lang === 'fa' ? 'SHANTUI' : 'LET’S TALK'}</span>
      <div className="relative mx-auto flex max-w-(--container-yard) flex-wrap items-center justify-between gap-8 px-5 md:px-10">
        <div className="min-w-0">
          <span aria-hidden="true" className="mb-4 block h-[3px] w-10 rounded-full bg-brand" />
          <h2 id="finale-title" className="max-w-2xl font-display text-3xl font-extrabold leading-[1.05] tracking-tight md:text-4xl">{t.cta.title}</h2>
        </div>
        <div className="flex flex-wrap gap-4">
          <button onClick={onQuote} className={CTA_PRIMARY}>{t.hero.quote}<Icon name="arrow" className="directional" /></button>
          <a href={`#/${lang}/contact`} className={CTA_GHOST}><Icon name="pin" size={16} />{t.nav.contact}</a>
        </div>
      </div>
    </section>
  );
}
