import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CtaBand, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, prod, partsList, partsGroups, servicesList, teamList, newsList, eventsList, facilitiesList, contactCards, branchesList, img } from '../lib/content';
import { PageHero, StatusBadge, MachineCard } from './shared';

// ============================================================
// Machine model detail page (specs, photos, fits, quote).
// ============================================================
export function Product({ lang, t, route, onQuote }) {
  const p = prod(route.param) || products[0];
  const name = p.model || cat(p.category).label[lang];
  const family = prods(p.category).filter(x => x.id !== p.id);
  const fitParts = partsList.filter(pt => pt.fits && pt.fits.includes(p.category)).slice(0, 4);
  return (
    <>
      <PageHero t={t} title={<bdi>{name}</bdi>} body={t.product.specsNote}>
        <p className="mt-5 flex flex-wrap items-center gap-2 text-[11px] font-bold text-muted">
          <span className="rounded-full border border-cardline px-3 py-1.5">{t.product.sample}</span>
          <span className="rounded-full border border-cardline px-3 py-1.5">{cat(p.category).label[lang]}</span>
          <a className="inline-flex items-center gap-1.5 rounded-full border border-cardline px-3 py-1.5 transition-colors hover:border-brand hover:text-brand" href={`#/${lang}/machinery/${p.category}`}>{t.product.back} {cat(p.category).label[lang]}</a>
        </p>
      </PageHero>
      <Shell>
        <div className="grid gap-8 lg:grid-cols-[1.15fr_.85fr] lg:gap-12">
          <div className="io yard-card min-w-0 p-5 md:p-6">
            <MachinePhoto name={p.image} alt={name} className="img-zoom aspect-[4/3]" />
            <p className="mt-4 flex items-center gap-2 px-2 text-[11px] text-muted/80"><Icon name="info" size={14} />{t.hero.note}</p>
          </div>
          <div className="io min-w-0">
            <h2 className="font-display text-2xl font-extrabold tracking-tight md:text-3xl">{t.product.specs}</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted">{t.product.specsNote}</p>
            <dl className="mt-6 divide-y divide-cardline overflow-hidden rounded-3xl border border-cardline">
              {(p.keySpecs || []).map(sp => (
                <div key={sp.k.en} className="flex items-center justify-between gap-4 bg-card/60 px-5 py-4">
                  <dt className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-wide text-muted"><Icon name="grid" size={15} className="text-brand" />{sp.k[lang]}</dt>
                  <dd className="font-display text-sm font-extrabold tabular-nums">{sp.v}</dd>
                </div>
              ))}
              <div className="flex items-center justify-between gap-4 bg-card/60 px-5 py-4">
                <dt className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-wide text-muted"><Icon name="shield" size={15} className="text-brand" />{t.availability.title}</dt>
                <dd><StatusBadge t={t} s={p.availability} /></dd>
              </div>
              <div className="flex items-center justify-between gap-4 bg-card/60 px-5 py-4">
                <dt className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-wide text-muted"><Icon name="document" size={15} className="text-brand" />{t.downloads.title}</dt>
                <dd className="text-sm font-bold text-muted">{t.downloads.none}</dd>
              </div>
            </dl>
            <div className="mt-6 flex flex-wrap gap-4">
              <BtnPrimary onClick={() => onQuote(name)}>{t.product.quote}</BtnPrimary>
              <BtnGhost href={cat(p.category).source}>{t.product.source}<Icon name="diagonal" className="directional" size={15} /></BtnGhost>
            </div>
          </div>
        </div>
        {family.length > 0 && (
          <div className="mt-14">
            <SectionHead eyebrow={t.featured.eyebrow} title={t.productFit.similar} />
            <div className="strip rail">
              {family.map((x, j) => <MachineCard key={x.id} lang={lang} t={t} p={x} onQuote={onQuote} j={j} />)}
            </div>
          </div>
        )}
        {fitParts.length > 0 && (
          <div className="mt-14">
            <SectionHead eyebrow={t.partsHome.eyebrow} title={t.productFit.parts} body={t.productFit.partsNote} />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {fitParts.map((part, j) => (
                <article key={part.id} className="yard-card io flex flex-col p-5" style={{ '--d': `${j * 60}ms` }}>
                  <div className="img-zoom relative aspect-[4/3] overflow-hidden rounded-2xl bg-raised">
                    <img src={`/images/${part.photo}`} alt={part.name[lang]} loading="lazy" width="640" height="480" className="h-full w-full object-cover" />
                    <span className="absolute start-2.5 top-2.5 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.partsHome.demoPhoto}</span>
                  </div>
                  <div className="flex items-center justify-between px-1 pt-3">
                    <h3 className="font-display text-base font-extrabold tracking-tight"><a href={`#/${lang}/parts/${part.id}`} className="inline-flex min-h-9 items-center transition-colors hover:text-brand"><bdi>{part.name[lang]}</bdi></a></h3>
                    <span className="rounded-full border border-cardline bg-raised px-2 py-0.5 font-display text-[10px] font-extrabold tabular-nums text-muted">{part.num}</span>
                  </div>
                  <p className="mt-1 px-1 text-xs leading-relaxed text-muted">{part.note[lang]}</p>
                  <button onClick={() => onQuote(`${name} — ${part.name[lang]}`)} className="cta-arrow mt-auto inline-flex min-h-11 items-center gap-2 px-1 text-xs font-extrabold text-brand">{t.featured.quote}<Icon name="arrow" className="directional" size={14} /></button>
                </article>
              ))}
            </div>
            <div className="mt-6">
              <BtnGhost href={`#/${lang}/parts`}>{t.productFit.allParts}</BtnGhost>
            </div>
          </div>
        )}
      </Shell>
    </>
  );
}
