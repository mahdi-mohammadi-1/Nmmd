import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CtaBand, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, prod, partsList, partsGroups, servicesList, teamList, newsList, eventsList, facilitiesList, contactCards, branchesList, img } from '../lib/content';
import { PageHero, StatusBadge, MachineCard } from './shared';

// ============================================================
// About: SHANTUI global, Afghanistan yard, team, facilities,
// mission/vision, CTA.
// ============================================================
export function AboutPage({ lang, t, onQuote }) {
  const a = t.aboutPage;
  return (
    <>
      {/* 1. Page hero — medium height (50–60vh), real machine photo backdrop */}
      <section className="relative flex min-h-[55svh] items-end overflow-hidden bg-deep text-white" aria-labelledby="about-hero-title">
        <img src={img('hero')} alt="" aria-hidden="true" width="1920" height="1080" className="kenburns absolute inset-0 h-full w-full object-cover" />
        <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/95 via-deep/50 to-deep/30" />
        <div className="relative mx-auto w-full max-w-(--container-yard) px-5 pb-12 pt-32 md:px-10 md:pb-16">
          <p className="pop flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.24em] text-brand" style={{ '--d': '0ms' }}>
            <span aria-hidden="true" className="sweep h-[3px] w-10 rounded-full bg-brand" />{t.tagline}
          </p>
          <h1 id="about-hero-title" className="pop mt-5 max-w-3xl font-display text-4xl font-extrabold leading-[1.05] tracking-tight md:text-6xl" style={{ '--d': '160ms' }}>{a.hero.title}</h1>
          <p className="pop mt-4 max-w-2xl text-sm leading-relaxed text-white/85 md:text-base" style={{ '--d': '300ms' }}>{a.hero.body}</p>
          <p className="pop mt-5 flex items-center gap-2 text-[11px] tracking-wide text-white/50" style={{ '--d': '400ms' }}><Icon name="info" size={14} />{a.hero.note}</p>
        </div>
      </section>

      {/* 2. Who is SHANTUI? — global, verified facts only */}
      <Shell>
        <div className="io grid gap-10 lg:grid-cols-[1.5fr_1fr] lg:gap-14">
          <div>
            <p className="flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.22em] text-brand"><span aria-hidden="true" className="sweep h-[3px] w-9 rounded-full bg-brand" />{t.nav.about}</p>
            <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight md:text-4xl">{a.global.title}</h2>
            <p className="mt-5 text-sm leading-relaxed text-muted md:text-[15px]">{a.global.body1}</p>
            <p className="mt-4 text-sm leading-relaxed text-muted md:text-[15px]">{a.global.body2}</p>
          </div>
          <div className="grid content-start gap-4">
            {a.global.facts.map(f => (
              <div key={f.l} className="yard-card flex items-center gap-4 p-5">
                <span className="w-24 shrink-0 text-center font-display text-3xl font-extrabold tabular-nums text-brand md:text-4xl">{f.n}</span>
                <p className="text-[13px] font-bold leading-snug">{f.l}</p>
              </div>
            ))}
          </div>
        </div>
      </Shell>

      {/* 3. SHANTUI in Afghanistan — the heart of the page */}
      <Shell tone="raised">
        <div className="io max-w-3xl">
          <p className="flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.22em] text-brand"><Icon name="pin" size={15} className="text-brand" />{t.country}</p>
          <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight md:text-4xl">{a.af.title}</h2>
          <p className="mt-5 text-sm leading-relaxed text-muted md:text-[15px]">{a.af.body1}</p>
          <p className="mt-4 text-sm leading-relaxed text-muted md:text-[15px]">{a.af.body2}</p>
          <p className="mt-5 flex items-center gap-2 text-[11px] text-muted/70"><Icon name="info" size={13} />{a.af.note}</p>
        </div>
      </Shell>

      {/* 4. Capabilities — compact cards with links (no service-page repetition) */}
      <Shell>
        <SectionHead eyebrow={a.caps.eyebrow} title={a.caps.title} />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {a.caps.items.map((c, j) => (
            <a key={c.line} href={`#/${lang}/${c.page}`} className="yard-card io group flex flex-col gap-3 p-5" style={{ '--d': `${j * 60}ms` }}>
              <span className="grid size-12 place-items-center rounded-2xl bg-brand/10 text-brand transition-colors group-hover:bg-brand group-hover:text-deep"><Icon name={c.icon} size={22} /></span>
              <p className="text-[13px] font-bold leading-snug">{c.line}</p>
              <span className="cta-arrow mt-auto inline-flex items-center gap-1.5 pt-2 text-[11px] font-extrabold text-brand">{a.caps.link}<Icon name="arrow" className="directional" size={13} /></span>
            </a>
          ))}
        </div>
      </Shell>

      {/* 5. Mission & vision + working values — one combined section */}
      <Shell tone="raised">
        <SectionHead eyebrow={a.mv.eyebrow} title={a.mv.title} />
        <div className="grid gap-5 md:grid-cols-2">
          {[a.mv.mission, a.mv.vision].map((m, j) => (
            <div key={m.title} className="yard-card io relative overflow-hidden p-6 md:p-6" style={{ '--d': `${j * 90}ms` }}>
              <span aria-hidden="true" className="block h-[3px] w-10 rounded-full bg-brand" />
              <h3 className="font-display text-2xl font-extrabold tracking-tight">{m.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted md:text-[15px]">{m.body}</p>
            </div>
          ))}
        </div>
        <div className="io mt-8">
          <p className="text-[11px] font-extrabold uppercase tracking-[0.22em] text-muted">{a.mv.valuesTitle}</p>
          <div className="mt-3 flex flex-wrap gap-2.5">
            {a.mv.values.map(v => (
              <span key={v} className="chip-float inline-flex min-h-11 items-center gap-2 rounded-full border border-cardline bg-card px-4 text-[13px] font-bold">
                <Icon name="check" size={14} className="text-brand" />{v}
              </span>
            ))}
          </div>
        </div>
      </Shell>

      {/* 6. Team — demo profiles, honestly labeled */}
      <Shell>
        <SectionHead eyebrow={a.team.eyebrow} title={a.team.title} body={a.team.note} />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {teamList.map((m, j) => (
            <article key={m.id} className="yard-card io flex flex-col p-5" style={{ '--d': `${j * 80}ms` }}>
              <div className="img-zoom relative aspect-[4/5] overflow-hidden rounded-2xl bg-raised">
                <img src={`/images/${m.photo}`} alt={`${m.name[lang]} — ${m.role[lang]}`} loading="lazy" width="640" height="800" className="h-full w-full object-cover" />
                <span className="absolute start-2.5 top-2.5 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{a.team.demo}</span>
              </div>
              <div className="px-1 pt-4">
                <h3 className="font-display text-xl font-extrabold tracking-tight"><bdi>{m.name[lang]}</bdi></h3>
                <p className="mt-0.5 text-xs font-extrabold uppercase tracking-[0.14em] text-brand">{m.role[lang]}</p>
                <p className="mt-2 text-[13px] leading-relaxed text-muted">{m.body[lang]}</p>
              </div>
            </article>
          ))}
        </div>
      </Shell>

      {/* 7. Facilities — trust through images */}
      <Shell tone="raised">
        <SectionHead eyebrow={a.fac.eyebrow} title={a.fac.title} body={a.fac.note} />
        <div className="grid gap-4 sm:grid-cols-2">
          {facilitiesList.map((f, j) => (
            <figure key={f.photo} className={`yard-card io group overflow-hidden p-0 ${j % 3 === 0 ? 'sm:col-span-2' : ''}`} style={{ '--d': `${j * 70}ms` }}>
              <div className="img-zoom relative overflow-hidden">
                <img src={f.photo} alt={f.cap[lang]} loading="lazy" width="1200" height="750" className={`w-full object-cover ${j % 3 === 0 ? 'aspect-[21/9]' : 'aspect-[4/3]'}`} />
                <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/75 via-transparent to-transparent" />
                <figcaption className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 p-4">
                  <span className="flex items-center gap-2 text-sm font-extrabold text-white"><Icon name="pin" className="text-brand" size={15} />{f.cap[lang]}</span>
                  <span className="rounded-full bg-deep/70 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/75 backdrop-blur">{a.fac.demo}</span>
                </figcaption>
              </div>
            </figure>
          ))}
        </div>
      </Shell>

      {/* 8. Final CTA */}
      <CtaBand id="about-cta-title" title={a.cta.title} body={a.cta.body} watermark={lang === 'fa' ? 'SHANTUI' : 'LET’S TALK'}>
        <button onClick={onQuote} className={CTA_PRIMARY}>{t.cta.button}<Icon name="arrow" className="directional" /></button>
        <a href={`#/${lang}/contact`} className={CTA_GHOST}><Icon name="document" size={16} />{t.cta.secondary}</a>
      </CtaBand>
    </>
  );
}
