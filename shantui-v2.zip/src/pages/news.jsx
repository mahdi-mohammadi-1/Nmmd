import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CtaBand, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, prod, partsList, partsGroups, servicesList, teamList, newsList, eventsList, facilitiesList, contactCards, branchesList, img } from '../lib/content';
import { PageHero, StatusBadge, MachineCard } from './shared';

// ============================================================
// News: featured, grid + load-more, events timeline,
// article detail pages (#/lang/news/:id).
// ============================================================
function NewsDetail({ lang, t, item, np }) {
  const related = newsList.filter(n => n.id !== item.id).slice(0, 3);
  return (
    <>
      <section className="border-b border-cardline bg-raised">
        <div className="mx-auto max-w-(--container-yard) px-5 py-12 md:px-10 md:py-16">
          <a href={`#/${lang}/news`} className="cta-arrow inline-flex min-h-9 items-center gap-2 rounded-full border border-cardline px-4 text-xs font-extrabold text-muted transition-colors hover:border-brand hover:text-brand">
            <Icon name="arrow" className="directional rotate-180" size={15} />{np.detail.back}
          </a>
          <div className="mt-6 flex flex-wrap items-center gap-2.5">
            <span className="rounded-full bg-deep px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.14em] text-white/85">{item.cat[lang]}</span>
            <span className="rounded-full border border-brand/40 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.12em] text-brand">{t.news.sample}</span>
            <span className="flex items-center gap-1.5 text-[11px] font-bold text-muted"><Icon name="calendar" size={13} />{item.date[lang]}</span>
          </div>
          <h1 className="pop mt-4 max-w-3xl font-display text-3xl font-extrabold leading-[1.12] tracking-tight md:text-5xl" style={{ '--d': '90ms' }}>{item.title[lang]}</h1>
          <p className="pop mt-4 max-w-2xl text-[15px] font-semibold leading-relaxed text-bone/80" style={{ '--d': '180ms' }}>{item.summary[lang]}</p>
        </div>
      </section>
      <Shell>
        <figure className="io yard-card group overflow-hidden p-0">
          <div className="img-zoom relative aspect-[16/8] overflow-hidden">
            <img src={`/images/${item.photo}`} alt={item.title[lang]} width="1200" height="600" className="h-full w-full object-cover" />
            <span className="absolute start-3 top-3 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.news.demoPhoto}</span>
          </div>
        </figure>
        <div className="mx-auto mt-8 grid max-w-3xl gap-5">
          {item.paras.map((p, j) => (
            <p key={j} className="io text-[15px] leading-[1.9] text-bone/90" style={{ '--d': `${j * 60}ms` }}>{p[lang]}</p>
          ))}
          <p className="mt-2 flex items-center gap-2 text-[11px] text-muted/70"><Icon name="info" size={14} />{t.news.body}</p>
        </div>
        <div className="mt-14">
          <SectionHead eyebrow={np.detail.related} title={np.grid.title} />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((n, j) => (
              <a key={n.id} href={`#/${lang}/news/${n.id}`} className="yard-card io group flex flex-col overflow-hidden p-0 transition-all duration-300 hover:-translate-y-1 hover:shadow-float" style={{ '--d': `${j * 70}ms` }}>
                <div className="img-zoom relative aspect-[16/10] overflow-hidden">
                  <img src={`/images/${n.photo}`} alt={n.title[lang]} loading="lazy" width="640" height="400" className="h-full w-full object-cover" />
                  <span className="absolute start-2.5 top-2.5 rounded-full bg-deep/80 px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.news.sample}</span>
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <span className="text-[11px] font-bold text-muted">{n.date[lang]} · {n.cat[lang]}</span>
                  <h3 className="mt-2 font-display text-lg font-extrabold leading-snug tracking-tight transition-colors group-hover:text-brand">{n.title[lang]}</h3>
                </div>
              </a>
            ))}
          </div>
        </div>
      </Shell>
    </>
  );
}

export function NewsPage({ lang, t, route }) {
  const np = t.newsPage;
  const [showAll, setShowAll] = useState(false);
  useEffect(() => { setShowAll(false); }, [route?.path]);
  const detail = route?.param ? newsList.find(n => n.id === route.param) : null;
  if (detail) return <NewsDetail lang={lang} t={t} item={detail} np={np} />;

  const [featured, ...rest] = newsList;
  const GRID_STEP = 6;
  const visible = showAll ? rest : rest.slice(0, GRID_STEP);
  const hidden = rest.length - visible.length;
  const itemUrl = id => `#/${lang}/news/${id}`;
  return (
    <>
      {/* 1. short hero */}
      <PageHero t={t} title={np.hero.title} body={np.hero.body} />

      {/* 2. featured — full-width split card */}
      <Shell>
        <p className="mb-5 flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.22em] text-brand"><Icon name="grid" size={14} />{np.featured.eyebrow}</p>
        <a href={itemUrl(featured.id)} className="yard-card io group grid overflow-hidden p-0 lg:grid-cols-[1.25fr_1fr]">
          <div className="img-zoom relative aspect-[16/10] overflow-hidden lg:aspect-auto lg:min-h-[420px]">
            <img src={`/images/${featured.photo}`} alt={featured.title[lang]} width="1200" height="800" className="absolute inset-0 h-full w-full object-cover" />
            <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/45 to-transparent" />
            <span className="absolute start-3 top-3 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.news.demoPhoto}</span>
          </div>
          <div className="flex flex-col justify-center p-6 md:p-10">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="rounded-full bg-deep px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.14em] text-white/85">{featured.cat[lang]}</span>
              <span className="rounded-full border border-brand/40 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.12em] text-brand">{t.news.sample}</span>
              <span className="flex items-center gap-1.5 text-[11px] font-bold text-muted"><Icon name="calendar" size={13} />{featured.date[lang]}</span>
            </div>
            <h2 className="mt-4 font-display text-2xl font-extrabold leading-[1.15] tracking-tight transition-colors group-hover:text-brand md:text-4xl">{featured.title[lang]}</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted md:text-[15px]">{featured.summary[lang]}</p>
            <span className="cta-arrow mt-6 inline-flex min-h-12 items-center gap-3 self-start rounded-full bg-brand px-6 text-sm font-extrabold text-deep transition-colors group-hover:bg-brandhot">{np.readMore}<Icon name="arrow" className="directional" /></span>
          </div>
        </a>
      </Shell>

      {/* 3. news grid 3/2/1 */}
      <Shell tone="raised">
        <SectionHead eyebrow={np.grid.eyebrow} title={np.grid.title} body={np.grid.body} />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((n, j) => (
            <a key={n.id} href={itemUrl(n.id)} className="yard-card io group flex flex-col overflow-hidden p-0 transition-all duration-300 hover:-translate-y-1 hover:shadow-float" style={{ '--d': `${(j % GRID_STEP) * 60}ms` }}>
              <div className="img-zoom relative aspect-[16/10] overflow-hidden">
                <img src={`/images/${n.photo}`} alt={n.title[lang]} loading="lazy" width="640" height="400" className="h-full w-full object-cover" />
                <span className="absolute start-2.5 top-2.5 rounded-full bg-deep/80 px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.news.sample}</span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <div className="flex items-center justify-between gap-2">
                  <span className="rounded-full bg-raised px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-[0.12em] text-bone/70">{n.cat[lang]}</span>
                  <span className="flex items-center gap-1.5 text-[11px] font-bold text-muted"><Icon name="calendar" size={12} />{n.date[lang]}</span>
                </div>
                <h3 className="mt-3 font-display text-lg font-extrabold leading-snug tracking-tight transition-colors group-hover:text-brand">{n.title[lang]}</h3>
                <p className="mt-2 line-clamp-3 text-[13px] leading-relaxed text-muted">{n.summary[lang]}</p>
                <span className="cta-arrow mt-auto inline-flex items-center gap-2 pt-4 text-xs font-extrabold text-brand">{np.readMore}<Icon name="arrow" className="directional" size={14} /></span>
              </div>
            </a>
          ))}
        </div>
        {hidden > 0 ? (
          <div className="mt-10 text-center">
            <button type="button" onClick={() => setShowAll(true)} className="cta-arrow inline-flex min-h-12 items-center gap-3 rounded-full border-2 border-brand px-7 text-sm font-extrabold text-brand transition-colors hover:bg-brand hover:text-deep">
              {np.loadMore} ({hidden})<Icon name="plus" size={15} />
            </button>
          </div>
        ) : (
          <p className="mt-10 text-center text-xs font-bold text-muted/70">— {np.allLoaded} —</p>
        )}
      </Shell>

      {/* 4. events — vertical timeline */}
      <Shell>
        <SectionHead eyebrow={np.events.eyebrow} title={np.events.title} body={np.events.body} />
        <ol className="relative mx-auto max-w-3xl">
          <span aria-hidden="true" className="absolute bottom-6 start-[19px] top-6 w-[2px] rounded bg-cardline" />
          {eventsList.map((ev, j) => (
            <li key={ev.id} className="io relative flex gap-4 pb-8 last:pb-0 sm:gap-5" style={{ '--d': `${j * 70}ms` }}>
              <span className="relative z-10 grid size-10 shrink-0 place-items-center rounded-full border-2 border-brand bg-card text-brand shadow-[0_0_0_5px_rgba(255,95,0,.12)]">
                <Icon name="calendar" size={17} />
              </span>
              <div className="yard-card min-w-0 flex-1 p-5">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="rounded-full bg-brand/15 px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.12em] text-brand">{ev.kind[lang]}</span>
                  <span className="rounded-full border border-cardline px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-muted">{t.news.sample}</span>
                  <span className="ms-auto flex items-center gap-1.5 text-[11px] font-extrabold text-bone"><Icon name="calendar" size={12} />{ev.date[lang]}</span>
                </div>
                <h3 className="mt-3 font-display text-lg font-extrabold tracking-tight">{ev.title[lang]}</h3>
                <p className="mt-1.5 flex items-center gap-1.5 text-xs font-bold text-muted"><Icon name="pin" size={13} className="text-brand" />{ev.place[lang]}</p>
                <p className="mt-2 text-[13px] leading-relaxed text-muted">{ev.desc[lang]}</p>
              </div>
            </li>
          ))}
        </ol>
      </Shell>

      {/* 5. short CTA */}
      <CtaBand id="news-cta-title" title={np.cta.title} body={np.cta.body}>
        <a href={`#/${lang}/contact`} className={CTA_PRIMARY}>{np.cta.contact}<Icon name="arrow" className="directional" /></a>
      </CtaBand>
    </>
  );
}
