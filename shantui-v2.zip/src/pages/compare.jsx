import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CtaBand, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, prod, partsList, partsGroups, servicesList, teamList, newsList, eventsList, facilitiesList, contactCards, branchesList, img } from '../lib/content';
import { PageHero, StatusBadge, MachineCard } from './shared';

// ============================================================
// Compare page (max 3 machines side by side).
// ============================================================
export function ComparePage({ lang, t, onQuote }) {
  const mach = t.machPage;
  const [ids, setIds] = useState(() => { try { return JSON.parse(sessionStorage.getItem('shantui-compare') || '[]'); } catch { return []; } });
  const items = ids.map(prod).filter(Boolean);
  const remove = id => { const nx = ids.filter(x => x !== id); setIds(nx); try { sessionStorage.setItem('shantui-compare', JSON.stringify(nx)); } catch { /* ignore */ } };
  const names = items.map(p => p.model || cat(p.category).label[lang]);
  return (
    <>
      <PageHero t={t} title={mach.compare.title} body={mach.compare.pick}>
        <a href={`#/${lang}/machinery`} className="mt-5 inline-flex min-h-11 items-center gap-2 rounded-full border border-cardline px-5 text-xs font-extrabold transition-colors hover:border-brand hover:text-brand">
          <Icon name="arrow" className="directional rotate-180" size={15} />{mach.compare.back}
        </a>
      </PageHero>
      <Shell>
        {items.length === 0 ? (
          <p className="rounded-3xl border border-dashed border-cardline p-10 text-center text-sm text-muted">{mach.compare.pick}</p>
        ) : (
          <>
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {items.map((p, j) => {
                const name = p.model || cat(p.category).label[lang];
                return (
                  <article key={p.id} className="yard-card io flex flex-col p-5" style={{ '--d': `${j * 70}ms` }}>
                    <div className="flex items-center justify-between gap-2 px-1 pb-3">
                      <span className="rounded-full border border-brand/40 bg-brand/10 px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.14em] text-brand">{cat(p.category).label[lang]}</span>
                      <button onClick={() => remove(p.id)} aria-label={`${mach.compare.remove} ${name}`} className="grid size-9 place-items-center rounded-full border border-cardline text-muted transition-colors hover:border-brand hover:text-brand"><Icon name="close" size={14} /></button>
                    </div>
                    <MachinePhoto name={p.image} alt={name} className="img-zoom aspect-[4/3]" />
                    <div className="mt-3 flex items-center justify-between gap-2 px-1">
                      <h2 className="font-display text-2xl font-extrabold tracking-tight"><bdi>{name}</bdi></h2>
                      <StatusBadge t={t} s={p.availability} />
                    </div>
                    <dl className="mt-3 divide-y divide-cardline overflow-hidden rounded-2xl border border-cardline">
                      {(p.keySpecs || []).map(sp => (
                        <div key={sp.k.en} className="flex items-center justify-between gap-3 bg-card/60 px-4 py-3">
                          <dt className="text-[11px] font-bold uppercase tracking-wide text-muted">{sp.k[lang]}</dt>
                          <dd className="font-display text-sm font-extrabold tabular-nums">{sp.v}</dd>
                        </div>
                      ))}
                    </dl>
                    <div className="mt-auto px-1 pt-4">
                      <BtnPrimary onClick={() => onQuote(name)}>{t.product.quote}</BtnPrimary>
                    </div>
                  </article>
                );
              })}
            </div>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <BtnPrimary onClick={() => onQuote(names.join('، '))}>{mach.compare.quoteAll}<Icon name="arrow" className="directional" /></BtnPrimary>
              <p className="flex items-center gap-2 text-[11px] text-muted/70"><Icon name="info" size={13} />{mach.count}</p>
            </div>
          </>
        )}
      </Shell>
    </>
  );
}
