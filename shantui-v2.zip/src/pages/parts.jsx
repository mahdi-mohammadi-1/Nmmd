import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CtaBand, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, prod, partsList, partsGroups, servicesList, teamList, newsList, eventsList, facilitiesList, contactCards, branchesList, img } from '../lib/content';
import { PageHero, StatusBadge, MachineCard } from './shared';

// ============================================================
// Parts: finder, catalog grid, request form, part detail
// pages (#/lang/parts/:id).
// ============================================================
function PartsForm({ lang, t, pp, prefill }) {
  const [f, setF] = useState({ name: '', phone: '', province: '', model: '', serial: '', pn: '', notes: '' });
  const [photo, setPhoto] = useState(null);
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);
  useEffect(() => {
    if (prefill) setF(x => ({ ...x, pn: prefill.pn || x.pn, notes: prefill.note || x.notes, model: prefill.model || x.model }));
  }, [prefill]);
  const set = (k, v) => { setF(x => ({ ...x, [k]: v })); setErrors(e => ({ ...e, [k]: false })); };
  const onPhoto = e => {
    const file = e.target.files?.[0];
    if (!file || !file.type.startsWith('image/')) return;
    const rd = new FileReader();
    rd.onload = () => setPhoto({ name: file.name, url: String(rd.result) });
    rd.readAsDataURL(file);
  };
  const submit = e => {
    e.preventDefault();
    const errs = {};
    for (const k of ['name', 'phone', 'model']) if (!String(f[k] || '').trim()) errs[k] = true;
    setErrors(errs);
    if (Object.keys(errs).length) return;
    try {
      const arr = JSON.parse(localStorage.getItem('shantui-parts-requests') || '[]');
      arr.push({ ...f, photoName: photo ? photo.name : null, lang, at: new Date().toISOString() });
      localStorage.setItem('shantui-parts-requests', JSON.stringify(arr));
    } catch { /* storage blocked */ }
    setSent(true);
  };
  const inp = 'min-h-12 w-full rounded-2xl border bg-card px-4 text-sm font-bold text-bone placeholder:font-semibold placeholder:text-muted/50 focus:border-brand focus:outline-none';
  const lbl = 'mb-1.5 block text-xs font-bold text-muted';
  if (sent) {
    return (
      <div className="io yard-card mx-auto max-w-xl p-6 text-center md:p-6">
        <span className="mx-auto grid size-16 place-items-center rounded-full bg-brand/15 text-brand"><Icon name="check" size={30} /></span>
        <h3 className="mt-5 font-display text-2xl font-extrabold tracking-tight">{pp.form.sent}</h3>
        <p className="mt-3 text-sm leading-relaxed text-muted">{pp.form.sentBody}</p>
        <button type="button" onClick={() => { setSent(false); setF({ name: '', phone: '', province: '', model: '', serial: '', pn: '', notes: '' }); setPhoto(null); }}
          className="cta-arrow mt-6 inline-flex min-h-12 items-center gap-3 rounded-full bg-brand px-6 text-sm font-extrabold text-deep transition-colors hover:bg-brandhot">
          {pp.form.again}<Icon name="arrow" className="directional" />
        </button>
      </div>
    );
  }
  return (
    <form onSubmit={submit} noValidate className="io yard-card grid gap-4 p-5 md:grid-cols-2 md:p-6">
      <div>
        <label className={lbl} htmlFor="pf-name">{pp.form.name} *</label>
        <input id="pf-name" value={f.name} onChange={e => set('name', e.target.value)} className={`${inp} ${errors.name ? 'border-red-500' : 'border-cardline'}`} autoComplete="name" />
        {errors.name && <p className="mt-1 text-[11px] font-bold text-red-600">{pp.form.required}</p>}
      </div>
      <div>
        <label className={lbl} htmlFor="pf-phone">{pp.form.phone} *</label>
        <input id="pf-phone" value={f.phone} onChange={e => set('phone', e.target.value)} type="tel" inputMode="tel" dir="ltr" className={`${inp} ${errors.phone ? 'border-red-500' : 'border-cardline'}`} autoComplete="tel" />
        {errors.phone && <p className="mt-1 text-[11px] font-bold text-red-600">{pp.form.required}</p>}
      </div>
      <div>
        <label className={lbl} htmlFor="pf-prov">{pp.form.province}</label>
        <select id="pf-prov" value={f.province} onChange={e => set('province', e.target.value)} className={`${inp} border-cardline`}>
          <option value="">{pp.form.provincePick}</option>
          {pp.provinces.map(p => <option key={p.en} value={lang === 'fa' ? p.fa : p.en}>{lang === 'fa' ? p.fa : p.en}</option>)}
        </select>
      </div>
      <div>
        <label className={lbl} htmlFor="pf-model">{pp.form.model} *</label>
        <input id="pf-model" value={f.model} onChange={e => set('model', e.target.value)} dir="ltr" placeholder="SD22 / SE220LC…" className={`${inp} ${errors.model ? 'border-red-500' : 'border-cardline'}`} />
        {errors.model && <p className="mt-1 text-[11px] font-bold text-red-600">{pp.form.required}</p>}
      </div>
      <div>
        <label className={lbl} htmlFor="pf-serial">{pp.form.serial}</label>
        <input id="pf-serial" value={f.serial} onChange={e => set('serial', e.target.value)} dir="ltr" className={`${inp} border-cardline`} />
      </div>
      <div>
        <label className={lbl} htmlFor="pf-pn">{pp.form.pn}</label>
        <input id="pf-pn" value={f.pn} onChange={e => set('pn', e.target.value)} dir="ltr" placeholder="ST-00-000" className={`${inp} border-cardline`} />
      </div>
      <div className="md:col-span-2">
        <label className={lbl} htmlFor="pf-notes">{pp.form.notes}</label>
        <textarea id="pf-notes" value={f.notes} onChange={e => set('notes', e.target.value)} rows="3" className={`${inp} border-cardline py-3`} />
      </div>
      <div className="md:col-span-2">
        <p className={lbl}>{pp.form.photo}</p>
        <div className="flex flex-wrap items-center gap-3">
          <label className="inline-flex min-h-12 cursor-pointer items-center gap-2 rounded-full border border-cardline bg-card px-5 text-xs font-extrabold text-bone transition-colors hover:border-brand hover:text-brand">
            <Icon name="plus" size={15} />{pp.form.photo}
            <input type="file" accept="image/*" onChange={onPhoto} className="sr-only" />
          </label>
          {photo && (
            <span className="inline-flex items-center gap-2 rounded-full bg-raised ps-1.5 pe-3">
              <img src={photo.url} alt="" width="72" height="72" className="size-9 rounded-full object-cover" />
              <span dir="ltr" className="max-w-40 truncate text-[11px] font-bold text-muted">{photo.name}</span>
              <button type="button" onClick={() => setPhoto(null)} aria-label={t.common.close} className="grid size-7 place-items-center rounded-full text-muted hover:text-brand"><Icon name="close" size={12} /></button>
            </span>
          )}
        </div>
        <p className="mt-2 flex items-center gap-1.5 text-[11px] text-muted/70"><Icon name="info" size={13} />{pp.form.photoHint}</p>
      </div>
      <div className="md:col-span-2">
        <button type="submit" className="cta-arrow inline-flex min-h-14 w-full items-center justify-center gap-3 rounded-full bg-brand px-8 text-sm font-extrabold text-deep transition-all hover:bg-brandhot hover:shadow-[0_14px_44px_-12px_rgba(255,95,0,.7)] active:scale-[.98] md:w-auto">
          {pp.form.send}<Icon name="arrow" className="directional" />
        </button>
        <p className="mt-3 flex items-center gap-1.5 text-[11px] text-muted/70"><Icon name="info" size={13} />{pp.form.body}</p>
      </div>
    </form>
  );
}

// single part detail (#/lang/parts/:id) — mirrors the machine detail pattern.
function PartDetail({ lang, t, part }) {
  const pp = t.partsPage;
  const name = part.name[lang];
  const group = partsGroups.find(g => g.id === part.group);
  const compat = part.fits || [];
  const similar = partsList.filter(p => p.group === part.group && p.id !== part.id).slice(0, 4);
  const request = () => {
    try { sessionStorage.setItem('shantui-part-prefill', JSON.stringify({ pn: part.num, note: `${name} — ${part.num}` })); } catch { /* ignore */ }
    location.hash = `/${lang}/parts`;
  };
  return (
    <>
      <PageHero t={t} title={<bdi>{name}</bdi>} body={part.note[lang]}>
        <p className="mt-5 flex flex-wrap items-center gap-2 text-[11px] font-bold text-muted">
          <span className="rounded-full border border-cardline px-3 py-1.5" dir="ltr">{part.num}</span>
          {group && <span className="rounded-full border border-cardline px-3 py-1.5">{group.label[lang]}</span>}
          <a href={`#/${lang}/parts`} className="inline-flex min-h-9 items-center gap-1.5 rounded-full border border-cardline px-3 py-1.5 transition-colors hover:border-brand hover:text-brand">
            <Icon name="arrow" className="directional rotate-180" size={13} />{pp.detail.back}
          </a>
        </p>
      </PageHero>
      <Shell>
        <div className="grid gap-8 lg:grid-cols-[1.15fr_.85fr] lg:gap-12">
          <div className="io yard-card min-w-0 p-5 md:p-6">
            <div className="img-zoom relative aspect-[4/3] overflow-hidden rounded-2xl bg-raised">
              <img src={`/images/${part.photo}`} alt={name} width="880" height="660" className="h-full w-full object-cover" />
              <span className="absolute start-2.5 top-2.5 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.partsHome.demoPhoto}</span>
            </div>
            <p className="mt-4 flex items-center gap-2 px-2 text-[11px] text-muted/80"><Icon name="info" size={14} />{t.partsGrid.body}</p>
          </div>
          <div className="io min-w-0">
            <h2 className="font-display text-2xl font-extrabold tracking-tight md:text-3xl">{t.product.specs}</h2>
            <dl className="mt-6 divide-y divide-cardline overflow-hidden rounded-3xl border border-cardline">
              <div className="flex items-center justify-between gap-4 bg-card/60 px-5 py-4">
                <dt className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-wide text-muted"><Icon name="document" size={15} className="text-brand" />{pp.detail.num}</dt>
                <dd className="font-display text-sm font-extrabold tabular-nums" dir="ltr">{part.num}</dd>
              </div>
              {group && (
                <div className="flex items-center justify-between gap-4 bg-card/60 px-5 py-4">
                  <dt className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-wide text-muted"><Icon name="grid" size={15} className="text-brand" />{pp.detail.group}</dt>
                  <dd className="text-sm font-bold">{group.label[lang]}</dd>
                </div>
              )}
              <div className="flex items-center justify-between gap-4 bg-card/60 px-5 py-4">
                <dt className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-wide text-muted"><Icon name="shield" size={15} className="text-brand" />{pp.detail.status}</dt>
                <dd><StatusBadge t={t} s={part.status} /></dd>
              </div>
              <div className="bg-card/60 px-5 py-4">
                <dt className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-wide text-muted"><Icon name="machine" size={15} className="text-brand" />{pp.detail.compat}</dt>
                <dd className="mt-2 flex flex-wrap gap-1.5">
                  {compat.map(fid => <span key={fid} className="rounded-full bg-raised px-2.5 py-1 text-[11px] font-bold text-muted">{cat(fid).label[lang]}</span>)}
                </dd>
              </div>
            </dl>
            <div className="mt-6 flex flex-wrap gap-4">
              <BtnPrimary onClick={request}>{pp.detail.request}<Icon name="arrow" className="directional" /></BtnPrimary>
              <BtnGhost href={`#/${lang}/parts`}>{pp.detail.back}</BtnGhost>
            </div>
          </div>
        </div>
        {similar.length > 0 && (
          <div className="mt-14">
            <SectionHead eyebrow={t.partsHome.eyebrow} title={pp.detail.similar} />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {similar.map((sp, j) => (
                <a key={sp.id} href={`#/${lang}/parts/${sp.id}`} className="yard-card io group flex flex-col p-4 transition-all duration-300 hover:-translate-y-1 hover:shadow-float" style={{ '--d': `${j * 60}ms` }}>
                  <div className="img-zoom relative aspect-[4/3] overflow-hidden rounded-2xl bg-raised">
                    <img src={`/images/${sp.photo}`} alt={sp.name[lang]} loading="lazy" width="640" height="480" className="h-full w-full object-cover" />
                    <span className="absolute start-2.5 top-2.5 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.partsHome.demoPhoto}</span>
                  </div>
                  <div className="flex items-center justify-between gap-2 px-1 pt-3">
                    <h3 className="font-display text-base font-extrabold tracking-tight transition-colors group-hover:text-brand"><bdi>{sp.name[lang]}</bdi></h3>
                    <span className="rounded-full border border-cardline bg-raised px-2 py-0.5 font-display text-[10px] font-extrabold tabular-nums text-muted" dir="ltr">{sp.num}</span>
                  </div>
                  <p className="mt-1 px-1 text-xs leading-relaxed text-muted">{sp.note[lang]}</p>
                </a>
              ))}
            </div>
          </div>
        )}
      </Shell>
    </>
  );
}

export function PartsPage({ lang, t, route }) {
  const pp = t.partsPage;
  const [sel, setSel] = useState({ family: 'all', model: '', group: 'all' });
  const [applied, setApplied] = useState(null);
  const [pnq, setPnq] = useState('');
  const [prefill, setPrefill] = useState(null);

  // part-detail pages hand their request over through sessionStorage
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem('shantui-part-prefill');
      if (raw) { setPrefill(JSON.parse(raw)); sessionStorage.removeItem('shantui-part-prefill'); }
    } catch { /* ignore */ }
  }, []);

  // single-part detail view (#/lang/parts/:id) — after all hooks
  const detailPart = route?.param ? partsList.find(p => p.id === route.param) : null;
  if (detailPart) return <PartDetail lang={lang} t={t} part={detailPart} />;

  const goto = id => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  const effFamily = applied ? applied.family : 'all';
  const results = partsList.filter(p =>
    (!applied || applied.group === 'all' || p.group === applied.group) &&
    (effFamily === 'all' || (p.fits || []).includes(effFamily)) &&
    (!pnq.trim() || p.num.toLowerCase().includes(pnq.trim().toLowerCase()))
  );
  const search = () => {
    setApplied({ family: sel.model ? (prod(sel.model)?.category || sel.family) : sel.family, group: sel.group });
    goto('parts-grid');
  };
  const reset = () => { setSel({ family: 'all', model: '', group: 'all' }); setApplied(null); setPnq(''); };
  const askPart = (part) => { setPrefill({ pn: part.num, note: `${part.name[lang]} — ${part.num}`, k: Date.now() }); goto('parts-form'); };

  const selCls = 'w-full min-h-12 rounded-full border border-cardline bg-raised px-5 text-sm font-bold text-bone focus:border-brand focus:outline-none';
  const models = sel.family === 'all' ? products : prods(sel.family);

  return (
    <>
      {/* 1. hero (~45vh) */}
      <section className="relative flex min-h-[45svh] items-end overflow-hidden bg-deep text-white" aria-labelledby="parts-hero-title">
        <img src="/images/facility-warehouse.jpg" alt="" aria-hidden="true" width="1536" height="1024" className="kenburns absolute inset-0 h-full w-full object-cover" />
        <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/95 via-deep/55 to-deep/30" />
        <div className="relative mx-auto w-full max-w-(--container-yard) px-5 pb-10 pt-28 md:px-10 md:pb-12">
          <p className="pop flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.24em] text-brand" style={{ '--d': '0ms' }}>
            <span aria-hidden="true" className="sweep h-[3px] w-10 rounded-full bg-brand" />{t.nav.parts}
          </p>
          <h1 id="parts-hero-title" className="pop mt-4 font-display text-4xl font-extrabold leading-[1.05] tracking-tight md:text-5xl" style={{ '--d': '150ms' }}>{pp.hero.title}</h1>
          <p className="pop mt-3 max-w-2xl text-sm leading-relaxed text-white/85" style={{ '--d': '280ms' }}>{pp.hero.body}</p>
          <div className="pop mt-6 flex flex-wrap gap-4" style={{ '--d': '400ms' }}>
            <button type="button" onClick={() => goto('parts-finder')} className="cta-arrow inline-flex min-h-12 items-center gap-3 rounded-full bg-brand px-6 text-sm font-extrabold text-deep transition-all hover:bg-brandhot active:scale-[.98]">{pp.hero.search}<Icon name="search" size={16} /></button>
            <button type="button" onClick={() => goto('parts-form')} className="inline-flex min-h-12 items-center gap-3 rounded-full border-2 border-white/45 px-5 text-sm font-extrabold text-white transition-colors hover:border-white hover:bg-white hover:text-deep">{pp.hero.request}<Icon name="arrow" className="directional" /></button>
          </div>
        </div>
      </section>

      {/* 2. parts finder */}
      <Shell>
        <div id="parts-finder" className="scroll-mt-28">
          <SectionHead eyebrow={pp.finder.eyebrow} title={pp.finder.title} body={pp.finder.body} />
          <div className="yard-card grid items-end gap-4 p-5 md:grid-cols-[1fr_1fr_1fr_auto] md:p-6">
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold text-muted">{pp.finder.family}</span>
              <select value={sel.family} onChange={e => setSel(s => ({ ...s, family: e.target.value, model: '' }))} className={selCls}>
                <option value="all">{t.catalog.filterAll}</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.label[lang]}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold text-muted">{pp.finder.model}</span>
              <select value={sel.model} onChange={e => setSel(s => ({ ...s, model: e.target.value }))} className={selCls}>
                <option value="">{t.quote.pick}</option>
                {models.map(p => <option key={p.id} value={p.id}>{p.model || cat(p.category).label[lang]}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-bold text-muted">{pp.finder.group}</span>
              <select value={sel.group} onChange={e => setSel(s => ({ ...s, group: e.target.value }))} className={selCls}>
                <option value="all">{pp.finder.all}</option>
                {partsGroups.map(g => <option key={g.id} value={g.id}>{g.label[lang]}</option>)}
              </select>
            </label>
            <BtnPrimary onClick={search} className="md:mb-0">{pp.finder.search}</BtnPrimary>
          </div>
          <div className="yard-card mt-4 flex flex-wrap items-center gap-3 p-3">
            <label className="relative min-w-52 flex-1">
              <span className="sr-only">{pp.finder.pn}</span>
              <Icon name="search" size={16} className="pointer-events-none absolute start-4 top-1/2 -translate-y-1/2 text-muted" />
              <input value={pnq} onChange={e => setPnq(e.target.value)} type="search" dir="ltr" placeholder={pp.finder.pn}
                className="min-h-11 w-full rounded-full border border-cardline bg-raised ps-11 pe-4 text-sm font-bold text-bone placeholder:font-semibold placeholder:text-muted/60 focus:border-brand focus:outline-none" />
            </label>
            {applied && (
              <button type="button" onClick={reset} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-cardline px-4 text-xs font-bold text-muted transition-colors hover:border-brand hover:text-brand">
                <Icon name="close" size={13} />{pp.finder.reset}
              </button>
            )}
            <p className="text-xs font-bold text-muted"><bdi>{results.length}</bdi> {pp.finder.results}</p>
          </div>
        </div>
      </Shell>

      {/* 3. results grid (the finder is the only category path — no separate category section) */}
      <Shell tone="raised">
        <div id="parts-grid" className="scroll-mt-28">
          <p className="mb-4 mt-12 flex flex-wrap items-baseline gap-2 text-xs font-bold text-muted">
            <span>{applied || pnq.trim() ? `${pp.finder.resultsFor}:` : t.partsGrid.title + ':'} <bdi>{results.length}</bdi> {pp.finder.results}</span>
            <span className="text-muted/60">·</span>
            <span className="flex items-center gap-1.5 font-semibold text-muted/70"><Icon name="info" size={13} />{t.partsGrid.body}</span>
          </p>
          {results.length ? (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {results.map((part, j) => {
                const compat = part.fits || [];
                const shown = compat.slice(0, 2).map(fid => cat(fid).label[lang]);
                const extra = compat.length - 2;
                return (
                  <article key={part.id} className="yard-card io flex flex-col p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-float" style={{ '--d': `${j * 60}ms` }}>
                    <div className="img-zoom relative aspect-[4/3] overflow-hidden rounded-2xl bg-raised">
                      <img src={`/images/${part.photo}`} alt={part.name[lang]} loading="lazy" width="640" height="480" className="h-full w-full object-cover" />
                      <span className="absolute start-2.5 top-2.5 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.partsHome.demoPhoto}</span>
                    </div>
                    <div className="flex items-center justify-between gap-2 px-1 pt-3">
                      <h3 className="font-display text-base font-extrabold tracking-tight"><a href={`#/${lang}/parts/${part.id}`} className="inline-flex min-h-9 items-center transition-colors hover:text-brand"><bdi>{part.name[lang]}</bdi></a></h3>
                      <span className="rounded-full border border-cardline bg-raised px-2 py-0.5 font-display text-[10px] font-extrabold tabular-nums text-muted" dir="ltr">{part.num}</span>
                    </div>
                    <p className="mt-1 px-1 text-xs leading-relaxed text-muted">{part.note[lang]}</p>
                    <div className="mt-2 flex flex-wrap items-center gap-1.5 px-1">
                      <span className="text-[10px] font-bold text-muted/70">{t.productFit.parts}:</span>
                      {shown.map(lb => <span key={lb} className="rounded-full bg-raised px-2 py-0.5 text-[10px] font-bold text-muted">{lb}</span>)}
                      {extra > 0 && <span className="rounded-full bg-raised px-2 py-0.5 text-[10px] font-bold text-muted">+{extra}</span>}
                    </div>
                    <div className="mt-2 px-1"><StatusBadge t={t} s={part.status} /></div>
                    <button onClick={() => askPart(part)} className="cta-arrow mt-auto inline-flex min-h-11 items-center gap-2 px-1 pt-3 text-xs font-extrabold text-brand">
                      {t.partsGrid.request}<Icon name="arrow" className="directional" size={14} />
                    </button>
                  </article>
                );
              })}
            </div>
          ) : (
            <div className="rounded-3xl border border-dashed border-cardline p-10 text-center">
              <p className="text-sm font-bold text-muted">{pp.finder.empty}</p>
              <button type="button" onClick={() => goto('parts-form')} className="cta-arrow mt-4 inline-flex min-h-12 items-center gap-3 rounded-full bg-brand px-6 text-xs font-extrabold text-deep transition-colors hover:bg-brandhot">{pp.hero.request}<Icon name="arrow" className="directional" size={14} /></button>
            </div>
          )}
        </div>
      </Shell>

      {/* 5. why genuine + 6. how it works */}
      <Shell>
        <SectionHead eyebrow={pp.why.eyebrow} title={pp.why.title} />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {pp.why.items.map((w, j) => (
            <div key={w.t} className="yard-card io flex gap-3 p-5" style={{ '--d': `${j * 50}ms` }}>
              <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-brand/10 text-brand"><Icon name={w.icon} size={20} /></span>
              <div className="min-w-0">
                <h3 className="text-sm font-extrabold">{w.t}</h3>
                <p className="mt-1 text-xs leading-relaxed text-muted">{w.d}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-16">
          <SectionHead eyebrow={pp.how.eyebrow} title={pp.how.title} />
          <div className="grid gap-4 md:grid-cols-3">
            {pp.how.steps.map((st, j) => (
              <div key={st.t} className="yard-card io relative overflow-hidden p-6" style={{ '--d': `${j * 80}ms` }}>
                <span aria-hidden="true" className="absolute -top-3 end-3 font-display text-7xl font-extrabold text-bone/[.06]">{j + 1}</span>
                <span className="grid size-11 place-items-center rounded-full bg-brand font-display text-lg font-extrabold text-deep">{j + 1}</span>
                <h3 className="mt-4 font-display text-lg font-extrabold tracking-tight">{st.t}</h3>
                <p className="mt-2 text-[13px] leading-relaxed text-muted">{st.d}</p>
              </div>
            ))}
          </div>
        </div>
      </Shell>

      {/* 7. request form */}
      <Shell tone="raised">
        <div id="parts-form" className="scroll-mt-28">
          <SectionHead eyebrow={pp.form.eyebrow} title={pp.form.title} />
          <PartsForm lang={lang} t={t} pp={pp} prefill={prefill} />
        </div>
      </Shell>

      {/* 8. final CTA (support + request merged into one quiet band) */}
      <CtaBand id="parts-cta-title" title={pp.cta.title} body={pp.cta.body}>
        <button type="button" onClick={() => goto('parts-form')} className={CTA_PRIMARY}>{pp.cta.request}<Icon name="arrow" className="directional" /></button>
        <a href={`#/${lang}/contact`} className={CTA_GHOST}><Icon name="document" size={15} />{t.nav.contact}</a>
      </CtaBand>
    </>
  );
}
