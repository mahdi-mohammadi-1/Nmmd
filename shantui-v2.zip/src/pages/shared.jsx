import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CtaBand, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, prod, partsList, partsGroups, servicesList, teamList, newsList, eventsList, facilitiesList, contactCards, branchesList, img } from '../lib/content';

// ============================================================
// Shared page pieces: compact hero band, status badge,
// machine card (grid/list), 404.
// ============================================================
export function PageHero({ t, title, body, children }) {
  return (
    <section className="border-b border-cardline bg-raised">
      <div className="mx-auto max-w-(--container-yard) px-5 py-12 md:px-10 md:py-16">
        <p className="pop flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.24em] text-brand"><span aria-hidden="true" className="sweep h-[3px] w-10 rounded-full bg-brand" />{t.brand} · {t.country}</p>
        <h1 className="pop mt-4 font-display text-4xl font-extrabold leading-[1.02] tracking-tight md:text-6xl" style={{ '--d': '90ms' }}>{title}</h1>
        {body && <p className="pop mt-4 max-w-xl text-sm leading-relaxed text-muted md:text-[15px]" style={{ '--d': '180ms' }}>{body}</p>}
        {children}
      </div>
    </section>
  );
}

// v2.11 — status badge + compact spec row + optional compare toggle.

const STATUS_DOT = { available: 'bg-emerald-600', order: 'bg-brand', contact: 'bg-muted' };

export function StatusBadge({ t, s }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-extrabold text-white ${STATUS_DOT[s] || STATUS_DOT.contact}`}>
      <span aria-hidden="true" className="size-1.5 rounded-full bg-white/90" />
      {t.availability.status[s] || t.availability.status.contact}
    </span>
  );
}

export function MachineCard({ lang, t, p, onQuote, j = 0, compare = null, onCompare = null, view = 'grid' }) {
  const name = p.model || cat(p.category).label[lang];
  const inCompare = compare ? compare.includes(p.id) : false;
  const full = compare ? compare.length >= 3 : true;
  const specs = p.keySpecs || [];
  const media = (
    <>
      <div className="flex items-center justify-between gap-2 px-1 pb-3">
        <span className="rounded-full border border-brand/40 bg-brand/10 px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.14em] text-brand">{cat(p.category).label[lang]}</span>
        <StatusBadge t={t} s={p.availability} />
      </div>
      <MachinePhoto name={p.image} alt={name} className="img-zoom aspect-[4/3]" />
    </>
  );
  const info = (
    <>
      <h3 className="mt-3 px-1 font-display text-xl font-extrabold tracking-tight md:text-2xl"><bdi>{name}</bdi></h3>
      {specs.length > 0 && (
        <dl className="mt-2 flex flex-wrap gap-x-4 gap-y-1 px-1">
          {specs.map(sp => (
            <div key={sp.k.en} className="flex items-baseline gap-1.5 text-[11px]">
              <dt className="font-bold text-muted">{sp.k[lang]}:</dt>
              <dd className="font-extrabold tabular-nums text-bone">{sp.v}</dd>
            </div>
          ))}
        </dl>
      )}
      <div className="mt-auto flex flex-wrap items-center gap-3 px-1 pt-4">
        <BtnPrimary href={`#/${lang}/models/${p.id}`} className="min-h-10 px-4 text-[11px]">{t.featured.view}</BtnPrimary>
        <button onClick={() => onQuote(name)} className="inline-flex min-h-10 items-center gap-1.5 text-[11px] font-extrabold text-muted transition-colors hover:text-brand">{t.featured.quote}<Icon name="arrow" className="directional" size={14} /></button>
        {onCompare && (
          <button onClick={() => onCompare(p.id)} disabled={!inCompare && full} aria-pressed={inCompare}
            className={`ms-auto inline-flex min-h-10 items-center gap-1.5 rounded-full border px-3 text-[11px] font-extrabold transition-colors ${inCompare ? 'border-brand bg-brand text-deep' : full ? 'border-cardline text-muted/40' : 'border-cardline text-muted hover:border-brand hover:text-brand'}`}>
            <Icon name={inCompare ? 'check' : 'plus'} size={13} />{inCompare ? t.machPage.compare.added : t.machPage.compare.add}
          </button>
        )}
      </div>
    </>
  );
  return view === 'list' ? (
    <article className="yard-card io flex flex-col transition-all duration-300 hover:-translate-y-0.5 hover:shadow-float sm:flex-row sm:gap-5" style={{ '--d': `${j * 50}ms` }}>
      <div className="min-w-0 sm:w-64 sm:shrink-0">{media}</div>
      <div className="flex min-w-0 flex-1 flex-col">{info}</div>
    </article>
  ) : (
    <article className="yard-card io flex flex-col p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-float" style={{ '--d': `${j * 50}ms` }}>{media}{info}</article>
  );
}

export function NotFound({ lang, t }) {
  return (
    <Shell>
      <div className="io yard-card mx-auto max-w-xl p-10 text-center md:p-14">
        <p className="font-display text-7xl font-extrabold tracking-tighter text-brand md:text-8xl">404</p>
        <h1 className="mt-4 font-display text-2xl font-extrabold tracking-tight md:text-3xl">{t.nf.title}</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">{t.nf.body}</p>
        <BtnPrimary href={`#/${lang}/home`} className="mt-8">{t.nf.home}</BtnPrimary>
      </div>
    </Shell>
  );
}

// ============================================================
// v2.1 pages — parts catalogue, services, company + team, news
// ============================================================

// ============================================================
// v2.13 — Parts page: catalog + request system (user spec).
// Find → browse → request. No cart, no checkout — the request
// form is the single action, recorded locally.
