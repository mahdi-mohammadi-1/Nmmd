import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CtaBand, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, prod, partsList, partsGroups, servicesList, teamList, newsList, eventsList, facilitiesList, contactCards, branchesList, img } from '../lib/content';
import { PageHero, StatusBadge, MachineCard } from './shared';

// ============================================================
// Machinery catalog: hero, search toolbar, family strip,
// product grid/list, compare tray, CTA.
// ============================================================
export function Catalog({ lang, t, route, onQuote }) {
  const mach = t.machPage;
  const active = route.param && cat(route.param) ? route.param : 'all';
  const [query, setQuery] = useState('');
  const [view, setView] = useState('grid');
  const [compare, setCompare] = useState(() => { try { return JSON.parse(sessionStorage.getItem('shantui-compare') || '[]'); } catch { return []; } });
  useEffect(() => { try { sessionStorage.setItem('shantui-compare', JSON.stringify(compare)); } catch { /* private mode */ } }, [compare]);

  const toggleCompare = id => setCompare(c => (c.includes(id) ? c.filter(x => x !== id) : c.length >= 3 ? c : [...c, id]));
  const family = id => { location.hash = `/${lang}/machinery${id === 'all' ? '' : '/' + id}`; };

  const q = query.trim().toLowerCase();
  const base = prods(active);
  const list = q ? base.filter(p => `${p.model || ''} ${cat(p.category).label[lang]} ${cat(p.category).label.en}`.toLowerCase().includes(q)) : base;

  return (
    <>
      {/* 1. compact hero (45vh) — product-focused */}
      <section className="relative flex min-h-[45svh] items-end overflow-hidden bg-deep text-white" aria-labelledby="mach-hero-title">
        <img src={img('work-earth')} alt="" aria-hidden="true" width="1920" height="1080" className="kenburns absolute inset-0 h-full w-full object-cover" />
        <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/95 via-deep/55 to-deep/30" />
        <div className="relative mx-auto w-full max-w-(--container-yard) px-5 pb-10 pt-28 md:px-10 md:pb-12">
          <p className="pop flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.24em] text-brand" style={{ '--d': '0ms' }}>
            <span aria-hidden="true" className="sweep h-[3px] w-10 rounded-full bg-brand" />{t.productsHome.eyebrow}
          </p>
          <h1 id="mach-hero-title" className="pop mt-4 font-display text-4xl font-extrabold leading-[1.05] tracking-tight md:text-5xl" style={{ '--d': '150ms' }}>{mach.hero.title}</h1>
          <p className="pop mt-3 max-w-2xl text-sm leading-relaxed text-white/85" style={{ '--d': '280ms' }}>{mach.hero.body}</p>
          <div className="pop mt-6" style={{ '--d': '400ms' }}>
            <button type="button" onClick={onQuote} className="cta-arrow inline-flex min-h-12 items-center gap-3 rounded-full bg-brand px-6 text-sm font-extrabold text-deep transition-all hover:bg-brandhot active:scale-[.98]">{mach.hero.cta}<Icon name="arrow" className="directional" /></button>
          </div>
        </div>
      </section>

      <Shell>
        {/* 2. sticky toolbar: search only (+ view toggle) — filtering lives in the image strip below */}
        <div className="sticky top-[112px] z-30 -mx-5 mb-8 bg-ink/95 px-5 py-3 backdrop-blur-md md:mx-0 md:px-0">
          <div className="yard-card flex flex-wrap items-center gap-2 p-2.5">
            <label className="relative min-w-44 flex-1">
              <span className="sr-only">{mach.search}</span>
              <Icon name="search" size={16} className="pointer-events-none absolute start-4 top-1/2 -translate-y-1/2 text-muted" />
              <input value={query} onChange={e => setQuery(e.target.value)} type="search" placeholder={mach.search}
                className="min-h-11 w-full rounded-full border border-cardline bg-raised ps-11 pe-4 text-sm font-bold text-bone placeholder:font-semibold placeholder:text-muted/60 focus:border-brand focus:outline-none" />
            </label>
            <div className="flex items-center gap-1 rounded-full border border-cardline p-1" role="group" aria-label={mach.view.grid}>
              {(['grid', 'list']).map(v => (
                <button key={v} onClick={() => setView(v)} aria-pressed={view === v} aria-label={v === 'grid' ? mach.view.grid : mach.view.list}
                  className={`grid size-9 place-items-center rounded-full transition-colors ${view === v ? 'bg-brand text-deep' : 'text-muted hover:text-bone'}`}>
                  <Icon name={v === 'grid' ? 'grid' : 'machine'} size={15} />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 3. family filter strip: "all" + 6 image tiles (the only family filter) */}
        <div className="mb-10 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 2xl:grid-cols-7">
          <button type="button" onClick={() => family('all')} aria-pressed={active === 'all'}
            className={`yard-card io flex items-center gap-3 p-2.5 text-start transition-all duration-300 hover:-translate-y-0.5 hover:shadow-float ${active === 'all' ? 'ring-2 ring-brand' : ''}`}>
            <span className="grid size-14 shrink-0 place-items-center rounded-xl bg-raised text-brand"><Icon name="grid" size={22} /></span>
            <span className="min-w-0 text-[13px] font-extrabold leading-tight">{t.catalog.filterAll}</span>
          </button>
          {categories.map((c, j) => (
            <a key={c.id} href={`#/${lang}/machinery/${c.id}`} aria-current={active === c.id ? 'page' : undefined}
              className={`yard-card io group flex items-center gap-3 p-2.5 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-float ${active === c.id ? 'ring-2 ring-brand' : ''}`} style={{ '--d': `${j * 50}ms` }}>
              <span className="h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-raised">
                <img src={img(c.image)} alt="" aria-hidden="true" loading="lazy" width="112" height="112" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110" />
              </span>
              <span className="min-w-0 text-[13px] font-extrabold leading-tight">{c.label[lang]}</span>
            </a>
          ))}
        </div>

        {/* 4. product list */}
        <p className="mb-4 flex flex-wrap items-baseline gap-2 text-xs font-bold text-muted">
          <span><bdi>{list.length}</bdi> {mach.results}</span>
          <span className="text-muted/60">·</span>
          <span className="flex items-center gap-1.5 font-semibold text-muted/70"><Icon name="info" size={13} />{mach.count}</span>
        </p>
        {list.length ? (
          view === 'grid' ? (
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {list.map((p, j) => <MachineCard key={p.id} lang={lang} t={t} p={p} onQuote={onQuote} j={j} compare={compare} onCompare={toggleCompare} view="grid" />)}
            </div>
          ) : (
            <div className="grid gap-4">
              {list.map((p, j) => <MachineCard key={p.id} lang={lang} t={t} p={p} onQuote={onQuote} j={j} compare={compare} onCompare={toggleCompare} view="list" />)}
            </div>
          )
        ) : (
          <p className="rounded-3xl border border-dashed border-cardline p-10 text-center text-sm text-muted">{t.catalog.empty}</p>
        )}
      </Shell>

      {/* 5. project-based selection guide */}
      <Shell tone="raised">
        <SectionHead eyebrow={mach.projects.eyebrow} title={mach.projects.title} body={mach.projects.body} />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {mach.projects.items.map((pr, j) => (
            <div key={pr.line} className="yard-card io flex flex-col gap-3 p-5" style={{ '--d': `${j * 60}ms` }}>
              <span className="grid size-12 place-items-center rounded-2xl bg-brand/10 text-brand"><Icon name={pr.icon} size={22} /></span>
              <p className="text-[13px] font-bold leading-snug">{pr.line}</p>
              <div className="mt-auto flex flex-wrap gap-1.5 pt-2">
                {pr.fams.map(f => (
                  <a key={f} href={`#/${lang}/machinery/${f}`} className="inline-flex min-h-9 items-center rounded-full border border-cardline bg-card px-3 text-[11px] font-bold text-muted transition-colors hover:border-brand hover:text-brand">{cat(f).label[lang]}</a>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Shell>

      {/* 6. final CTA */}
      <CtaBand id="mach-cta-title" title={mach.cta.title} body={mach.cta.body}>
        <a href={`#/${lang}/services`} className={CTA_GHOST}><Icon name="tool" size={16} />{mach.cta.consult}</a>
        <button onClick={onQuote} className={CTA_PRIMARY}>{t.cta.button}<Icon name="arrow" className="directional" /></button>
      </CtaBand>

      {/* compare tray */}
      {compare.length > 0 && (
        <div className="fixed inset-x-4 bottom-4 z-30 left-1/2 w-[min(46rem,calc(100vw-2rem))] -translate-x-1/2" role="region" aria-label={mach.compare.title}>
          <div className="pop flex flex-wrap items-center justify-center gap-2 rounded-3xl border border-cardline bg-card/95 p-2.5 shadow-float backdrop-blur-xl">
            {compare.map(id => {
              const p = prod(id);
              const nm = p ? (p.model || cat(p.category).label[lang]) : id;
              return (
                <span key={id} className="inline-flex min-h-10 items-center gap-1.5 rounded-full bg-raised ps-3 pe-1.5 text-xs font-extrabold">
                  <bdi>{nm}</bdi>
                  <button onClick={() => toggleCompare(id)} aria-label={`${mach.compare.remove} ${nm}`} className="grid size-8 place-items-center rounded-full text-muted transition-colors hover:bg-card hover:text-brand"><Icon name="close" size={13} /></button>
                </span>
              );
            })}
            <a href={`#/${lang}/compare`} className="cta-arrow inline-flex min-h-10 items-center gap-2 rounded-full bg-brand px-5 text-xs font-extrabold text-deep transition-colors hover:bg-brandhot">{mach.compare.go}<Icon name="arrow" className="directional" size={14} /></a>
            <button onClick={() => setCompare([])} className="min-h-10 rounded-full px-3 text-xs font-bold text-muted transition-colors hover:text-brand">{mach.compare.clear}</button>
          </div>
        </div>
      )}
    </>
  );
}
