# SHANTUI Afghanistan — راهنمای کامل پروژه

> سایت معرفی و کاتالوگ ماشین‌آلات ساختمانی شانتویی افغانستان — دوزبانه (دری RTL / انگلیسی LTR)
> آخرین نسخه: **v2.21** — وضعیت: هر ۷ صفحه کامل، تست‌شده و یکدست

---

## ۱. معرفی و قواعد پایه

- **نوع سایت:** معرفی + کاتالوگ. **سبد خرید و سفارش آنلاین ندارد** — تنها عملکرد خرید، «فورم درخواست» است.
- **دیتای دیمو:** هر جا معلومات واقعی نبود، دیتای نمونه با برچسب صادقانه («نمونه»، «تصویر نمایشی») استفاده شده. هیچ مشخصات/قیمت/موجودی/شماره‌ی ساختگی بدون برچسب وجود ندارد (قواعد پروتکل اصلی — آرشیو: `../project-docs/INDEX.md`).
- **سبک بصری:** «Orange Yard» — تم روشن، سرمه‌ای صنعتی + نارنجی برند فقط به‌عنوان لهجه. کارت‌ها `yard-card`، پایان همه‌ی صفحه‌ها با `CtaBand` تیره، خط hazard فقط بالای فوتر.

## ۲. تکنولوژی و راه‌اندازی

Vite + React (JS) + Tailwind CSS v4 — بدون کتابخانه‌ی UI خارجی؛ کیت اختصاصی در `src/ui/kit.jsx`.

```bash
npm install        # نصب وابستگی‌ها
npm run dev        # سرور توسعه (روی سیستم خودت: http://localhost:5173)
npm run build      # بیلد تولیدی → dist/
npx vite preview --host 0.0.0.0 --port 5176   # پیش‌نمایش بیلد تولیدی
```

## ۳. ساختار فولدرها

```
shantui-v2/
├── PROJECT.md              ← همین فایل (راهنمای کامل)
├── index.html
├── src/
│   ├── main.jsx            ← روتینگ hash + چیدمان کلی (navbar/footer/quote sheet)
│   ├── app.css             ← توکن‌های رنگ/فونت/انیمیشن (Tailwind v4 @theme)
│   ├── lib/content.js      ← ⭐ کل دیتا و متن‌ها (fa/en) — همه‌چیز از اینجا تغذیه می‌شود
│   ├── ui/kit.jsx          ← کیت UI: Icon, Shell, SectionHead, Btn*, MachinePhoto,
│   │                          QuoteSheet, CtaBand, CTA_PRIMARY/CTA_GHOST
│   ├── layout/chrome.jsx   ← Navbar (pill شناور) + Footer + منوی موبایل
│   ├── home/sections.jsx   ← ۱۱ سکشن صفحه‌ی خانه (Hero → Finale)
│   └── pages/              ← هر صفحه یک فایل:
│       shared.jsx (PageHero/StatusBadge/MachineCard/404) · catalog.jsx · product.jsx
│       compare.jsx · parts.jsx · services.jsx · about.jsx · news.jsx · contact.jsx
├── public/images/          ← عکس‌ها (دیمو با برچسب؛ لوگو shantui-logo.png)
└── research/               ← اسکریپت‌های تست و QA (README.md داخلش)
```

## ۴. مسیرها (Hash Routing)

| مسیر | صفحه |
|------|------|
| `#/fa/home` · `#/en/home` | خانه |
| `#/lang/about` | درباره ما |
| `#/lang/machinery` + `#/lang/machinery/:category` | کاتالوگ + دسته‌بندی |
| `#/lang/models/:id` (مثلاً `models/sd22`) | صفحه‌ی مودیل ماشین |
| `#/lang/compare` | مقایسه (حداکثر ۳ ماشین) |
| `#/lang/parts` + `#/lang/parts/:id` | قطعات + صفحه‌ی هر قطعه |
| `#/lang/services` | خدمات (۱۰ سکشن + فورم) |
| `#/lang/news` + `#/lang/news/:id` | اخبار + مقاله‌ی کامل |
| `#/lang/contact` | تماس (۴ دسک + فورم + نقشه‌ی شعبات) |

## ۵. لایه‌ی دیتا — `src/lib/content.js`

همه‌ی متن‌ها دوزبانه به شکل `{ en: '...', fa: '...' }`. بخش‌های مهم:

| خروجی | محتوا |
|-------|-------|
| `categories` `products` | ۶ خانواده‌ی ماشین + مودیل‌ها (مشخصات دیمو با برچسب) |
| `partsList` `partsGroups` | قطعات (۶ گروه) + شماره‌ی پارت، وضعیت موجودی دیمو |
| `servicesList` | ۶ خدمت (نگهداری، پس از فروش، پشتیبانی، تعمیر، نصب، مشوره) |
| `newsList` `eventsList` | ۱۰ خبر (هر کدام ۳ پاراگراف) + ۵ رویداد — همه نمونه |
| `contactCards` `branchesList` | ۴ دسک تماس + ۲ شعبه — **شماره/ایمیل/آدرس همه دیمو** |
| `teamList` `facilitiesList` `galleryList` | تیم، ساحات، گالری (برای خانه/درباره) |
| `copy.en` / `copy.fa` | متن هر صفحه: `homePage` `machPage` `partsPage` `servicesPage` `newsPage` `contactPage` `aboutPage` … |

**قاعده‌ی تغییر متن:** فقط `content.js` را عوض کن؛ کد صفحات دست نمی‌زند.

## ۶. دیتای دیمو → چه چیزهایی واقعی شود

| مورد | محل دقیق در `content.js` |
|------|--------------------------|
| شماره‌های تماس/واتساپ/ایمیل | `contactCards` (۴ دسک) + `branchesList` |
| آدرس و ساعت کاری شعبات | `branchesList` (کابل/مزار) + `copy.*.contactPage` |
| نقشه‌ی زنده | `BranchMap` در `src/pages/contact.jsx` — جایش کد امبد گوگل‌مپ |
| مشخصات فنی ماشین‌ها | `products` (فعلاً «مشخصات نمونه») |
| موجودی و قیمت قطعات | `partsList` (status: available/order/contact) |
| خبرها و رویدادها | `newsList` `eventsList` |
| عکس‌های واقعی | `public/images/` — همه با برچسب «تصویر نمایشی» |
| ویدیوی هیرو | `Hero` در `src/home/sections.jsx` — جای تصویر `hero.webp` |
| شبکه‌های اجتماعی | آیکون‌های فوتر (فعلاً «به‌زودی») |

## ۷. فرم‌ها و ذخیره‌سازی (بدون بک‌اند)

| فرم | کلید ذخیره |
|-----|-----------|
| استعلام قیمت (شیت سراسری) | `localStorage: shantui-quote-requests` |
| درخواست قطعه | `localStorage: shantui-parts-requests` |
| درخواست سرویس | `localStorage: shantui-service-requests` |
| پیام تماس | `localStorage: shantui-contact-requests` |
| مقایسه‌ی ماشین‌ها | `sessionStorage: shantui-compare` (حداکثر ۳) |
| تحویل درخواست از صفحه‌ی قطعه به فورم | `sessionStorage: shantui-part-prefill` |

اعتبارسنجی همه‌ی فرم‌ها محلی است؛ پیام موفقیت + ثبت در localStorage.

## ۸. سیستم طراحی (خلاصه)

- **رنگ‌ها** (`src/app.css`): `--color-deep #141C20` سرمه‌ای · `--color-brand #FF5F00` نارنجی · `bone` متن تیره · `muted` متن ثانویه · `card/raised/cardline` سطوح روشن.
- **کارت:** کلاس `yard-card` (شعاع ۲۴px، خط کارت، سایه در hover) + پدینگ استاندارد `p-5 md:p-6`.
- **پایان صفحه:** فقط `CtaBand` (تیره، خط نارنجی کوچک، دکمه‌های `CTA_PRIMARY`/`CTA_GHOST`). **اسلب نارنجی تمام‌عرض ممنوع** — ممیز بصری این را تست می‌کند.
- **انیمیشن:** کلاس‌های `io` (reveal on scroll)، `pop`، `img-zoom`، `kenburns` — همه کم‌مدت و `prefers-reduced-motion` را رعایت می‌کنند.
- **آیکون‌ها:** استروک‌درون در `kit.jsx` (`PATHS`) — phone/mail/calendar در v2.18 اضافه شد.

## ۹. تاریخچه‌ی نسخه‌ها

| نسخه | کار |
|------|-----|
| v2.3 | ۷ صفحه + نوبار pill |
| v2.4 | هیرو ویدیویی (تصویر موقت) |
| v2.6–2.7 | ProductStream خانه |
| v2.8 | ممیزی بصری + کیت UI |
| v2.9 | خانه‌ی ۱۱-سکشنی |
| v2.10 | درباره ما (فکت‌های تأییدشده: تأسیس ۱۹۸۰، ۱۶۰+ کشور، رتبه ۱ بولدوزر) |
| v2.11–2.12 | ماشین‌آلات + رفع تکرار نوار کنترل |
| v2.13–2.14 | قطعات + فایندر (بدون سکشن دسته‌بندی) |
| v2.15 | صفحه‌ی جزئیات هر قطعه |
| v2.16 | خدمات ۱۰-سکشنی + فورم سرویس |
| v2.17 | اخبار (Featured + Grid + رویدادها + Load More + جزئیات خبر) |
| v2.18 | تماس (۴ دسک + فورم + نقشه‌ی شعبات) |
| v2.19 | ممیزی بصری کامل ۴عرض×۲زبان + رفع بریدگی متن |
| v2.20 | هم‌خانی طراحی: حذف اسلب‌های نارنجی → `CtaBand` واحد + نرمال‌سازی کارت‌ها |
| v2.21 | مرتب‌سازی ساختار کد (تقسیم `all.jsx` به ۹ فایل) + پاک‌سازی + همین سند |

## ۱۰. تست‌ها

```bash
# اول سرور پیش‌نمایش:
npm run build && npx vite preview --host 0.0.0.0 --port 5176 --strictPort
cd research && npm install   # فقط بار اول (playwright)

node research/audit.mjs          # ۲۴۱ بررسی — همه‌ی صفحات
node research/smoke.mjs          # ۱۲۸ بررسی — مسیرها و فرم‌ها
node research/visual-audit.mjs   # ممیزی بصری ۴۴ بارگذاری (۴ عرض × ۲ زبان)
node research/qa-parts.mjs       # ۲۶ — قطعات
node research/qa-services.mjs    # ۲۴ — خدمات
node research/qa-news.mjs        # ۲۰ — اخبار
node research/qa-contact.mjs     # ۱۸ — تماس
node research/snap.mjs fa/services name 1440   # اسکرین‌شات
```

**قاعده‌ی ثابت:** بعد از هر تغییر، بیلد + تست + بررسی بصری، بعد کامیت.

## ۱۱. نقشه‌ی راه باقیمانده

1. ویدیوی واقعی هیرو (جای‌گذاری آماده در `Hero`)
2. عکس‌های واقعی (ماشین‌ها، تیم، ورکشاپ، نمایشگاه)
3. معلومات تماس واقعی + امبد گوگل‌مپ
4. CMS یا پنل ساده برای خبرها/قطعات (فعلاً `content.js`)
5. مرتب‌سازی/سایدبار کاتالوگ قطعات
6. شبکه‌های اجتماعی

## ۱۲. نکات محیط کاری (اگر دوباره در همین سندباکس کار کردیم)

- سرور توسعه (vite dev) از طریق پروکسی کاربر **خالی** می‌شود — همیشه `build` + `vite preview` روی پورت **5176**.
- بین نوبت‌ها ریست سندباکس: `node_modules` (ریشه و research)، `dist` و بسته‌های apt پاک می‌شوند → `npm install` + `cd research && npm install` + `npx playwright install chromium` + `sudo apt-get install -y libnspr4 libnss3 libasound2t64 ...` + build.
- کامیت‌ها با `git -c user.name="mahdi" -c user.email="mahdi@local" commit` (identity گلوبال ست نیست).
- سیستم کاربر: ویندوز، CMD، مسیر `C:\Users\mahdi\Desktop\projects\shatui` — فایروال فقط برای Node.js و Chrome اینترنت می‌دهد.
