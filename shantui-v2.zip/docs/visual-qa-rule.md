# Visual QA rule — MANDATORY (user directive, 2026-09-23)

After EVERY frontend change, the agent MUST open the real rendered output and
inspect it graphically. Code passing build/tests is NOT enough.

## The cycle (repeat until clean)

**Code → Run → Visual Check → Fix → Re-check**

## How to inspect (this environment)

This agent session cannot view images directly. The visual check is therefore
enforced with `research/audit.mjs` — a real-browser rendered-output audit that
measures actual geometry, imagery, fonts, motion and interactions (201 checks:
9 pages × 2 languages × 2 widths + deep home checks + mobile journeys).

1. Dev server running (`npx vite --host 0.0.0.0 --port 5176`).
2. `node research/audit.mjs` — must exit 0 (all checks pass).
3. `node research/snap.mjs <lang/route> <w> <h> <file.png> [full]` saves screenshots
   for the user's own eyes — the user remains the final visual judge.
4. Any FAIL = fix code, re-run audit, repeat until 0 failures.

## Checklist

- ظاهر کلی و برندینگ (overall look & branding)
- Layout و فاصله‌ها (spacing, alignment, rhythm)
- سایز عناصر (element sizes, touch targets ≥44px)
- Responsive (390 / 768 / 1440) و Overflow (no horizontal scroll)
- تصاویر (loading, cropping, aspect)
- فونت‌ها (Persian/English rendering, sizes, weights)
- Hover و Focus states
- Animation و Interaction (motion smoothness, pause behaviour)
- RTL correctness in Dari

## Rules

- No frontend change is "done" until the final UI is visually verified.
- If a visual or functional issue is found: fix it, re-screenshot, re-check.
- Record findings in this file (append below) so they are not repeated.

## Cycle log

- 2026-09-23 (first full cycle, 201 checks): found & fixed — models page +106px
  mobile overflow (grid columns lacked min-w-0), home +10px mobile overflow
  (unrevealed .io-side cards in RTL; html overflow-x clip added), marquee images
  lazy-loaded causing first-loop blanks (now eager), header indicator misaligned
  after webfont load/resize (re-measures on fonts.ready + resize), logo tap
  target 26px→44px. Final: 201/201 green.
