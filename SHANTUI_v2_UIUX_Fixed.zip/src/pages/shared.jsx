import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CtaBand, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, prod, partsList, partsGroups, servicesList, teamList, newsList, eventsList, facilitiesList, contactCards, branchesList, img } from '../lib/content';

// ============================================================
// Shared page pieces: compact hero band, status badge,
// machine card (grid/list), 404.
// ============================================================
export function PageHero({ t, title, body, children }) {
  return (
    <section className="border-b border-cardline bg-raised">
      <div className="mx-auto max-w-(--container-yard) px-5 py-12 md:px-10 md:py-16">
        <p className="pop flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.24em] text-brand"><span aria-hidden="true" className="sweep h-[3px] w-10 rounded-full bg-brand" />{t.brand} · {t.country}</p>
        <h1 className="pop mt-4 font-display text-4xl font-extrabold leading-[1.02] tracking-tight md:text-6xl" style={{ '--d': '90ms' }}>{title}</h1>
        {body && <p className="pop mt-4 max-w-xl text-sm leading-relaxed text-muted md:text-[15px]" style={{ '--d': '180ms' }}>{body}</p>}
        {children}
      </div>
    </section>
  );
}

// v2.11 — status badge + compact spec row + optional compare toggle.

const STATUS_DOT = { available: 'bg-emerald-600', order: 'bg-brand', contact: 'bg-muted' };

export function StatusBadge({ t, s }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-extrabold text-white ${STATUS_DOT[s] || STATUS_DOT.contact}`}>
      <span aria-hidden="true" className="size-1.5 rounded-full bg-white/90" />
      {t.availability.status[s] || t.availability.status.contact}
    </span>
  );
}

export function MachineCard({ lang, t, p, onQuote, j = 0, compare = null, onCompare = null, view = 'grid' }) {
  const name = p.model || cat(p.category).label[lang];
  const inCompare = compare ? compare.includes(p.id) : false;
  const full = compare ? compare.length >= 3 : true;
  const specs = p.keySpecs || [];
  const actions = (
    <div className="mt-auto flex flex-wrap items-center gap-3 pt-4">
      <a href={`#/${lang}/models/${p.id}`} className="cta-arrow inline-flex min-h-10 items-center gap-2 text-xs font-extrabold text-bone transition-colors hover:text-brand">{t.featured.view}<Icon name="arrow" className="directional" size={14} /></a>
      <button onClick={() => onQuote(name)} className="min-h-10 text-xs font-extrabold text-brand transition-colors hover:text-brandhot">{t.featured.quote}</button>
      {onCompare && (
        <button onClick={() => onCompare(p.id)} disabled={!inCompare && full} aria-pressed={inCompare}
          className={`ms-auto inline-flex min-h-9 items-center gap-1.5 rounded-lg border px-2.5 text-[10px] font-extrabold transition-colors ${inCompare ? 'border-brand bg-brand text-deep' : full ? 'border-cardline text-muted/40' : 'border-cardline text-muted hover:border-brand hover:text-brand'}`}>
          <Icon name={inCompare ? 'check' : 'plus'} size={12} />{inCompare ? t.machPage.compare.added : t.machPage.compare.add}
        </button>
      )}
    </div>
  );
  const specRow = specs.length > 0 && (
    <dl className="mt-3 grid grid-cols-3 gap-2 border-y border-cardline py-3">
      {specs.slice(0, 3).map(sp => (
        <div key={sp.k.en} className="min-w-0">
          <dt className="truncate text-[9px] font-bold uppercase tracking-wide text-muted">{sp.k[lang]}</dt>
          <dd className="mt-0.5 truncate font-display text-xs font-extrabold text-bone">{sp.v}</dd>
        </div>
      ))}
    </dl>
  );
  if (view === 'list') {
    return (
      <article className="panel-flat io grid overflow-hidden sm:grid-cols-[260px_1fr]" style={{ '--d': `${j * 45}ms` }}>
        <a href={`#/${lang}/models/${p.id}`} className="relative bg-raised p-3"><MachinePhoto name={p.image} alt={name} className="aspect-[4/3] rounded-xl" /></a>
        <div className="flex min-w-0 flex-col p-5">
          <div className="flex flex-wrap items-center justify-between gap-2"><span className="text-[10px] font-extrabold uppercase tracking-[.12em] text-brand">{cat(p.category).label[lang]}</span><StatusBadge t={t} s={p.availability} /></div>
          <h3 className="mt-2 font-display text-2xl font-extrabold tracking-tight"><a href={`#/${lang}/models/${p.id}`} className="hover:text-brand"><bdi>{name}</bdi></a></h3>
          {specRow}{actions}
        </div>
      </article>
    );
  }
  return (
    <article className="panel-flat io group flex min-w-0 flex-col overflow-hidden" style={{ '--d': `${j * 45}ms` }}>
      <a href={`#/${lang}/models/${p.id}`} className="relative block bg-raised p-3">
        <MachinePhoto name={p.image} alt={name} className="img-zoom aspect-[4/3] rounded-xl" />
        <span className="absolute start-4 top-4 rounded-lg bg-deep/88 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[.12em] text-white">{cat(p.category).label[lang]}</span>
      </a>
      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-center justify-between gap-3"><h3 className="font-display text-xl font-extrabold tracking-tight md:text-2xl"><a href={`#/${lang}/models/${p.id}`} className="transition-colors group-hover:text-brand"><bdi>{name}</bdi></a></h3><StatusBadge t={t} s={p.availability} /></div>
        {specRow}{actions}
      </div>
    </article>
  );
}

export function NotFound({ lang, t }) {
  return (
    <Shell>
      <div className="io yard-card mx-auto max-w-xl p-10 text-center md:p-14">
        <p className="font-display text-7xl font-extrabold tracking-tighter text-brand md:text-8xl">404</p>
        <h1 className="mt-4 font-display text-2xl font-extrabold tracking-tight md:text-3xl">{t.nf.title}</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">{t.nf.body}</p>
        <BtnPrimary href={`#/${lang}/home`} className="mt-8">{t.nf.home}</BtnPrimary>
      </div>
    </Shell>
  );
}

// ============================================================
// v2.1 pages — parts catalogue, services, company + team, news
// ============================================================

// ============================================================
// v2.13 — Parts page: catalog + request system (user spec).
// Find → browse → request. No cart, no checkout — the request
// form is the single action, recorded locally.
