import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CtaBand, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, prod, partsList, partsGroups, servicesList, teamList, newsList, eventsList, facilitiesList, contactCards, branchesList, img } from '../lib/content';
import { PageHero, StatusBadge, MachineCard } from './shared';

// ============================================================
// Services: 10-section page + service request form.
// ============================================================
function ServiceForm({ lang, t, sv }) {
  const [f, setF] = useState({ name: '', phone: '', province: '', model: '', serial: '', type: '', notes: '' });
  const [file, setFile] = useState(null);
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);
  const set = (k, v) => { setF(x => ({ ...x, [k]: v })); setErrors(e => ({ ...e, [k]: false })); };
  const onFile = e => {
    const fl = e.target.files?.[0];
    if (!fl || !/^(image|video)\//.test(fl.type)) return;
    if (fl.type.startsWith('image/')) {
      const rd = new FileReader();
      rd.onload = () => setFile({ name: fl.name, url: String(rd.result) });
      rd.readAsDataURL(fl);
    } else setFile({ name: fl.name, url: '' });
  };
  const submit = e => {
    e.preventDefault();
    const errs = {};
    for (const k of ['name', 'phone', 'model', 'type']) if (!String(f[k] || '').trim()) errs[k] = true;
    setErrors(errs);
    if (Object.keys(errs).length) return;
    try {
      const arr = JSON.parse(localStorage.getItem('shantui-service-requests') || '[]');
      arr.push({ ...f, fileName: file ? file.name : null, lang, at: new Date().toISOString() });
      localStorage.setItem('shantui-service-requests', JSON.stringify(arr));
    } catch { /* storage blocked */ }
    setSent(true);
  };
  const inp = 'min-h-12 w-full rounded-2xl border bg-card px-4 text-sm font-bold text-bone placeholder:font-semibold placeholder:text-muted/50 focus:border-brand focus:outline-none';
  const lbl = 'mb-1.5 block text-xs font-bold text-muted';
  if (sent) {
    return (
      <div className="io yard-card mx-auto max-w-xl p-6 text-center md:p-6">
        <span className="mx-auto grid size-16 place-items-center rounded-full bg-brand/15 text-brand"><Icon name="check" size={30} /></span>
        <h3 className="mt-5 font-display text-2xl font-extrabold tracking-tight">{sv.form.sent}</h3>
        <p className="mt-3 text-sm leading-relaxed text-muted">{sv.form.sentBody}</p>
        <button type="button" onClick={() => { setSent(false); setF({ name: '', phone: '', province: '', model: '', serial: '', type: '', notes: '' }); setFile(null); }}
          className="cta-arrow mt-6 inline-flex min-h-12 items-center gap-3 rounded-full bg-brand px-6 text-sm font-extrabold text-deep transition-colors hover:bg-brandhot">
          {sv.form.again}<Icon name="arrow" className="directional" />
        </button>
      </div>
    );
  }
  return (
    <form onSubmit={submit} noValidate className="io yard-card grid gap-4 p-5 md:grid-cols-2 md:p-6">
      <div>
        <label className={lbl} htmlFor="sf-name">{sv.form.name} *</label>
        <input id="sf-name" value={f.name} onChange={e => set('name', e.target.value)} autoComplete="name" className={`${inp} ${errors.name ? 'border-red-500' : 'border-cardline'}`} />
        {errors.name && <p className="mt-1 text-[11px] font-bold text-red-600">{sv.form.required}</p>}
      </div>
      <div>
        <label className={lbl} htmlFor="sf-phone">{sv.form.phone} *</label>
        <input id="sf-phone" value={f.phone} onChange={e => set('phone', e.target.value)} type="tel" inputMode="tel" dir="ltr" autoComplete="tel" className={`${inp} ${errors.phone ? 'border-red-500' : 'border-cardline'}`} />
        {errors.phone && <p className="mt-1 text-[11px] font-bold text-red-600">{sv.form.required}</p>}
      </div>
      <div>
        <label className={lbl} htmlFor="sf-prov">{sv.form.province}</label>
        <select id="sf-prov" value={f.province} onChange={e => set('province', e.target.value)} className={`${inp} border-cardline`}>
          <option value="">{sv.form.provincePick}</option>
          {t.partsPage.provinces.map(p => <option key={p.en} value={lang === 'fa' ? p.fa : p.en}>{lang === 'fa' ? p.fa : p.en}</option>)}
        </select>
      </div>
      <div>
        <label className={lbl} htmlFor="sf-model">{sv.form.model} *</label>
        <input id="sf-model" value={f.model} onChange={e => set('model', e.target.value)} dir="ltr" placeholder="SD22 / SE220LC…" className={`${inp} ${errors.model ? 'border-red-500' : 'border-cardline'}`} />
        {errors.model && <p className="mt-1 text-[11px] font-bold text-red-600">{sv.form.required}</p>}
      </div>
      <div>
        <label className={lbl} htmlFor="sf-type">{sv.form.type} *</label>
        <select id="sf-type" value={f.type} onChange={e => set('type', e.target.value)} className={`${inp} ${errors.type ? 'border-red-500' : 'border-cardline'}`}>
          <option value="">{sv.form.typePick}</option>
          {sv.form.types.map(tp => <option key={tp} value={tp}>{tp}</option>)}
        </select>
        {errors.type && <p className="mt-1 text-[11px] font-bold text-red-600">{sv.form.required}</p>}
      </div>
      <div>
        <label className={lbl} htmlFor="sf-serial">{sv.form.serial}</label>
        <input id="sf-serial" value={f.serial} onChange={e => set('serial', e.target.value)} dir="ltr" className={`${inp} border-cardline`} />
      </div>
      <div className="md:col-span-2">
        <label className={lbl} htmlFor="sf-notes">{sv.form.notes}</label>
        <textarea id="sf-notes" value={f.notes} onChange={e => set('notes', e.target.value)} rows="3" className={`${inp} border-cardline py-3`} />
      </div>
      <div className="md:col-span-2">
        <p className={lbl}>{sv.form.photo}</p>
        <div className="flex flex-wrap items-center gap-3">
          <label className="inline-flex min-h-12 cursor-pointer items-center gap-2 rounded-full border border-cardline bg-card px-5 text-xs font-extrabold text-bone transition-colors hover:border-brand hover:text-brand">
            <Icon name="plus" size={15} />{sv.form.photo}
            <input type="file" accept="image/*,video/*" onChange={onFile} className="sr-only" />
          </label>
          {file && (
            <span className="inline-flex items-center gap-2 rounded-full bg-raised ps-1.5 pe-3">
              {file.url ? <img src={file.url} alt="" width="72" height="72" className="size-9 rounded-full object-cover" /> : <span className="grid size-9 place-items-center rounded-full bg-brand/15 text-brand"><Icon name="document" size={15} /></span>}
              <span dir="ltr" className="max-w-40 truncate text-[11px] font-bold text-muted">{file.name}</span>
              <button type="button" onClick={() => setFile(null)} aria-label={t.common.close} className="grid size-7 place-items-center rounded-full text-muted hover:text-brand"><Icon name="close" size={12} /></button>
            </span>
          )}
        </div>
        <p className="mt-2 flex items-center gap-1.5 text-[11px] text-muted/70"><Icon name="info" size={13} />{sv.form.photoHint}</p>
      </div>
      <div className="md:col-span-2">
        <button type="submit" className="cta-arrow inline-flex min-h-14 w-full items-center justify-center gap-3 rounded-full bg-brand px-8 text-sm font-extrabold text-deep transition-all hover:bg-brandhot hover:shadow-[0_14px_44px_-12px_rgba(255,95,0,.7)] active:scale-[.98] md:w-auto">
          {sv.form.send}<Icon name="arrow" className="directional" />
        </button>
        <p className="mt-3 flex items-center gap-1.5 text-[11px] text-muted/70"><Icon name="info" size={13} />{sv.form.body}</p>
      </div>
    </form>
  );
}

export function ServicesPage({ lang, t }) {
  const sv = t.servicesPage;
  const goto = id => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  const anchors = { maintenance: 'svc-maintenance', repairs: 'svc-repair' };
  return (
    <>
      {/* 1. hero (~45vh) */}
      <section className="relative flex min-h-[45svh] items-end overflow-hidden bg-deep text-white" aria-labelledby="svc-hero-title">
        <img src="/images/facility-workshop.jpg" alt="" aria-hidden="true" width="1536" height="1024" className="kenburns absolute inset-0 h-full w-full object-cover" />
        <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/95 via-deep/55 to-deep/30" />
        <div className="relative mx-auto w-full max-w-(--container-yard) px-5 pb-10 pt-28 md:px-10 md:pb-12">
          <p className="pop flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.24em] text-brand" style={{ '--d': '0ms' }}>
            <span aria-hidden="true" className="sweep h-[3px] w-10 rounded-full bg-brand" />{t.nav.services}
          </p>
          <h1 id="svc-hero-title" className="pop mt-4 font-display text-4xl font-extrabold leading-[1.05] tracking-tight md:text-5xl" style={{ '--d': '150ms' }}>{sv.hero.title}</h1>
          <p className="pop mt-3 max-w-2xl text-sm leading-relaxed text-white/85" style={{ '--d': '280ms' }}>{sv.hero.body}</p>
          <div className="pop mt-6 flex flex-wrap gap-4" style={{ '--d': '400ms' }}>
            <button type="button" onClick={() => goto('svc-form')} className="cta-arrow inline-flex min-h-12 items-center gap-3 rounded-full bg-brand px-6 text-sm font-extrabold text-deep transition-all hover:bg-brandhot active:scale-[.98]">{sv.hero.request}<Icon name="tool" size={16} /></button>
            <a href={`#/${lang}/contact`} className="inline-flex min-h-12 items-center gap-3 rounded-full border-2 border-white/45 px-5 text-sm font-extrabold text-white transition-colors hover:border-white hover:bg-white hover:text-deep">{sv.hero.contact}<Icon name="arrow" className="directional" /></a>
          </div>
        </div>
      </section>

      {/* 2. main services — compact service index */}
      <Shell>
        <SectionHead eyebrow={sv.main.eyebrow} title={sv.main.title} body={sv.main.body} />
        <div className="grid overflow-hidden rounded-2xl border border-cardline bg-card md:grid-cols-2">
          {servicesList.map((item, j) => (
            <article key={item.id} className="io group flex min-h-[150px] gap-4 border-b border-cardline p-5 md:border-e md:p-6" style={{ '--d': `${j * 55}ms` }}>
              <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand"><Icon name={item.icon} size={21} /></span>
              <div className="min-w-0 flex-1">
                <h2 className="font-display text-lg font-extrabold tracking-tight">{item.title[lang]}</h2>
                <p className="mt-2 text-[13px] leading-relaxed text-muted">{item.body[lang]}</p>
                {anchors[item.id] && <button type="button" onClick={() => goto(anchors[item.id])} className="cta-arrow mt-3 inline-flex min-h-9 items-center gap-2 text-xs font-extrabold text-brand">{sv.main.details}<Icon name="arrow" className="directional" size={14} /></button>}
              </div>
            </article>
          ))}
        </div>
      </Shell>

      {/* 3. maintenance — split layout */}
      <Shell tone="raised">
        <div id="svc-maintenance" className="scroll-mt-28 grid items-center gap-8 lg:grid-cols-2 lg:gap-12">
          <div className="io">
            <p className="flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.22em] text-brand"><span aria-hidden="true" className="sweep h-[3px] w-9 rounded-full bg-brand" />{sv.maintenance.eyebrow}</p>
            <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight md:text-4xl">{sv.maintenance.title}</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted md:text-[15px]">{sv.maintenance.body}</p>
            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {sv.maintenance.items.map((it, j) => (
                <li key={it} className="io flex items-center gap-3 rounded-2xl border border-cardline bg-card/70 p-3.5 text-[13px] font-bold" style={{ '--d': `${j * 50}ms` }}>
                  <span className="grid size-8 shrink-0 place-items-center rounded-full bg-brand/15 text-brand"><Icon name="check" size={15} /></span>{it}
                </li>
              ))}
            </ul>
          </div>
          <figure className="io yard-card group overflow-hidden p-0">
            <div className="img-zoom relative aspect-[4/3] overflow-hidden">
              <img src="/images/service-maintenance.jpg" alt={sv.maintenance.title} loading="lazy" width="1200" height="900" className="h-full w-full object-cover" />
              <span className="absolute start-3 top-3 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.news.demoPhoto}</span>
            </div>
          </figure>
        </div>
      </Shell>

      {/* 4. repair & diagnostics — 5-step process */}
      <Shell>
        <div id="svc-repair" className="scroll-mt-28">
          <SectionHead eyebrow={sv.repair.eyebrow} title={sv.repair.title} />
          <ol className="grid gap-4 md:grid-cols-5">
            {sv.repair.steps.map((st, j) => (
              <li key={st.t} className="yard-card io relative overflow-hidden p-5" style={{ '--d': `${j * 70}ms` }}>
                <span aria-hidden="true" className="absolute -top-2 end-2 font-display text-6xl font-extrabold text-bone/[.07]">{j + 1}</span>
                <span className="grid size-11 place-items-center rounded-full bg-brand font-display text-lg font-extrabold text-deep">{j + 1}</span>
                <h3 className="mt-4 font-display text-base font-extrabold tracking-tight">{st.t}</h3>
                <p className="mt-2 text-xs leading-relaxed text-muted">{st.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </Shell>

      {/* 5. on-site support */}
      <Shell tone="raised">
        <div className="grid items-center gap-8 lg:grid-cols-2 lg:gap-12">
          <figure className="io yard-card group order-last overflow-hidden p-0 lg:order-first">
            <div className="img-zoom relative aspect-[4/3] overflow-hidden">
              <img src="/images/service-field.jpg" alt={sv.onsite.title} loading="lazy" width="1200" height="900" className="h-full w-full object-cover" />
              <span className="absolute start-3 top-3 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.news.demoPhoto}</span>
            </div>
          </figure>
          <div className="io">
            <p className="flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.22em] text-brand"><Icon name="pin" size={15} className="text-brand" />{sv.onsite.eyebrow}</p>
            <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight md:text-4xl">{sv.onsite.title}</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted md:text-[15px]">{sv.onsite.body}</p>
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              {sv.onsite.items.map((it, j) => (
                <div key={it} className="io flex items-center gap-3 rounded-2xl border border-cardline bg-card/70 p-3.5 text-[13px] font-bold" style={{ '--d': `${j * 50}ms` }}>
                  <span className="grid size-8 shrink-0 place-items-center rounded-full bg-brand/15 text-brand"><Icon name="check" size={15} /></span>{it}
                </div>
              ))}
            </div>
          </div>
        </div>
      </Shell>

      {/* 6. parts integration */}
      <Shell>
        <div className="io flex flex-wrap items-center gap-5 border-y border-cardline py-7">
          <span className="grid size-14 shrink-0 place-items-center rounded-3xl bg-brand/10 text-brand"><Icon name="parts" size={26} /></span>
          <div className="min-w-56 flex-1">
            <h2 className="font-display text-xl font-extrabold tracking-tight md:text-2xl">{sv.partsLink.title}</h2>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">{sv.partsLink.body}</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <BtnPrimary href={`#/${lang}/parts`}>{sv.partsLink.view}</BtnPrimary>
            <BtnGhost href={`#/${lang}/parts`}>{sv.partsLink.request}</BtnGhost>
          </div>
        </div>
      </Shell>

      {/* 7. why our services */}
      <Shell tone="raised">
        <SectionHead eyebrow={sv.why.eyebrow} title={sv.why.title} />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {sv.why.items.map((w, j) => (
            <div key={w.t} className="io flex flex-col items-center gap-3 border-t border-cardline px-4 py-6 text-center" style={{ '--d': `${j * 50}ms` }}>
              <span className="grid size-14 place-items-center rounded-full bg-brand/12 text-brand"><Icon name={w.icon} size={24} /></span>
              <h3 className="text-sm font-extrabold">{w.t}</h3>
              <p className="text-xs leading-relaxed text-muted">{w.d}</p>
            </div>
          ))}
        </div>
      </Shell>

      {/* 8. service request form */}
      <Shell>
        <div id="svc-form" className="scroll-mt-28">
          <SectionHead eyebrow={sv.form.eyebrow} title={sv.form.title} />
          <ServiceForm lang={lang} t={t} sv={sv} />
        </div>
      </Shell>

      {/* 9. FAQ — accordion */}
      <Shell tone="raised">
        <SectionHead eyebrow={sv.faq.eyebrow} title={sv.faq.title} />
        <div className="mx-auto grid max-w-3xl gap-3">
          {sv.faq.items.map((f, j) => (
            <details key={f.q} className="yard-card io group p-0 [&_summary::-webkit-details-marker]:hidden" style={{ '--d': `${j * 50}ms` }}>
              <summary className="flex min-h-14 cursor-pointer list-none items-center justify-between gap-4 px-5 py-4 text-sm font-extrabold transition-colors hover:text-brand">
                {f.q}
                <Icon name="plus" size={16} className="shrink-0 text-brand transition-transform duration-300 group-open:rotate-45" />
              </summary>
              <p className="border-t border-cardline px-5 py-4 text-sm leading-relaxed text-muted">{f.a}</p>
            </details>
          ))}
        </div>
      </Shell>

      {/* 10. final CTA */}
      <CtaBand id="svc-cta-title" title={sv.cta.title} body={sv.cta.body}>
        <button type="button" onClick={() => goto('svc-form')} className={CTA_PRIMARY}>{sv.cta.request}<Icon name="arrow" className="directional" /></button>
        <a href={`#/${lang}/contact`} className={CTA_GHOST}><Icon name="pin" size={15} />{sv.cta.contact}</a>
      </CtaBand>
    </>
  );
}
