import React from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell } from '../ui/kit';
import { products, cat, prods, prod, partsList } from '../lib/content';
import { StatusBadge, MachineCard } from './shared';

const GUIDE = {
  bulldozers: {
    en: ['Earthmoving and site preparation', 'Road and embankment work', 'Pushing and rough grading'],
    fa: ['خاک‌برداری و آماده‌سازی ساحه', 'راه‌سازی و کار خاکریز', 'هل‌دادن مواد و تسطیح ابتدایی'],
  },
  excavators: {
    en: ['Excavation and trenching', 'Loading and material handling', 'Foundation and utility work'],
    fa: ['حفاری و کندن ترانشه', 'بارگیری و انتقال مواد', 'کارهای فوندیشن و تأسیسات'],
  },
  loaders: {
    en: ['Stockpile handling', 'Truck loading', 'General site material movement'],
    fa: ['مدیریت دپوی مواد', 'بارگیری موتر', 'انتقال عمومی مواد در ساحه'],
  },
  compactors: {
    en: ['Road-base compaction', 'Embankment work', 'Site preparation'],
    fa: ['کمپکت بستر سرک', 'کار خاکریز', 'آماده‌سازی ساحه'],
  },
  graders: {
    en: ['Fine grading', 'Road shaping', 'Surface maintenance'],
    fa: ['تسطیح دقیق', 'شکل‌دهی سرک', 'نگهداری سطح راه'],
  },
  trucks: {
    en: ['Bulk material hauling', 'Mine and quarry transport', 'Heavy site logistics'],
    fa: ['انتقال حجمی مواد', 'حمل‌ونقل معدن و سنگ‌شکن', 'لجستیک سنگین ساحه'],
  },
};

function labels(lang) {
  return lang === 'fa' ? {
    overview: 'نمای کلی ماشین',
    applications: 'کاربردهای معمول',
    applicationsNote: 'نمونه‌ی راهنمای انتخاب بر اساس نوع ماشین؛ تطابق نهایی با پروژه توسط تیم تخنیکی بررسی می‌شود.',
    decision: 'قبل از درخواست قیمت چه چیزهایی را مشخص کنید؟',
    decisionItems: ['نوع پروژه و مواد', 'ساعات کاری روزانه', 'شرایط ساحه و مسیر', 'زمان مورد نیاز برای تحویل'],
    gallery: 'نمای ماشین و محیط کاری',
    support: 'قطعات و خدمات بعد از فروش',
    supportBody: 'صفحه ماشین باید پایان مسیر نباشد؛ از همین‌جا کاربر باید بتواند به قطعات، خدمات و درخواست قیمت برسد.',
    official: 'مشخصات رسمی',
    officialBody: 'جدول کامل مشخصات در فاز داینامیک از دیتای رسمی هر مودیل تغذیه می‌شود.',
    quote: 'درخواست قیمت این ماشین',
    contact: 'مشوره تخنیکی',
    breadcrumbHome: 'خانه', breadcrumbMachines: 'ماشین‌آلات',
  } : {
    overview: 'Machine overview',
    applications: 'Typical applications',
    applicationsNote: 'Sample selection guidance by machine family; final project fit is confirmed by the technical team.',
    decision: 'What to confirm before requesting a quote',
    decisionItems: ['Project and material type', 'Daily operating hours', 'Site and access conditions', 'Required delivery timeline'],
    gallery: 'Machine and job-site reference',
    support: 'Parts and after-sales support',
    supportBody: 'A machine page should not be a dead end. From here the customer can move directly to parts, service and quotation.',
    official: 'Official specifications',
    officialBody: 'The complete specification table will be fed from verified model data in the dynamic phase.',
    quote: 'Request a quote for this machine',
    contact: 'Technical consultation',
    breadcrumbHome: 'Home', breadcrumbMachines: 'Machinery',
  };
}

export function Product({ lang, t, route, onQuote }) {
  const p = prod(route.param) || products[0];
  const name = p.model || cat(p.category).label[lang];
  const family = prods(p.category).filter(x => x.id !== p.id).slice(0, 4);
  const fitParts = partsList.filter(pt => pt.fits && pt.fits.includes(p.category)).slice(0, 4);
  const l = labels(lang);
  const apps = GUIDE[p.category]?.[lang] || [];
  const contextImages = ['/images/work-earth.webp', '/images/work-road.webp', '/images/work-mine.webp'];

  return (
    <>
      <section className="border-b border-cardline bg-card pt-4">
        <div className="mx-auto max-w-(--container-yard) px-5 py-4 md:px-10">
          <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-2 text-[11px] font-bold text-muted">
            <a href={`#/${lang}/home`} className="hover:text-brand">{l.breadcrumbHome}</a><span>/</span>
            <a href={`#/${lang}/machinery`} className="hover:text-brand">{l.breadcrumbMachines}</a><span>/</span>
            <a href={`#/${lang}/machinery/${p.category}`} className="hover:text-brand">{cat(p.category).label[lang]}</a><span>/</span>
            <bdi className="text-bone">{name}</bdi>
          </nav>
        </div>
      </section>

      <section className="bg-ink py-8 md:py-12">
        <div className="mx-auto grid max-w-(--container-yard) gap-8 px-5 md:px-10 lg:grid-cols-[1.15fr_.85fr] lg:items-center lg:gap-12">
          <div className="io relative">
            <MachinePhoto name={p.image} alt={name} eager className="aspect-[4/3] rounded-2xl border border-cardline shadow-lift" />
            <span className="absolute start-4 top-4 rounded-lg bg-deep/88 px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-[.12em] text-white">{cat(p.category).label[lang]}</span>
          </div>
          <div className="io">
            <p className="text-[10px] font-extrabold uppercase tracking-[.22em] text-brand">SHANTUI · {cat(p.category).label[lang]}</p>
            <h1 className="mt-3 font-display text-5xl font-extrabold leading-none tracking-tight md:text-6xl"><bdi>{name}</bdi></h1>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted">{t.product.specsNote}</p>
            <div className="mt-5 flex flex-wrap items-center gap-2"><StatusBadge t={t} s={p.availability} /><span className="rounded-lg border border-cardline bg-card px-3 py-1.5 text-[10px] font-extrabold text-muted">{t.product.sample}</span></div>

            {p.keySpecs?.length > 0 && (
              <dl className="mt-7 grid grid-cols-3 border-y border-cardline">
                {p.keySpecs.slice(0, 3).map(sp => (
                  <div key={sp.k.en} className="py-5 pe-4">
                    <dt className="text-[10px] font-bold uppercase tracking-wide text-muted">{sp.k[lang]}</dt>
                    <dd className="mt-1 font-display text-lg font-extrabold tabular-nums md:text-xl">{sp.v}</dd>
                  </div>
                ))}
              </dl>
            )}
            <div className="mt-7 flex flex-wrap gap-3">
              <BtnPrimary onClick={() => onQuote(name)}>{l.quote}</BtnPrimary>
              <BtnGhost href={`#/${lang}/contact`}>{l.contact}</BtnGhost>
            </div>
          </div>
        </div>
      </section>

      <Shell tone="raised">
        <div className="grid gap-10 lg:grid-cols-[1fr_.9fr] lg:gap-14">
          <div>
            <SectionHead eyebrow={l.overview} title={l.applications} body={l.applicationsNote} />
            <div className="divide-y divide-cardline border-y border-cardline">
              {apps.map((app, i) => (
                <div key={app} className="feature-row flex items-center gap-4 py-5">
                  <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-brand text-sm font-extrabold text-deep">{i + 1}</span>
                  <p className="font-display text-lg font-extrabold tracking-tight">{app}</p>
                </div>
              ))}
            </div>
          </div>
          <aside className="panel-dark io p-6 md:p-8">
            <p className="text-[10px] font-extrabold uppercase tracking-[.2em] text-brand">{l.decision}</p>
            <div className="mt-5 divide-y divide-white/12">
              {l.decisionItems.map((item, i) => (
                <div key={item} className="flex items-center gap-3 py-4 first:pt-0">
                  <span className="font-display text-xl font-extrabold text-brand">0{i + 1}</span>
                  <span className="text-sm font-bold text-white/78">{item}</span>
                </div>
              ))}
            </div>
            <button onClick={() => onQuote(name)} className="cta-arrow mt-7 inline-flex min-h-12 items-center gap-3 rounded-xl bg-brand px-6 text-sm font-extrabold text-deep transition-colors hover:bg-brandhot">{t.product.quote}<Icon name="arrow" className="directional" /></button>
          </aside>
        </div>
      </Shell>

      <Shell>
        <SectionHead eyebrow={t.product.specs} title={l.official} body={l.officialBody} />
        <div className="grid gap-6 lg:grid-cols-[1.2fr_.8fr]">
          <div className="overflow-hidden rounded-2xl border border-cardline bg-card">
            <dl className="divide-y divide-cardline">
              {(p.keySpecs || []).map(sp => (
                <div key={sp.k.en} className="grid grid-cols-[1fr_auto] items-center gap-4 px-5 py-4 md:px-6">
                  <dt className="text-sm font-bold text-muted">{sp.k[lang]}</dt>
                  <dd className="font-display text-base font-extrabold tabular-nums">{sp.v}</dd>
                </div>
              ))}
              <div className="grid grid-cols-[1fr_auto] items-center gap-4 px-5 py-4 md:px-6"><dt className="text-sm font-bold text-muted">{t.availability.title}</dt><dd><StatusBadge t={t} s={p.availability} /></dd></div>
            </dl>
          </div>
          <div className="rounded-2xl border border-cardline bg-raised p-6">
            <Icon name="document" size={24} className="text-brand" />
            <h3 className="mt-4 font-display text-2xl font-extrabold tracking-tight">{t.downloads.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{t.downloads.none}</p>
            <a href={cat(p.category).source} target="_blank" rel="noreferrer" className="cta-arrow mt-5 inline-flex min-h-11 items-center gap-2 text-sm font-extrabold text-brand">{t.product.source}<Icon name="diagonal" size={14} /></a>
          </div>
        </div>
      </Shell>

      <section className="bg-deep py-14 text-white md:py-20">
        <div className="mx-auto max-w-(--container-yard) px-5 md:px-10">
          <div className="grid items-end gap-5 md:grid-cols-[1fr_.7fr]">
            <div><p className="text-[10px] font-extrabold uppercase tracking-[.2em] text-brand">{l.gallery}</p><h2 className="mt-3 font-display text-3xl font-extrabold tracking-tight md:text-4xl">{name}</h2></div>
            <p className="text-sm leading-relaxed text-white/55">{t.hero.note}</p>
          </div>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {contextImages.map((src, i) => <figure key={src} className={`io media-frame ${i === 0 ? 'md:col-span-2' : ''}`}><img src={src} alt="" aria-hidden="true" loading="lazy" className={`w-full object-cover ${i === 0 ? 'aspect-[16/8]' : 'aspect-[4/3]'}`} /></figure>)}
          </div>
        </div>
      </section>

      <Shell tone="raised">
        <SectionHead eyebrow={t.partsHome.eyebrow} title={l.support} body={l.supportBody} />
        <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
          <a href={`#/${lang}/parts`} className="group flex items-center gap-5 rounded-2xl border border-cardline bg-card p-5 transition-colors hover:border-brand/40">
            <span className="grid size-14 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand"><Icon name="parts" size={26} /></span>
            <div className="min-w-0 flex-1"><h3 className="font-display text-xl font-extrabold">{t.nav.parts}</h3><p className="mt-1 text-[13px] leading-relaxed text-muted">{t.productFit.partsNote}</p></div><Icon name="arrow" className="directional text-muted group-hover:text-brand" />
          </a>
          <a href={`#/${lang}/services`} className="group flex items-center gap-5 rounded-2xl border border-cardline bg-card p-5 transition-colors hover:border-brand/40">
            <span className="grid size-14 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand"><Icon name="tool" size={26} /></span>
            <div className="min-w-0 flex-1"><h3 className="font-display text-xl font-extrabold">{t.nav.services}</h3><p className="mt-1 text-[13px] leading-relaxed text-muted">{t.servicesHome.body}</p></div><Icon name="arrow" className="directional text-muted group-hover:text-brand" />
          </a>
        </div>

        {fitParts.length > 0 && (
          <div className="mt-14">
            <SectionHead eyebrow={t.partsHome.eyebrow} title={t.productFit.parts} body={t.productFit.partsNote} />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {fitParts.map((part, j) => (
                <article key={part.id} className="panel-flat io flex flex-col overflow-hidden" style={{ '--d': `${j * 60}ms` }}>
                  <div className="img-zoom aspect-[4/3] overflow-hidden bg-raised"><img src={`/images/${part.photo}`} alt={part.name[lang]} loading="lazy" className="h-full w-full object-cover" /></div>
                  <div className="flex flex-1 flex-col p-4"><h3 className="font-display text-base font-extrabold">{part.name[lang]}</h3><p className="mt-1 text-xs text-muted">{part.note[lang]}</p><button onClick={() => onQuote(`${name} — ${part.name[lang]}`)} className="mt-auto pt-4 text-start text-xs font-extrabold text-brand">{t.featured.quote}</button></div>
                </article>
              ))}
            </div>
          </div>
        )}

        {family.length > 0 && (
          <div className="mt-14">
            <SectionHead eyebrow={t.featured.eyebrow} title={t.productFit.similar} />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{family.map((x, j) => <MachineCard key={x.id} lang={lang} t={t} p={x} onQuote={onQuote} j={j} />)}</div>
          </div>
        )}
      </Shell>

      <div className="mobile-actionbar fixed inset-x-0 bottom-0 z-40 flex items-center gap-2 border-t border-cardline bg-card/96 p-3 backdrop-blur-xl">
        <a href={`#/${lang}/contact`} className="grid size-12 shrink-0 place-items-center rounded-xl border border-cardline text-bone"><Icon name="phone" /></a>
        <button onClick={() => onQuote(name)} className="flex min-h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-brand px-4 text-xs font-extrabold text-deep">{t.product.quote}<Icon name="arrow" className="directional" size={14} /></button>
      </div>
    </>
  );
}
