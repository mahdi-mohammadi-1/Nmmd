import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CtaBand, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, prod, partsList, partsGroups, servicesList, teamList, newsList, eventsList, facilitiesList, contactCards, branchesList, img } from '../lib/content';
import { PageHero, StatusBadge, MachineCard } from './shared';

// ============================================================
// Contact: quick desks, form + office info, branch map, CTA.
// ============================================================
function ContactForm({ lang, t, cp }) {
  const [f, setF] = useState({ name: '', phone: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);
  const set = (k, v) => { setF(x => ({ ...x, [k]: v })); setErrors(e => ({ ...e, [k]: false })); };
  const submit = e => {
    e.preventDefault();
    const errs = {};
    for (const k of ['name', 'phone', 'subject', 'message']) if (!String(f[k] || '').trim()) errs[k] = true;
    setErrors(errs);
    if (Object.keys(errs).length) return;
    try {
      const arr = JSON.parse(localStorage.getItem('shantui-contact-requests') || '[]');
      arr.push({ ...f, lang, at: new Date().toISOString() });
      localStorage.setItem('shantui-contact-requests', JSON.stringify(arr));
    } catch { /* storage blocked */ }
    setSent(true);
  };
  const inp = 'min-h-12 w-full rounded-2xl border bg-card px-4 text-sm font-bold text-bone placeholder:font-semibold placeholder:text-muted/50 focus:border-brand focus:outline-none';
  const lbl = 'mb-1.5 block text-xs font-bold text-muted';
  if (sent) {
    return (
      <div className="io yard-card flex h-full flex-col items-center justify-center p-6 text-center md:p-6">
        <span className="mx-auto grid size-16 place-items-center rounded-full bg-brand/15 text-brand"><Icon name="check" size={30} /></span>
        <h3 className="mt-5 font-display text-2xl font-extrabold tracking-tight">{cp.form.sent}</h3>
        <p className="mt-3 text-sm leading-relaxed text-muted">{cp.form.sentBody}</p>
        <button type="button" onClick={() => { setSent(false); setF({ name: '', phone: '', email: '', subject: '', message: '' }); }}
          className="cta-arrow mt-6 inline-flex min-h-12 items-center gap-3 rounded-full bg-brand px-6 text-sm font-extrabold text-deep transition-colors hover:bg-brandhot">
          {cp.form.again}<Icon name="arrow" className="directional" />
        </button>
      </div>
    );
  }
  return (
    <form onSubmit={submit} noValidate className="io yard-card grid gap-4 p-5 md:p-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className={lbl} htmlFor="cf-name">{cp.form.name} *</label>
          <input id="cf-name" value={f.name} onChange={e => set('name', e.target.value)} autoComplete="name" className={`${inp} ${errors.name ? 'border-red-500' : 'border-cardline'}`} />
          {errors.name && <p className="mt-1 text-[11px] font-bold text-red-600">{cp.form.required}</p>}
        </div>
        <div>
          <label className={lbl} htmlFor="cf-phone">{cp.form.phone} *</label>
          <input id="cf-phone" value={f.phone} onChange={e => set('phone', e.target.value)} type="tel" inputMode="tel" dir="ltr" autoComplete="tel" className={`${inp} ${errors.phone ? 'border-red-500' : 'border-cardline'}`} />
          {errors.phone && <p className="mt-1 text-[11px] font-bold text-red-600">{cp.form.required}</p>}
        </div>
      </div>
      <div>
        <label className={lbl} htmlFor="cf-email">{cp.form.email}</label>
        <input id="cf-email" value={f.email} onChange={e => set('email', e.target.value)} type="email" dir="ltr" autoComplete="email" className={`${inp} border-cardline`} />
      </div>
      <div>
        <label className={lbl} htmlFor="cf-subject">{cp.form.subject} *</label>
        <select id="cf-subject" value={f.subject} onChange={e => set('subject', e.target.value)} className={`${inp} ${errors.subject ? 'border-red-500' : 'border-cardline'}`}>
          <option value="">{cp.form.subjectPick}</option>
          {cp.form.subjects.map(sbj => <option key={sbj} value={sbj}>{sbj}</option>)}
        </select>
        {errors.subject && <p className="mt-1 text-[11px] font-bold text-red-600">{cp.form.required}</p>}
      </div>
      <div>
        <label className={lbl} htmlFor="cf-message">{cp.form.message} *</label>
        <textarea id="cf-message" value={f.message} onChange={e => set('message', e.target.value)} rows="5" className={`${inp} ${errors.message ? 'border-red-500' : 'border-cardline'} py-3`} />
        {errors.message && <p className="mt-1 text-[11px] font-bold text-red-600">{cp.form.required}</p>}
      </div>
      <div>
        <button type="submit" className="cta-arrow inline-flex min-h-14 w-full items-center justify-center gap-3 rounded-full bg-brand px-8 text-sm font-extrabold text-deep transition-all hover:bg-brandhot hover:shadow-[0_14px_44px_-12px_rgba(255,95,0,.7)] active:scale-[.98] sm:w-auto">
          {cp.form.send}<Icon name="arrow" className="directional" />
        </button>
        <p className="mt-3 flex items-center gap-1.5 text-[11px] text-muted/70"><Icon name="info" size={13} />{cp.form.body}</p>
      </div>
    </form>
  );
}

// stylized offline map card with branch tabs (real embed swaps in later).
function BranchMap({ lang, t, cp }) {
  const [active, setActive] = useState(0);
  const br = branchesList[active];
  return (
    <div className="io">
      <SectionHead eyebrow={cp.map.eyebrow} title={cp.map.title} body={cp.map.demo} />
      <div className="flex flex-wrap gap-2">
        {branchesList.map((b, j) => (
          <button key={b.id} type="button" onClick={() => setActive(j)}
            className={`min-h-11 rounded-full border-2 px-5 text-xs font-extrabold transition-colors ${j === active ? 'border-brand bg-brand text-deep' : 'border-cardline bg-card text-bone hover:border-brand hover:text-brand'}`}>
            {b.city[lang]}
          </button>
        ))}
      </div>
      <div className="yard-card mt-4 overflow-hidden p-0">
        <div className="relative aspect-[16/7] bg-deep">
          <svg aria-hidden="true" viewBox="0 0 800 350" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 h-full w-full">
            <g stroke="white" strokeOpacity="0.07" strokeWidth="1">
              {Array.from({ length: 17 }, (_, i) => <line key={'v' + i} x1={i * 50} y1="0" x2={i * 50} y2="350" />)}
              {Array.from({ length: 8 }, (_, i) => <line key={'h' + i} x1="0" y1={i * 50} x2="800" y2={i * 50} />)}
            </g>
            <g stroke="white" strokeOpacity="0.16" strokeWidth="3" fill="none" strokeLinecap="round">
              <path d="M-20 250 C 150 210, 260 290, 420 240 S 680 260, 820 210" />
              <path d="M120 -20 C 160 90, 90 180, 200 260 S 300 330, 340 370" />
              <path d="M560 -20 C 540 80, 640 140, 600 240 S 560 330, 580 370" />
            </g>
            <g stroke="#255" strokeOpacity="0" fill="rgba(255,255,255,.03)">
              <circle cx="200" cy="120" r="70" /><circle cx="620" cy="280" r="90" /><circle cx="420" cy="90" r="55" />
            </g>
          </svg>
          <span className="absolute start-3 top-3 z-10 flex items-center gap-1.5 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85"><Icon name="info" size={11} />{t.news.sample}</span>
          <span className="absolute z-10 -translate-x-1/2 -translate-y-full transition-all duration-500" style={{ left: `${br.pin.x}%`, top: `${br.pin.y}%` }}>
            <span className="absolute -bottom-1 left-1/2 size-6 -translate-x-1/2 rounded-full bg-brand/30" />
            <span className="relative grid size-10 place-items-center rounded-full border-4 border-deep bg-brand text-deep shadow-[0_10px_30px_-6px_rgba(255,95,0,.8)]">
              <Icon name="pin" size={17} />
            </span>
          </span>
          <span className="absolute bottom-3 end-3 z-10 rounded-2xl bg-deep/85 px-4 py-2.5 backdrop-blur">
            <span className="block text-[11px] font-extrabold text-white">{br.city[lang]}</span>
            <span dir="auto" className="mt-0.5 block max-w-56 truncate text-[11px] font-semibold text-white/70">{br.address[lang]}</span>
          </span>
        </div>
        <div className="grid gap-3 p-5 sm:grid-cols-3">
          <p className="flex items-start gap-2 text-[13px] font-bold text-muted"><Icon name="pin" size={15} className="mt-0.5 shrink-0 text-brand" />{br.address[lang]}</p>
          <p className="flex items-start gap-2 text-[13px] font-bold text-muted"><Icon name="calendar" size={15} className="mt-0.5 shrink-0 text-brand" />{br.hours[lang]}</p>
          <p className="flex items-start gap-2 text-[13px] font-bold text-muted"><Icon name="phone" size={15} className="mt-0.5 shrink-0 text-brand" /><span dir="ltr">{br.phone}</span></p>
        </div>
        <div className="border-t border-cardline p-5 pt-4">
          <a href={br.maps} target="_blank" rel="noreferrer" className="cta-arrow inline-flex min-h-11 items-center gap-2 text-xs font-extrabold text-brand">
            {cp.map.view}<Icon name="diagonal" size={14} />
          </a>
        </div>
      </div>
    </div>
  );
}

export function Contact({ lang, t, onQuote }) {
  const cp = t.contactPage;
  return (
    <>
      {/* 1. short hero */}
      <PageHero t={t} title={cp.hero.title} body={cp.hero.body} />

      {/* 2. quick contact — compact routing strip */}
      <Shell>
        <SectionHead eyebrow={cp.quick.eyebrow} title={cp.quick.title} body={cp.quick.body} />
        <div className="overflow-hidden rounded-2xl border border-cardline bg-card">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 lg:divide-x lg:divide-cardline rtl:lg:divide-x-reverse">
            {contactCards.map((c, j) => (
              <article key={c.id} className="io border-b border-cardline p-5 last:border-b-0 lg:border-b-0" style={{ '--d': `${j * 55}ms` }}>
                <div className="flex items-center gap-3">
                  <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand"><Icon name={c.icon} size={20} /></span>
                  <h2 className="font-display text-lg font-extrabold tracking-tight">{c.title[lang]}</h2>
                </div>
                <p className="mt-3 min-h-[38px] text-[12px] leading-relaxed text-muted">{c.body[lang]}</p>
                <div className="mt-4 flex flex-wrap items-center gap-3 text-[11px] font-extrabold">
                  <a href={`tel:${c.phone.replace(/\s/g, '')}`} className="inline-flex min-h-9 items-center gap-1.5 text-bone transition-colors hover:text-brand"><Icon name="phone" size={14} className="text-brand" /><span dir="ltr">{c.phone}</span></a>
                  <a href={`https://wa.me/${c.whatsapp}`} target="_blank" rel="noreferrer" className="inline-flex min-h-9 items-center gap-1.5 text-muted transition-colors hover:text-brand"><Icon name="whatsapp" size={14} />{cp.quick.whatsapp}</a>
                </div>
              </article>
            ))}
          </div>
        </div>
        <p className="io mt-4 flex items-start gap-2 text-[11px] font-bold leading-relaxed text-muted"><Icon name="info" size={14} className="mt-0.5 shrink-0 text-brand" />{cp.quick.demo}</p>
      </Shell>

      {/* 3. form + office info */}
      <Shell tone="raised">
        <div className="grid gap-8 lg:grid-cols-[1.15fr_1fr] lg:gap-12">
          <div>
            <SectionHead eyebrow={cp.form.eyebrow} title={cp.form.title} />
            <ContactForm lang={lang} t={t} cp={cp} />
          </div>
          <div className="io">
            <p className="flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.22em] text-brand"><Icon name="pin" size={15} />{cp.office.eyebrow}</p>
            <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight">{cp.office.title}</h2>
            <div className="panel-flat mt-6 grid gap-4 p-5 md:p-6">
              {[
                { icon: 'pin', label: cp.office.address, value: branchesList[0].address[lang], ltr: false },
                { icon: 'calendar', label: cp.office.hours, value: branchesList[0].hours[lang], ltr: false },
                { icon: 'phone', label: cp.office.phone, value: branchesList[0].phone, ltr: true, href: `tel:${branchesList[0].phone.replace(/\s/g, '')}` },
                { icon: 'whatsapp', label: cp.office.whatsapp, value: '+93 70 000 0003', ltr: true, href: `https://wa.me/${contactCards[3].whatsapp}` },
                { icon: 'mail', label: cp.office.email, value: contactCards[3].email, ltr: true, href: `mailto:${contactCards[3].email}` },
              ].map(row => (
                <div key={row.label} className="flex items-start gap-3.5">
                  <span className="grid size-10 shrink-0 place-items-center rounded-2xl bg-brand/12 text-brand"><Icon name={row.icon} size={18} /></span>
                  <div className="min-w-0">
                    <p className="text-[11px] font-extrabold uppercase tracking-[0.12em] text-muted">{row.label}</p>
                    {row.href ? (
                      <a href={row.href} target={row.href.startsWith('http') ? '_blank' : undefined} rel="noreferrer" dir={row.ltr ? 'ltr' : 'auto'} className="mt-0.5 inline-flex min-h-9 max-w-full items-center truncate text-sm font-extrabold text-bone transition-colors hover:text-brand">{row.value}</a>
                    ) : (
                      <p dir={row.ltr ? 'ltr' : 'auto'} className="mt-0.5 text-sm font-extrabold leading-relaxed text-bone">{row.value}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-4 flex items-center gap-2 text-[12px] font-bold text-muted"><Icon name="shield" size={14} className="text-brand" />{cp.office.responseNote}</p>
          </div>
        </div>
      </Shell>

      {/* 4. branch map */}
      <Shell>
        <BranchMap lang={lang} t={t} cp={cp} />
      </Shell>

      {/* 5. short CTA */}
      <CtaBand id="contact-cta-title" title={cp.cta.title} body={cp.cta.body}>
        <button type="button" onClick={onQuote} className={CTA_PRIMARY}>{cp.cta.quote}<Icon name="arrow" className="directional" /></button>
        <a href={`#/${lang}/parts`} className={CTA_GHOST}><Icon name="parts" size={15} />{cp.cta.parts}</a>
      </CtaBand>
    </>
  );
}
