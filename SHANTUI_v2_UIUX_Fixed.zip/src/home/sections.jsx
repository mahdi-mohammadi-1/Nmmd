import React, { useEffect, useState } from 'react';
import { Icon, MachinePhoto, BtnPrimary, BtnGhost, SectionHead, Shell, CTA_PRIMARY, CTA_GHOST } from '../ui/kit';
import { categories, products, cat, prods, img, servicesList, newsList, partsList, partsGroups, galleryList } from '../lib/content';

// ============================================================
// v2.9 home — user-defined structure (2026-09-23):
// Hero(video) → Products+Filter → Categories → About(brief)
// → Parts(finder) → Services(4) → News(1+2) → Gallery(masonry)
// → Testimonials(demo) → Finale CTA.
// ============================================================

export function Hero({ lang, t, onQuote }) {
  // Full-bleed background video; the file is user-supplied
  // (public/videos/hero.mp4|.webm). Until then the reference photo
  // animates with a slow Ken Burns drift.
  const words = (text, off = 0) => String(text).split(' ').map((w, j) => <span key={j} style={{ '--i': off + j }}>{w}{'\u00A0'}</span>);
  const countA = String(t.hero.titleA).split(' ').length;
  const [video, setVideo] = useState(null);
  useEffect(() => {
    let alive = true;
    (async () => {
      for (const src of ['/videos/hero.mp4', '/videos/hero.webm']) {
        try {
          const r = await fetch(src, { method: 'HEAD' });
          const type = r.headers.get('content-type') || '';
          if (r.ok && type.startsWith('video/')) { if (alive) setVideo(src); return; }
        } catch { /* keep probing */ }
      }
      if (alive) setVideo('');
    })();
    return () => { alive = false; };
  }, []);
  return (
    <section className="relative flex min-h-[92svh] items-end overflow-hidden bg-deep text-white" aria-labelledby="hero-title">
      {video ? (
        <video key={video} src={video} autoPlay muted loop playsInline aria-hidden="true" onError={() => setVideo('')} className="absolute inset-0 h-full w-full object-cover" />
      ) : (
        <img src={img('hero')} alt="" aria-hidden="true" width="1920" height="1080" className="kenburns absolute inset-0 h-full w-full object-cover" />
      )}
      <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/95 via-deep/40 to-deep/25" />
      <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-b from-deep/60 via-transparent to-transparent" />
      <div className="relative mx-auto w-full max-w-(--container-yard) px-5 pb-16 pt-40 md:px-10 md:pb-20">
        <p className="pop flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.24em] text-brand" style={{ '--d': '0ms' }}>
          <span aria-hidden="true" className="sweep h-[3px] w-10 rounded-full bg-brand" />{t.hero.eyebrow}
        </p>
        <h1 id="hero-title" className="word mt-6 font-display font-extrabold leading-[1.02] tracking-tight">
          <span className="block text-[clamp(1.75rem,8vw,5rem)] text-white">{words(t.hero.titleA)}</span>
          <span className="block text-[clamp(1.75rem,8vw,5rem)] text-brand">{words(t.hero.titleB, countA)}</span>
        </h1>
        <p className="pop mt-6 max-w-xl text-sm leading-relaxed text-white/85 md:text-base" style={{ '--d': '300ms' }}>{t.hero.body}</p>
        <div className="pop mt-8 flex flex-wrap items-center gap-4" style={{ '--d': '420ms' }}>
          <button type="button" onClick={() => onQuote('')} className="cta-arrow inline-flex min-h-14 items-center gap-4 rounded-full bg-brand px-8 text-sm font-extrabold text-deep transition-all hover:bg-brandhot hover:shadow-[0_14px_44px_-12px_rgba(255,95,0,.7)] active:scale-[.98]">
            {t.hero.quote}<Icon name="arrow" className="directional" />
          </button>
          <a href={`#/${lang}/machinery`} className="inline-flex min-h-14 items-center gap-3 rounded-full border-2 border-white/45 px-7 text-sm font-extrabold text-white transition-colors hover:border-white hover:bg-white hover:text-deep">
            {t.hero.machines}<Icon name="machine" size={18} />
          </a>
        </div>
        <p className="mt-8 flex items-center gap-2 text-[11px] tracking-wide text-white/50"><Icon name="info" size={14} />{t.hero.note}</p>
      </div>
    </section>
  );
}

// ---------- 2. SHANTUI machinery + filter (max 8 on home) ----------
export function ProductStream({ lang, t, onQuote }) {
  const [filter, setFilter] = useState('all');
  const pool = (filter === 'all' ? products : prods(filter)).slice(0, 8);
  return (
    <Shell>
      <SectionHead eyebrow={t.productsHome.eyebrow} title={t.productsHome.title} body={t.productsHome.body}>
        <BtnPrimary href={`#/${lang}/machinery`}>{t.productsHome.viewAll}</BtnPrimary>
      </SectionHead>
      <div className="mb-8 flex gap-2 overflow-x-auto pb-2 rail" role="group" aria-label={t.productsHome.all}>
        {[["all", t.productsHome.all], ...categories.map(c => [c.id, c.label[lang]])].map(([id, label]) => (
          <button key={id} onClick={() => setFilter(id)} aria-pressed={filter === id}
            className={`min-h-10 shrink-0 rounded-xl border px-4 text-xs font-extrabold transition-colors ${filter === id ? 'border-brand bg-brand text-deep' : 'border-cardline bg-card text-muted hover:border-bone/30 hover:text-bone'}`}>
            {label}
          </button>
        ))}
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {pool.map((p, j) => {
          const name = p.model || cat(p.category).label[lang];
          return (
            <article key={p.id} className="panel-flat io group flex min-w-0 flex-col overflow-hidden" style={{ '--d': `${j * 55}ms` }}>
              <a href={`#/${lang}/models/${p.id}`} className="img-zoom relative block aspect-[4/3] overflow-hidden bg-raised">
                <MachinePhoto name={p.image} alt={name} eager={j < 4} className="h-full rounded-none" />
                <span className="absolute start-3 top-3 z-20 rounded-lg bg-deep/88 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.12em] text-white">{cat(p.category).label[lang]}</span>
              </a>
              <div className="flex flex-1 flex-col p-4">
                <h3 className="font-display text-xl font-extrabold tracking-tight"><a href={`#/${lang}/models/${p.id}`} className="transition-colors group-hover:text-brand"><bdi>{name}</bdi></a></h3>
                {p.keySpecs?.length > 0 && (
                  <dl className="mt-3 grid grid-cols-3 gap-2 border-y border-cardline py-3">
                    {p.keySpecs.slice(0, 3).map(sp => (
                      <div key={sp.k.en} className="min-w-0">
                        <dt className="truncate text-[9px] font-bold uppercase tracking-wide text-muted">{sp.k[lang]}</dt>
                        <dd className="mt-0.5 truncate font-display text-xs font-extrabold text-bone">{sp.v}</dd>
                      </div>
                    ))}
                  </dl>
                )}
                <div className="mt-auto flex items-center justify-between gap-3 pt-4">
                  <a href={`#/${lang}/models/${p.id}`} className="cta-arrow inline-flex min-h-10 items-center gap-2 text-xs font-extrabold text-bone transition-colors hover:text-brand">{t.featured.view}<Icon name="arrow" className="directional" size={14} /></a>
                  <button onClick={() => onQuote(name)} className="min-h-10 text-xs font-extrabold text-brand transition-colors hover:text-brandhot">{t.featured.quote}</button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </Shell>
  );
}

export function CategoryTiles({ lang, t }) {
  return (
    <Shell tone="raised">
      <SectionHead eyebrow={t.catHome.eyebrow} title={t.catHome.title} body={t.catHome.body} />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((c, j) => (
          <a key={c.id} href={`#/${lang}/machinery/${c.id}`} className={`io group relative overflow-hidden rounded-2xl bg-deep ${j === 0 || j === 3 ? 'lg:col-span-2' : ''}`} style={{ '--d': `${j * 60}ms` }}>
            <div className={`img-zoom relative ${j === 0 || j === 3 ? 'aspect-[16/8]' : 'aspect-[4/3]'}`}>
              <img src={img(c.image)} alt={c.label[lang]} loading="lazy" width="1100" height="720" className="h-full w-full object-cover" />
              <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/90 via-deep/20 to-transparent" />
              <span aria-hidden="true" className="absolute inset-x-0 bottom-0 h-1 origin-left scale-x-0 bg-brand transition-transform duration-300 group-hover:scale-x-100" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-5 md:p-6">
                <div>
                  <span className="text-[9px] font-extrabold uppercase tracking-[0.2em] text-brand">SHANTUI</span>
                  <h3 className="mt-1 font-display text-2xl font-extrabold tracking-tight text-white md:text-3xl">{c.label[lang]}</h3>
                </div>
                <span className="grid size-10 shrink-0 place-items-center rounded-xl border border-white/25 bg-deep/35 text-white backdrop-blur transition-all group-hover:border-brand group-hover:bg-brand group-hover:text-deep"><Icon name="arrow" className="directional" /></span>
              </div>
            </div>
          </a>
        ))}
      </div>
    </Shell>
  );
}

export function AboutBrief({ lang, t }) {
  return (
    <section className="bg-deep py-14 text-white md:py-20">
      <div className="mx-auto grid max-w-(--container-yard) gap-8 px-5 md:px-10 lg:grid-cols-[1.05fr_.95fr] lg:items-stretch">
        <div className="io media-frame relative min-h-[360px] overflow-hidden lg:min-h-[520px]">
          <img src="/images/facility-yard.jpg" alt="" aria-hidden="true" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
          <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/80 via-deep/10 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-6 md:p-8">
            <p className="text-[10px] font-extrabold uppercase tracking-[0.22em] text-brand">{t.aboutBrief.eyebrow}</p>
            <p className="mt-2 max-w-md font-display text-3xl font-extrabold leading-tight md:text-4xl">{t.aboutBrief.titleAF}</p>
          </div>
        </div>
        <div className="io flex flex-col justify-center lg:ps-4">
          <p className="flex items-center gap-3 text-[11px] font-extrabold uppercase tracking-[0.22em] text-brand"><span aria-hidden="true" className="sweep h-[3px] w-9 rounded-full bg-brand" />{t.aboutBrief.eyebrow}</p>
          <div className="mt-5 grid gap-7">
            <div>
              <h2 className="font-display text-3xl font-extrabold tracking-tight md:text-4xl">{t.aboutBrief.titleG}</h2>
              <p className="mt-3 text-sm leading-relaxed text-white/65 md:text-[15px]">{t.aboutBrief.bodyG}</p>
            </div>
            <div className="border-t border-white/12 pt-6">
              <h3 className="font-display text-2xl font-extrabold tracking-tight">{t.aboutBrief.titleAF}</h3>
              <p className="mt-3 text-sm leading-relaxed text-white/65 md:text-[15px]">{t.aboutBrief.bodyAF}</p>
            </div>
          </div>
          <dl className="mt-8 grid grid-cols-3 border-y border-white/12">
            {t.aboutBrief.facts.map(f => (
              <div key={f.l} className="py-5 pe-3">
                <dt className="font-display text-2xl font-extrabold tabular-nums text-brand md:text-3xl">{f.n}</dt>
                <dd className="mt-1 text-[10px] font-bold leading-snug text-white/55 md:text-[11px]">{f.l}</dd>
              </div>
            ))}
          </dl>
          <div className="mt-7 flex flex-wrap items-center gap-4">
            <a href={`#/${lang}/about`} className="cta-arrow inline-flex min-h-12 items-center gap-3 rounded-xl bg-brand px-6 text-sm font-extrabold text-deep transition-colors hover:bg-brandhot">{t.aboutBrief.cta}<Icon name="arrow" className="directional" /></a>
            <span className="text-[10px] text-white/40">{t.aboutBrief.note}</span>
          </div>
        </div>
      </div>
    </section>
  );
}

export function PartsFinder({ lang, t, onQuote }) {
  const [model, setModel] = useState('');
  const [group, setGroup] = useState('all');
  const [searched, setSearched] = useState(false);
  // default view: one sample card per group; after a group search, that group's parts
  const perGroup = () => partsGroups.map(g => partsList.find(p => p.group === g.id)).filter(Boolean);
  const results = searched && group !== 'all' ? partsList.filter(p => p.group === group) : perGroup();
  const sel = 'w-full min-h-12 rounded-full border border-cardline bg-raised px-5 text-sm font-bold text-bone focus:border-brand focus:outline-none';
  return (
    <Shell tone="raised">
      <SectionHead eyebrow={t.partsHome.eyebrow} title={t.partsHome.title} body={t.partsHome.body} />
      <div className="io panel-dark mb-10 grid items-end gap-4 p-5 shadow-float md:grid-cols-[1fr_1fr_auto] md:p-6">
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold text-white/65">{t.partsHome.finder.model}</span>
          <select value={model} onChange={e => setModel(e.target.value)} className={`${sel} border-white/15 bg-white/10 text-white`}>
            <option value="">{t.quote.pick}</option>
            {products.map(p => <option key={p.id} value={p.model || p.id}>{p.model || cat(p.category).label[lang]}</option>)}
          </select>
        </label>
        <label className="block">
          <span className="mb-1.5 block text-xs font-bold text-white/65">{t.partsHome.finder.group}</span>
          <select value={group} onChange={e => { setGroup(e.target.value); setSearched(false); }} className={`${sel} border-white/15 bg-white/10 text-white`}>
            <option value="all">{t.partsHome.finder.all}</option>
            {partsGroups.map(g => <option key={g.id} value={g.id}>{g.label[lang]}</option>)}
          </select>
        </label>
        <BtnPrimary onClick={() => setSearched(true)} className="md:mb-0">{t.partsHome.finder.search}<Icon name="search" size={16} /></BtnPrimary>
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {results.map((part, j) => (
          <article key={part.id} className="yard-card io flex flex-col p-5" style={{ '--d': `${j * 60}ms` }}>
            <div className="img-zoom relative aspect-[4/3] overflow-hidden rounded-2xl bg-raised">
              <img src={`/images/${part.photo}`} alt={part.name[lang]} loading="lazy" width="640" height="480" className="h-full w-full object-cover" />
              <span className="absolute start-2.5 top-2.5 rounded-full bg-deep/85 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.1em] text-white/85">{t.partsHome.demoPhoto}</span>
            </div>
            <div className="flex items-center justify-between px-1 pt-3">
              <h3 className="font-display text-base font-extrabold tracking-tight">{part.name[lang]}</h3>
              <span className="rounded-full border border-cardline bg-raised px-2 py-0.5 font-display text-[10px] font-extrabold tabular-nums text-muted">{part.num}</span>
            </div>
            <p className="mt-1 px-1 text-xs leading-relaxed text-muted">{part.note[lang]}</p>
            <button onClick={() => onQuote(part.name[lang])} className="cta-arrow mt-auto inline-flex min-h-11 items-center gap-2 px-1 text-xs font-extrabold text-brand">{t.featured.quote}<Icon name="arrow" className="directional" size={14} /></button>
          </article>
        ))}
      </div>
      <div className="mt-8 flex flex-wrap items-center gap-4">
        <BtnPrimary href={`#/${lang}/parts`}>{t.partsHome.view}</BtnPrimary>
        <BtnGhost onClick={onQuote}>{t.partsHome.request}</BtnGhost>
        <span className="text-[11px] text-muted/70">{results.length} {t.partsHome.finder.results}{model ? ` · ${model}` : ''}</span>
      </div>
    </Shell>
  );
}

// ---------- 6. Services: icon cards, short ----------
export function ServicesGrid({ lang, t }) {
  return (
    <Shell>
      <SectionHead eyebrow={t.servicesHome.eyebrow} title={t.servicesHome.title} body={t.servicesHome.body}>
        <a href={`#/${lang}/services`} className="cta-arrow mt-4 inline-flex min-h-11 items-center gap-3 text-sm font-extrabold text-bone transition-colors hover:text-brand">{t.servicesHome.all}<Icon name="arrow" className="directional" /></a>
      </SectionHead>
      <div className="grid overflow-hidden rounded-2xl border border-cardline bg-card lg:grid-cols-[1.05fr_.95fr]">
        <div className="img-zoom relative min-h-[320px] lg:min-h-[460px]">
          <img src="/images/service-maintenance.jpg" alt="" aria-hidden="true" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
          <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/75 via-transparent to-transparent" />
          <span className="absolute bottom-5 start-5 rounded-lg bg-deep/80 px-3 py-2 text-[10px] font-extrabold uppercase tracking-[.14em] text-white/80 backdrop-blur">{t.nav.services}</span>
        </div>
        <div className="divide-y divide-cardline">
          {servicesList.slice(0, 4).map((sv, j) => (
            <a key={sv.id} href={`#/${lang}/services`} className="io group flex min-h-[112px] items-start gap-4 p-5 transition-colors hover:bg-raised/70 md:p-6" style={{ '--d': `${j * 65}ms` }}>
              <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand"><Icon name={sv.icon} size={21} /></span>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-display text-lg font-extrabold tracking-tight md:text-xl">{sv.title[lang]}</h3>
                  <Icon name="arrow" className="directional mt-1 shrink-0 text-muted transition-transform group-hover:translate-x-1 group-hover:text-brand" size={16} />
                </div>
                <p className="mt-1.5 text-[13px] leading-relaxed text-muted">{sv.body[lang]}</p>
              </div>
            </a>
          ))}
        </div>
      </div>
    </Shell>
  );
}

export function NewsAsym({ lang, t }) {
  const [big, ...rest] = newsList.slice(0, 3);
  const badge = <span className="rounded-full border border-brand/50 bg-deep/70 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.12em] text-brand backdrop-blur">{t.news.sample}</span>;
  return (
    <Shell tone="raised">
      <SectionHead eyebrow={t.news.eyebrow} title={t.news.title} body={t.news.body}>
        <a href={`#/${lang}/news`} className="cta-arrow mt-4 inline-flex min-h-11 items-center gap-3 border-b-2 border-brand pb-1 text-sm font-extrabold text-bone transition-colors hover:text-brand">{t.news.all}<Icon name="arrow" className="directional" /></a>
      </SectionHead>
      <div className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
        <article className="yard-card io group overflow-hidden">
          <div className="img-zoom relative aspect-[16/10] overflow-hidden">
            <img src={`/images/${big.photo}`} alt={big.title[lang]} loading="lazy" width="960" height="600" className="h-full w-full object-cover" />
            <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/70 to-transparent" />
            <span className="absolute start-3 top-3">{badge}</span>
          </div>
          <div className="p-6">
            <span className="rounded-full bg-raised px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.14em] text-bone/70">{big.cat[lang]}</span>
            <a href={`#/${lang}/news/${big.id}`}><h3 className="mt-3 font-display text-2xl font-extrabold leading-snug tracking-tight transition-colors hover:text-brand md:text-3xl">{big.title[lang]}</h3></a>
            <p className="mt-2.5 text-sm leading-relaxed text-muted">{big.summary[lang]}</p>
          </div>
        </article>
        <div className="grid gap-5">
          {rest.map((n, j) => (
            <article key={n.id} className="yard-card io group flex flex-col overflow-hidden sm:flex-row" style={{ '--d': `${(j + 1) * 90}ms` }}>
              <div className="img-zoom relative aspect-[16/10] overflow-hidden sm:aspect-auto sm:w-2/5 sm:shrink-0">
                <img src={`/images/${n.photo}`} alt={n.title[lang]} loading="lazy" width="640" height="480" className="h-full w-full object-cover" />
                <span className="absolute start-2.5 top-2.5">{badge}</span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <span className="self-start rounded-full bg-raised px-3 py-1 text-[10px] font-extrabold uppercase tracking-[0.14em] text-bone/70">{n.cat[lang]}</span>
                <a href={`#/${lang}/news/${n.id}`}><h3 className="mt-2.5 font-display text-lg font-extrabold leading-snug tracking-tight transition-colors hover:text-brand">{n.title[lang]}</h3></a>
                <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-muted">{n.summary[lang]}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </Shell>
  );
}

// ---------- 8. Gallery: editorial masonry, captions only ----------
export function Gallery({ lang, t }) {
  return (
    <Shell>
      <SectionHead eyebrow={t.galleryHome.eyebrow} title={t.galleryHome.title}>
        <p className="mt-2 flex items-center gap-2 text-[11px] text-muted/70"><Icon name="info" size={13} />{t.galleryHome.note}</p>
      </SectionHead>
      <div className="columns-2 gap-4 lg:columns-3 [&>figure]:mb-4">
        {galleryList.map((g, j) => (
          <figure key={g.img} className="io break-inside-avoid" style={{ '--d': `${j * 60}ms` }}>
            <div className="yard-card group overflow-hidden p-0">
              <div className="img-zoom relative overflow-hidden">
                <img src={img(g.img)} alt={g.caption[lang]} loading="lazy" width="880" height="880" className={`w-full object-cover ${g.ar}`} />
                <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-deep/75 via-transparent to-transparent opacity-80 transition-opacity group-hover:opacity-100" />
                <figcaption className="absolute inset-x-0 bottom-0 flex items-center gap-2 p-4 text-sm font-extrabold text-white">
                  <Icon name="pin" className="text-brand" size={15} />{g.caption[lang]}
                </figcaption>
              </div>
            </div>
          </figure>
        ))}
      </div>
    </Shell>
  );
}

// ---------- 9. Testimonials: clearly demo ----------
export function Testimonials({ lang, t }) {
  return (
    <Shell tone="raised">
      <SectionHead eyebrow={t.testi.eyebrow} title={t.testi.title} body={t.testi.note} />
      <div className="grid gap-0 border-y border-cardline md:grid-cols-3 md:divide-x md:divide-cardline rtl:md:divide-x-reverse">
        {t.testi.items.map((it, j) => (
          <figure key={it.w} className="io flex min-h-[220px] flex-col px-2 py-7 md:px-7" style={{ '--d': `${j * 80}ms` }}>
            <span className="font-display text-4xl font-extrabold leading-none text-brand">“</span>
            <blockquote className="mt-3 flex-1 text-[15px] font-semibold leading-relaxed text-bone/90">{it.q}</blockquote>
            <figcaption className="mt-5 text-xs font-extrabold text-muted">{it.w}</figcaption>
          </figure>
        ))}
      </div>
    </Shell>
  );
}

export function Finale({ t, onQuote, lang }) {
  return (
    <section className="relative overflow-hidden bg-deep py-14 text-white md:py-16" aria-labelledby="finale-title">
      <span aria-hidden="true" className="pointer-events-none absolute -bottom-8 end-0 hidden select-none font-display text-[160px] font-extrabold leading-none tracking-tighter text-white/[.05] md:block">{lang === 'fa' ? 'SHANTUI' : 'LET’S TALK'}</span>
      <div className="relative mx-auto flex max-w-(--container-yard) flex-wrap items-center justify-between gap-8 px-5 md:px-10">
        <div className="min-w-0">
          <span aria-hidden="true" className="mb-4 block h-[3px] w-10 rounded-full bg-brand" />
          <h2 id="finale-title" className="max-w-2xl font-display text-3xl font-extrabold leading-[1.05] tracking-tight md:text-4xl">{t.cta.title}</h2>
        </div>
        <div className="flex flex-wrap gap-4">
          <button onClick={onQuote} className={CTA_PRIMARY}>{t.hero.quote}<Icon name="arrow" className="directional" /></button>
          <a href={`#/${lang}/contact`} className={CTA_GHOST}><Icon name="pin" size={16} />{t.nav.contact}</a>
        </div>
      </div>
    </section>
  );
}
