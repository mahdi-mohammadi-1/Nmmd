import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Icon } from '../ui/kit';
import { categories, partsGroups, servicesList } from '../lib/content';

// ============================================================
// v2.9 chrome — fixed header over the home hero video:
// transparent dark-glass pill at the top of the page, solid
// light glass once scrolled (and always on interior pages).
// Footer: full sitemap — pages, machinery, parts, services,
// company info + honest "coming soon" social buttons.
// ============================================================

export function Header({ route, t, onQuote, onSwitchLang }) {
  const nav = [
    ['home', t.nav.home], ['about', t.nav.about], ['machinery', t.nav.machinery],
    ['parts', t.nav.parts], ['services', t.nav.services], ['news', t.nav.news], ['contact', t.nav.contact],
  ];
  const active = id => id === route.page || (id === 'machinery' && route.page === 'models');
  const [menuOpen, setMenuOpen] = useState(false);
  const listRef = useRef(null);
  const [ind, setInd] = useState(null);
  const [scrolled, setScrolled] = useState(false);

  // Home: overlay state until the visitor scrolls; interior pages: always solid.
  const onHome = route.page === 'home';
  const solid = !onHome || scrolled;

  useEffect(() => {
    const on = () => setScrolled(scrollY > 24);
    on();
    addEventListener('scroll', on, { passive: true });
    return () => removeEventListener('scroll', on);
  }, []);

  const measure = () => {
    const el = listRef.current?.querySelector('[aria-current="page"]');
    setInd(el ? { left: el.offsetLeft, width: el.offsetWidth } : null);
  };
  useLayoutEffect(measure, [route.path, route.lang]);
  useEffect(() => {
    // link widths shift when webfonts settle and on resize — re-measure.
    const t = setTimeout(measure, 350);
    document.fonts?.ready?.then(measure);
    addEventListener('resize', measure);
    return () => { clearTimeout(t); removeEventListener('resize', measure); };
  }, [route.path, route.lang]);

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = e => e.key === 'Escape' && setMenuOpen(false);
    addEventListener('keydown', onKey);
    return () => removeEventListener('keydown', onKey);
  }, [menuOpen]);

  const linkCls = id => `relative z-10 rounded-xl px-3 py-2.5 text-[12.5px] font-bold transition-colors ${active(id) ? 'text-deep' : solid ? 'text-muted hover:text-bone' : 'text-white/80 hover:text-white'}`;
  const ghostBtn = solid
    ? 'border-cardline text-bone/85 hover:border-brand hover:text-brand'
    : 'border-white/30 text-white/90 hover:border-white hover:text-white';

  return (
    <div className="fixed inset-x-0 top-0 z-40">
      <div className="bg-brand text-deep">
        <div className="mx-auto flex min-h-8 max-w-(--container-yard) items-center gap-3 px-5 text-[10px] font-extrabold uppercase tracking-[0.14em] md:px-10">
          <span>{t.preview}</span>
          <span aria-hidden="true" className="h-3 w-px bg-deep/30" />
          <span className="truncate font-semibold normal-case tracking-normal opacity-80">{t.previewNote}</span>
        </div>
      </div>
      <div className="px-3 pt-3">
        <header className={`mx-auto flex max-w-(--container-yard) items-center gap-2 rounded-2xl border p-2 backdrop-blur-xl transition-[background-color,border-color,box-shadow] duration-300 ${solid ? 'border-cardline bg-card/90 shadow-lift' : 'border-white/15 bg-deep/35'}`}>
          <a href={`#/${route.lang}/home`} className={`flex min-h-11 shrink-0 items-center gap-2.5 rounded-md ps-2 ${solid ? '' : 'bg-white/95 px-1.5 py-1'}`} aria-label={`SHANTUI ${t.country}`}>
            <img src="/images/shantui-logo.png" width="180" height="39" alt="SHANTUI" className="h-auto w-[104px] min-[480px]:w-[120px]" />
          </a>
          <nav ref={listRef} aria-label={t.common.menu} className="relative ms-auto hidden items-center xl:flex">
            {ind && <span aria-hidden="true" className="absolute bottom-0.5 top-0.5 rounded-xl bg-brand transition-[left,width] duration-300" style={{ left: ind.left, width: ind.width }} />}
            {nav.map(([id, label]) => (
              <a key={id} href={`#/${route.lang}/${id}`} aria-current={active(id) ? 'page' : undefined} className={linkCls(id)}>
                {label}
              </a>
            ))}
          </nav>
          <div className="ms-auto flex items-center gap-1.5 xl:ms-1">
            <button type="button" onClick={onSwitchLang} aria-label={t.common.language} className={`inline-flex min-h-10 items-center gap-2 rounded-xl border px-3 text-[11px] font-extrabold transition-colors ${ghostBtn}`}>
              <Icon name="grid" size={14} /><span lang={route.lang === 'en' ? 'fa-AF' : 'en'} className="hidden min-[480px]:inline">{t.common.language}</span>
            </button>
            <button type="button" onClick={onQuote} className="cta-arrow hidden min-h-10 items-center gap-2 rounded-xl bg-brand px-4 text-[11px] font-extrabold text-deep transition-all hover:bg-brandhot sm:inline-flex">
              {t.hero.quote}<Icon name="arrow" className="directional" size={15} />
            </button>
            <button type="button" onClick={() => setMenuOpen(o => !o)} aria-label={t.common.menu} aria-expanded={menuOpen} aria-haspopup="menu"
              className={`grid size-10 place-items-center rounded-xl border transition-colors ${ghostBtn} xl:hidden`}>
              <Icon name={menuOpen ? 'close' : 'grid'} size={17} />
            </button>
          </div>
        </header>
        {menuOpen && (
          <div className="pop mx-auto mt-2 max-w-(--container-yard) rounded-3xl border border-cardline bg-card/95 p-3 shadow-float backdrop-blur-xl" role="menu" aria-label={t.common.menu}>
            <div className="grid grid-cols-2 gap-1.5 min-[480px]:grid-cols-3">
              {nav.map(([id, label]) => (
                <a key={id} href={`#/${route.lang}/${id}`} role="menuitem" aria-current={active(id) ? 'page' : undefined} onClick={() => setMenuOpen(false)}
                  className={`flex min-h-11 items-center rounded-2xl px-4 text-sm font-bold transition-colors ${active(id) ? 'bg-brand text-deep' : 'text-bone/80 hover:bg-raised hover:text-bone'}`}>
                  {label}
                </a>
              ))}
            </div>
            <button type="button" onClick={() => { setMenuOpen(false); onQuote(); }} className="cta-arrow mt-2 flex min-h-12 w-full items-center justify-center gap-3 rounded-2xl bg-brand text-sm font-extrabold text-deep transition-colors hover:bg-brandhot">
              {t.hero.quote}<Icon name="arrow" className="directional" size={17} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export function Footer({ lang, t }) {
  const groups = [
    [t.common.menu, navLinks(t, lang)],
    [t.nav.machinery, categories.map(c => [`#/${lang}/machinery/${c.id}`, c.label[lang]])],
    [t.nav.parts, partsGroups.map(g => [`#/${lang}/parts`, g.label[lang]])],
    [t.nav.services, servicesList.map(s => [`#/${lang}/services`, s.title[lang]])],
  ];
  const links = items => (
    <ul className="mt-3 grid gap-1">
      {items.map(([href, label]) => (
        <li key={`${href}-${label}`}>
          <a href={href} className="link-sweep inline-flex min-h-9 items-center text-[13px] font-semibold text-white/68 transition-colors hover:text-brand">{label}</a>
        </li>
      ))}
    </ul>
  );
  return (
    <footer className="relative mt-4 bg-deep text-white">
      <div aria-hidden="true" className="h-[3px] bg-brand" />
      <div className="mx-auto max-w-(--container-yard) px-5 pb-10 pt-12 md:px-10 md:pb-12 md:pt-14">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_2.6fr] lg:gap-14">
          <div>
            <img src="/images/shantui-logo.png" width="180" height="39" alt="SHANTUI" className="h-auto w-[132px] rounded-md bg-white p-1.5" />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-white/60">{t.hero.body}</p>
            <p className="mt-4 text-[10px] font-extrabold uppercase tracking-[0.24em] text-brand">{t.tagline}</p>
            <div className="mt-6 flex items-center gap-2">
              {[["telegram", "Telegram"], ["whatsapp", "WhatsApp"], ["instagram", "Instagram"]].map(([icon, name]) => (
                <button key={icon} type="button" title={`${name} — ${t.socialSoon}`} aria-label={`${name} — ${t.socialSoon}`}
                  className="grid size-10 place-items-center rounded-xl border border-white/15 text-white/70 transition-all hover:-translate-y-0.5 hover:border-brand hover:text-brand">
                  <Icon name={icon} size={18} />
                </button>
              ))}
            </div>
          </div>

          <div className="hidden grid-cols-4 gap-8 md:grid">
            {groups.map(([title, items]) => (
              <nav key={title} aria-label={title}>
                <p className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-white/42">{title}</p>
                {links(items)}
              </nav>
            ))}
          </div>

          <div className="divide-y divide-white/10 border-y border-white/10 md:hidden">
            {groups.map(([title, items], j) => (
              <details key={title} open={j === 0} className="group py-1">
                <summary className="flex min-h-12 cursor-pointer list-none items-center justify-between gap-3 text-sm font-extrabold text-white/85 marker:hidden">
                  {title}<Icon name="plus" size={14} className="text-brand transition-transform group-open:rotate-45" />
                </summary>
                <div className="pb-4">{links(items)}</div>
              </details>
            ))}
          </div>
        </div>
        <div className="mt-10 flex flex-col gap-3 border-t border-white/10 pt-5 text-[11px] leading-relaxed text-white/42 sm:flex-row sm:items-center sm:justify-between">
          <p>{t.footer.rights}</p>
          <a href={`#/${lang}/contact`} className="inline-flex min-h-9 items-center gap-2 font-bold text-white/68 transition-colors hover:text-brand"><Icon name="pin" size={14} />{t.nav.contact}</a>
          <p className="font-bold tracking-wide">{t.footer.made}</p>
        </div>
      </div>
    </footer>
  );
}

function navLinks(t, lang) {
  return [
    ['home', t.nav.home], ['about', t.nav.about], ['machinery', t.nav.machinery],
    ['parts', t.nav.parts], ['services', t.nav.services], ['news', t.nav.news], ['contact', t.nav.contact],
  ].map(([id, label]) => [`#/${lang}/${id}`, label]);
}
